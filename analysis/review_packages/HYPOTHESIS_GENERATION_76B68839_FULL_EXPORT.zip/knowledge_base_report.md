# Selective Knowledge-Borrowing for OOD Discovery

**Knowledge Base** · Generated on July 20, 2026 by Google Hypothesis Generation. AI can be inaccurate; double check it.

## Physical And Electronic Mechanisms Of Transfer Failure

### Valence Orbital Energetics And Ligand Field Interactions
In transition metal complexes, the spatial and electronic configuration of valence d-orbitals governs chemical bonding and reactivity. In planar coordination complexes containing $\pi$-donor halide ligands, spectroscopic studies establish the d-orbital sequence as:
$$d_{x^2-y^2} > d_{xy} > d_{xz}, d_{yz} > d_{z^2}$$
 [1]For $\sigma$-only coordination systems, such as $[Pd(NH_3)_4]^{2+}$, ligand field models including the angular overlap model (AOM) and cellular ligand field (CLF) model predict degeneracy among the $d_{xz}$, $d_{yz}$, and $d_{xy}$ orbitals. Kohn-Sham (KS) density functional theory (DFT) calculations place the $d_{xy}$ orbital below the $d_{xz}/d_{yz}$ pair. [1] Direct utilization of KS orbital eigenvalues in AOM or CLF analyses incorrectly implies that these ligands act as $\pi$-acceptors. This discrepancy arises because KS orbitals explicitly incorporate interelectron repulsion contributions, whereas ligand field theory d-orbitals do not. In a low-spin $d^8$ complex, DFT calculations yield less d-d interelectron repulsion in the $xy$ plane, lowering the energy of $d_{xy}$ relative to $d_{xz}/d_{yz}$. This sequence can be qualitatively reversed by rearranging approximately 0.6 electrons from the $d_{z^2}$ orbital to the $d_{x^2-y^2}$ orbital, making the $d_{\pi}$ orbitals for $[Pd(NH_3)_4]^{2+}$ virtually degenerate and establishing $E(d_{xy}) > E(d_{xz}/d_{yz})$ for $[PdCl_4]^{2-}$.

For iron complexes coordinated with proton-responsive SCS pincer ligands, the planar ligand exerts a large positive contribution to the z-component of the electric field gradient. This is counteracted by a large negative contribution from the $d_{z^2}$ ground state, yielding small quadrupole splitting ($\Delta E_Q$) values. [2] Double occupation of the $d_{z^2}$ orbital decreases the isomer shift due to increased mixing of the doubly occupied $3d_{z^2}$ with the $4s$ orbital, which increases s-electron density at the nucleus. [3]

In single-atom catalysts (SACs) based on 3d transition metals (Mn, Fe, Co, Ni, Cu) supported on carbon frameworks ($M-N-C$), X-ray absorption near-edge structure (XANES) reveals that the metal centers are positively charged, with oxidation states lying between those of the respective metals and metal oxides. [4] Extended X-ray absorption fine structure (EXAFS) of manganese single atoms in $Mn-N-C$ reveals a coordination peak at approximately 1.45 Å, matching $Mn-N$ coordination. The absence of a $Mn-Mn$ peak at 2.31 Å confirms atomic dispersion in a predominant $MnN_4$ configuration. [5]

### Ligand Coordination Sites And Selectivity Switching
The coordination site of a ligand dictates reaction selectivity by modifying the electronic configuration of transition metal valence orbitals. In the $CO_2/C_2H_4$ coupling reaction over Ru-based catalysts, the optimized ethylene complex 11A adopts a tetrahedral coordination geometry. [6] The $4d$ orbitals split according to this ligand field, where the $d_{xz}$, $d_{yz}$, and $d_{z^2}$ orbitals show significant interactions with the substrates, placing them at higher energy levels than $d_{x^2-y^2}$ and $d_{xy}$. An unconventional configuration occurs where $d_{xz}$ and $d_{z^2}$ are doubly occupied, while the lower-energy $d_{x^2-y^2}$ remains unoccupied.

The selectivity of the reaction is governed by ligand-induced electronic rearrangements:
* Saturated complexes: Complex 3B possesses 18 electrons, preventing additional ligands from binding to the transition metal due to the lack of low-energy unoccupied orbitals. Releasing a coordination site requires high-energy cleavage of the $Ru-P$ bond.
* Unsaturated complexes: The unsaturated complex 3A can bind additional ethylene molecules, facilitating the formation of unsaturated Ru carboxylate products.
* Binding modes: Electron-rich metal centers prefer the $\eta^1(C)$ binding mode due to charge transfer between the metal $4d$ orbital and the antibonding $\pi^*$ orbital of $CO_2$. Electron-deficient metal centers prefer the $\eta^1(O)$ and $\eta^2(O,O)$ modes. The Ru/PP3 catalytic system (high electron-donating ability of 0.20 e) exhibits the $\eta^1(C)$ mode, whereas the Ru/dmpe system exhibits the $\eta^2(C,O)$ mode.

### Spectator Versus Functional Ligand Chemistry
Ligand participation in transition metal catalysis exists along a continuum ranging from ancillary/spectator/innocent, electronically coupled/noninnocent, participatory/cooperative, to functional ligands, where bond-making and bond-breaking are localized on the ligand itself, stabilized by a spectator metal.

In the complex $1\cdot[Ru]^+$ (consisting of a nontrigonal phosphorus chelate, $P(N(o-N(2-pyridyl)C_6H_4)_2)$, and an inert $[Ru] = (Me_5C_5)Ru$ fragment), reaction with $NaBH_4$ forms the metallohydridophosphorane $1H\cdot[Ru]$ via $P-H$ bond formation. This complex functions as a potent hydride donor, with an experimental hydride donor free energy $\Delta G^\circ_{H^-,\text{exp}} < 41$ kcal/mol and a calculated value of $\Delta G^\circ_{H^-,\text{calc}} = 38 \pm 2$ kcal/mol in MeCN. [7] 

Kohn-Sham orbital analysis of $1\cdot[Ru]^+$ reveals a low-lying unfilled orbital localized on the phosphorus atom that projects into the concave space of the chelate to bind incoming hydride. Natural localized molecular orbital (NLMO) analysis of the formed $P-H$ bond shows leading contributions of 51.6% from H and 47.2% from P. Natural population analysis (NPA) assigns a negative charge of -0.09 to the $P-H$ hydrogen, compared to positive charges of $+0.20$ on the other hydrogens. $P-H$ bond formation alters the $Ru-P$ $\sigma$-interaction: the NLMO for the dative covalent $P \rightarrow Ru$ $\sigma$-interaction in $1\cdot[Ru]^+$ is polarized toward phosphorus (62.0% P / 34.5% Ru), whereas in $1H\cdot[Ru]$ the $P-Ru$ bond exhibits increased covalency (55.9% P / 41.8% Ru). The $1H\cdot[Ru]$ species exhibits a characteristic $^1H$ NMR doublet centered at $\delta 8.38$ ppm with a coupling constant of $J = 469$ Hz.

### Spin State Transitions And Single Electron Transfer Kinetics
Axial ligand coordination environments regulate single electron transfer (SET) kinetics by modulating transition metal spin states. In the thioetherification/C-S coupling of 2,4-dimethylbenzenethiol (1a) and styrene (2a) catalyzed by $Fe(III)Cl-TCPP$, intermediate $[RSH-Fe(III)TCPP-O_2]^+$ (IN1) is formed by the coordination of the thiol substrate and $O_2$ to the iron center. [8] This intermediate is assigned as a low-spin species, confirmed by low-temperature Raman spectrometry where the oxidation and spin-state marker bands $\nu_4$ and $\nu_2$ blue-shift from 1357 to 1365 cm$^{-1}$ and 1552 to 1561 cm$^{-1}$ upon adding substrate 1a. Thiophenol and $O_2$ coordinate as axial ligands with adsorption energies of -1.76 eV and -0.85 eV, respectively. 

Axial oxygen coordination alters bond lengths: the $Fe-S$ bond length varies by 0.04 Å between the low-spin intermediate and its high-spin counterpart (IN1'), while the equatorial $Fe-N_{\text{pyr}}$ bond lengths are 2.00 Å for the low-spin IN1 and 2.06 Å for the high-spin IN1'. The introduction of competitive axial ligands can suppress this pathway. Using methanol as a solvent provides competitive axial coordination with a higher adsorption energy of -1.79 eV (compared to -1.76 eV for substrate 1a), which prevents substrate coordination and significantly reduces radical generation.

### Local Electronic And Structural Perturbations Under Coordinate Compression
In transition-metal-doped systems, macroscopic structural modifications under pressure alter local electronic behaviors and coordinate geometries. External pressure compresses the local coordination polyhedron of transition-metal dopants, reducing the metal-ligand bond length ($\Delta R$). This physical contraction modifies the local electrostatic potential and shifts the d-orbital overlap. 

For transition-metal-doped phosphors dominated by d–d transitions, this contraction strengthens the local ligand field and scales the crystal-field splitting parameter ($10Dq$). [9] Modest contractions of the metal-ligand coordinate sphere alter the excited-state potential energy surface, modulating the transition energy and causing either hypsochromic (blue) or bathochromic (red) spectral shifts. Compression enhances the orbital overlap between ligand p orbitals and the transition metal's valence d orbitals. This increases covalency and reduces inter-electronic repulsion, reflected in a decrease of the Racah parameters. This nephelauxetic contribution lowers the centroid energy of the excited d-orbital configuration, reducing the excited-state energy gap (such as the 5d–4f transition energy in lanthanide systems or specific d–d levels in Cr3+ octahedral centers) and driving a bathochromic shift.

### Electronic And Geometric Descriptors Of Stability In Transition Metal Alloys
The thermodynamic stability and renormalization energies of single-atom alloys (SAAs) in dimer versus monomer configurations are governed by d-band electronic structures and orbital coupling mechanics. According to tight-binding theory, the d-band width ($W$) of an active site is proportional to the total orbital coupling strength between the guest metal site and its neighboring host atoms. The coupling strength of each atom pair is positively correlated with the d-orbital radius ($r_d$) of the participating atoms. 

The d-band formation energy difference ($\Delta E_{d\text{-band}}$) between dimer and monomer configurations is modeled using the electronic-geometric descriptor:
$$-N_d^g (10 - N_d^g) r_d^g (r_d^g - r_d^h)$$
 [10]where $g$ and $h$ denote the guest and host metals, $N_d^g$ represents the number of d-electrons of the guest metal, and $r_d^g$ and $r_d^h$ are the d-orbital radii of the guest and host metals, respectively. This descriptor becomes highly negative, indicating a thermodynamic preference for dimer configurations, when the guest d-orbital occupancy $N_d^g$ approaches a half-filled shell ($N_d = 5$) and the guest d-orbital radius $r_d^g$ is maximized relative to the host radius $r_d^h$. This physical scenario is realized when rhenium (Re, $N_d = 5$) or osmium (Os, $N_d = 6$) serves as the guest metal in late transition metal hosts.

### Defect Tolerance In Binary Semiconductors
The electronic properties of crystalline materials exhibit varying sensitivity to native defects:
* In $TlI$ and $InI$ (with CsCl structures), iodine (anion) vacancies are shallow, exhibiting negative-U behavior where the $+1$ to $-1$ charge transition occurs inside the conduction band. [11]
* The shallow anion vacancy of $TlBr$ in the CsCl structure is driven by its cubic coordination and the symmetry properties of the p atomic orbitals making up the conduction band edge. In this 8-fold cubic coordination, the central atom's p orbitals point to the face centers rather than the vertices of the coordination cube, causing stronger orbital overlap between second neighbors and an almost exclusive cation nature near the conduction band edge.
* Site symmetry enforces weak interactions between defect-state-forming orbitals to keep them shallow. Ground-state $PbI_2$ has deep cation vacancies, but hypothetical cubic $PbI_2$ displays shallow vacancies due to the tetrahedral coordination of Pb and shorter bonds. [11]

### Mechanisms Of Negative Thermal Expansion
Negative thermal expansion (NTE) is categorized into structural and electronic mechanisms:
* Structural NTE: Driven by transverse vibrational motion in insulating, flexible framework-type materials containing vertex-sharing units (such as $ZrW_2O_8$ and $ScF_3$). [12,13]
* Electronic NTE: Driven by thermal changes in the interatomic bonding potential or magnetostriction, associated with phase transitions (such as in the Invar alloy $Fe_{0.64}Ni_{0.36}$ or hexagonal perovskites containing face-shared octahedra like $Ba_3BiRu_2O_9$, $Ba_3BiIr_2O_9$, and $Ba_4BiIr_3O_{12}$). [14,15]
* Uniaxial NTE in $BaIrO_3$: Displays negative linear thermal expansion along its face-shared $IrO_6$ trimers and zero volume thermal expansion below 100 K. This is driven by rigid-body phonon behavior governed by the effective trimer valence state, associated with a transfer of $1.0(1)$ charge across the magnetic ordering transition between 300 K and 10 K. [16]
* Superconducting NTE: Found in superconductors like $MgB_2$, $La_{1.85}Sr_{0.15}CuO_4$, and $NdFeAsO_{0.89}F_{0.11}$ below their critical temperatures ($T_c$). The physical cause is the loss of bonding electron density at the Fermi level due to electron-pairing. [17]

### Electronic Structure And Imperfections At Polyethylene Interfaces
Physical and chemical complexity at the Aluminum/Polyethylene (Al/PE) interface alters charge transport and injection barriers:
* Without imperfections, the computed charge injection barriers ($\phi_e$ and $\phi_h$) are approximately 4.0 eV, which is significantly higher than experimental values (1.00–2.14 eV). [18]
* Imperfections including chemical defects, physical disorders, interfacial polar groups, and polar bonds translate to trap states in the band gap, lowering the band gap value, shifting band edges, and reducing computed injection barriers to 0.0–2.0 eV.
* The interfacial dipole change ($\Delta\varphi$) is strongly affected by O-containing polar groups. For the $Al/PE + C-O-C_{ring}$ interface, $\Delta\varphi$ can reach up to -2.62 eV. [18] Parallel O-containing groups in the top two layers of the interface yield the most negative $\Delta\varphi$ values, whereas anti-parallel configurations yield the smallest $\Delta\varphi$. Electronegative oxygen in $Al/PE + O-C-O$ results in $\Delta\varphi \approx -0.5$ eV.

### Enzymatic Kinetics And Uniform Binding Limitations
According to transition-state theory, the reaction rate is proportional to the activation energy barrier $\Delta G^\ddagger$, representing the energy difference between the transition state and the substrate:
$$\text{Rate} \propto e^{-\frac{\Delta G^\ddagger}{RT}}$$
A protein or peptide catalyst ($U$) that exhibits uniform binding—the parallel stabilization of the substrate ($S$), the transition state ($S^\ddagger$), and the product ($P$) to the exact same degree—fails to accelerate the reaction beyond its uncatalyzed rate because the activation energy barrier remains unchanged. 

Negative catalysis alters reaction outcomes without requiring overall rate acceleration or product release by selectively not stabilizing, or actively destabilizing, the transition state corresponding to an undesired product pathway ($S_2^\ddagger$). A differential destabilization of $S_2^\ddagger$ by 1.4 kcal/mol yields a 10-fold reduction in the rate of $S$-to-$P_2$ conversion. A differential destabilization of $S_2^\ddagger$ by 2.8 kcal/mol yields a 100-fold reduction in the rate of $S$-to-$P_2$ conversion, [19] causing the desired product $P_1$ to predominate.

---

## Structural Mismatches And Geometric Representation Failures

### Modality Dimensionality And Structural Expressiveness
Common molecular representations are categorized across distinct dimensionalities:
* 1D Sequence-Based Encodings: Includes SMILES and SELFIES. Sequence-based representations enable the direct application of sequence-based neural architectures, such as recurrent neural networks (RNNs) and Transformers, without requiring precomputed 3D coordinates. They frequently fail to capture three-dimensional conformation changes and coordinate-dependent properties.
* 2D Topological Graphs: Capture the connectivity of the molecular structure (atoms as nodes and bonds as edges) without explicit spatial coordinates.
* 3D Geometric Conformations: Capture the explicit spatial coordinates and geometric structures of the molecule.
* Images and Expert-Crafted Features: Consist of 2D image depictions or statistical surrogates based on engineered molecular fingerprints, such as Extended-Connectivity Fingerprints (ECFP13 to ECFP15) and Avalon fingerprints. ECFPs enable millisecond-level inference per molecule.
* Multimodal Combinations: Modern architectures implement learned fusion of these representation types at the feature, latent, or decision level. The GraSeq architecture jointly trains SMILES and graph encoders to merge syntactic and connectivity patterns.

### Limitations Of Crystal Graph Convolutional Architectures In Periodicity Capture
Crystal graph neural networks (GNNs), such as the Crystal Graph Convolutional Neural Network (CGCNN), fail to capture the long-range periodicity of crystal lattices. When trained on a 1D carbon chain dataset consisting of random atomic spacings with periodic boundaries, CGCNN fails to reconstruct the lattice constants or detect long-range translational symmetries due to its reliance on local, coordinate-free edge definitions that do not preserve the periodic cell volume or the scaling of the unit cell under deformation.

### Geometric Coordination And Voronoi Tessellation Representation Shifts
Traditional GNN models typically assign atomic neighbors using simple radial cutoffs. This approach fails to capture complex, highly asymmetric coordination geometries found in oxides and intermetallic compounds. CGCNN struggles to predict Voronoi coordination numbers, which are mathematically defined by the relative areas of shared faces in a Voronoi polyhedron. The Atomistic Line Graph Neural Network (ALIGNN) captures Voronoi coordination numbers more effectively because it explicitly encodes three-body angular information ($\theta_{ijk}$) within its line graph transformation. The Improved Crystal Graph Convolutional Neural Network (iCGCNN) incorporates Voronoi tessellations and atomic correlations directly into its edge definition, yielding a 20% improvement in thermodynamic stability predictions compared to standard CGCNN. In materials representations such as the Orbital Field Matrix (OFM), atomic local environments are described using symmetry functions that capture coordinate-invariant geometries. The local atomic density around a central atom $i$ is modeled via a sum of Gaussian functions over neighboring atoms within a defined radial cutoff:
$$f_c(R_{ij})$$
where the cutoff function $f_c$ decays smoothly to zero at the boundary radius to preserve the locality of short-range interactions.

### Information Overestimation And Edge Bias In Band Gap Predictions
GNN architectures without explicit intermolecular edge modeling exhibit systematic error patterns when predicting electronic band gaps in molecular crystals. An error analysis of the MolGraph model reveals a negative error trend: it systematically overestimates smaller band gaps and underestimates larger band gaps. This bias is caused by missing information regarding intermolecular non-covalent interactions (such as van der Waals forces and hydrogen bonding), which reduce the band gap by broadening the valence and conduction bands. This negative error trend is resolved by CrystGraph, which constructs a multi-edge crystal graph capturing both intramolecular and intermolecular contacts. CrystGraph defines edges using varying neighbor search radii ($r = 8$ Å) and maximum neighbor thresholds ($max\_n = 6$ for simple crystal graphs; $max\_n = 12$ for medium crystal graphs; and higher thresholds for complicated crystal graphs).

### Multi Task Generalization Limits
In multi-task learning, the naive addition of source tasks often degrades model performance on the target task. This degradation is tied to the complexity of the hypothesis class, quantified mathematically using Vapnik-Chervonenkis (VC) dimension and Rademacher complexity. In the Multi-Assay Conformal Prediction / Random Forest (MACP/RF) framework, predicting target endpoints utilizes a combination of chemical descriptors (fingerprints and physicochemical descriptors) and predictions from 373 bioactivity models. Integrating these predicted bioactivities yields divergent performance gains: Genotoxicity Models F1 score increased from 0.61 to 0.70; Cardiological Models F1 score increased from 0.72 to 0.82; Hepatic Models performance was not improved. [20] In attention-driven Mixture-of-Experts (MoE) architectures like ALipSol, complex endpoints (lipophilicity $\log D$ and aqueous solubility $\log S_w$) are decomposed into simpler physical subproblems: acidic $pK_a$, basic $pK_a$, and $\log P$. Specific expert GNN networks are pretrained on these subproblems.

---

## Mathematical Formulations For Latent Space Discrepancy And Domain Adaptation

### Metric Formulations For Domain Discrepancy
Domain adaptation (DA) attempts to map data from a source domain $D_S = (\mathcal{X}, P_{S})$ and a target domain $D_T = (\mathcal{X}, P_{T})$ (where $P_{S} \neq P_{T}$) into a shared latent space via a transformation $T$ such that $T(x^{(P_S)}) \sim T(x^{(P_T)})$.

The empirical $\mathcal{H}$-distance between empirical distributions $\hat{P}_S$ and $\hat{P}_T$ over samples of size $n$ and $m$ is defined as:
$$d_{\mathcal{H}}(\hat{P}_S, \hat{P}_T) = 2 \left( 1 - \min_{h \in \mathcal{H}} \left( \frac{1}{n} \sum_{i=1}^{n} \log(1 - h(\mathbf{x}_i^{(P_S)})) + \frac{1}{m} \sum_{j=1}^{m} \log h(\mathbf{x}_j^{(P_T)}) \right) \right)$$
where $h$ is a binary classifier trained to identify the domain of the latent representations.

The squared empirical Maximum Mean Discrepancy (MMD) is expressed as:
$$\text{MMD}^2(\hat{P}_S, \hat{P}_T) = \frac{1}{n^2} \sum_{i=1}^{n} \sum_{j=1}^{n} k(\mathbf{x}_i^{(P_S)}, \mathbf{x}_j^{(P_S)}) + \frac{1}{m^2} \sum_{i=1}^{m} \sum_{j=1}^{m} k(\mathbf{x}_i^{(P_T)}, \mathbf{x}_j^{(P_T)}) - \frac{2}{nm} \sum_{i=1}^{n} \sum_{j=1}^{m} k(\mathbf{x}_i^{(P_S)}, \mathbf{x}_j^{(P_T)})$$
Multi-Kernel MMD (MK-MMD) integrates multiple kernel functions. Margin Discrepancy (MDD) utilizes asymmetric margin loss and minimax optimization. 

The $p$-th Wasserstein distance calculates the minimum cost of transporting probability mass between distributions. The empirical formulation for discrete samples is:
$$W_p(\hat{P}_S, \hat{P}_T)^p = \sum_{i=1}^{n} \sum_{j=1}^{m} \gamma_{ij}^{\star} \|\mathbf{x}_i^{(P_S)} - \mathbf{x}_j^{(P_T)}\|_2^p$$
where $\gamma^{\star}$ is the optimal transport plan solving the discrete Monge-Kantorovich problem. In Wasserstein Distance Learns Domain Invariant Feature Representations (WDLFR), the empirical Wasserstein distance is estimated by training an optimal domain discriminator in an adversarial manner against a feature extractor network to enforce domain invariance. 

Under the Wasserstein-1 ($W_1$) metric, size generalization and domain transfer can be analyzed theoretically. For a supervised learning task where the loss function $\ell$ is bounded by $M$ and $c_\ell$-Lipschitz, and the learned hypothesis $A_s$ is $c_s$-Lipschitz, if the empirical sampling $S_n$ converges at rate $R(n)$ in expectation, then:
$$W_1(\mu, \mu_n) \le R(n) \quad \text{as } n \to \infty$$

### Graph Discrepancy Via Weisfeiler Lehman Subgraphs
For non-IID graph transfer learning under evolving domains, Weisfeiler-Lehman (WL) subgraphs are constructed at each timestamp. The dynamic p-Wasserstein distance ($W_p$, where $p \ge 1$) on graphs measures the discrepancy of these graph representations. Based on the graph discrepancy $d_{GSD}$ derived from $W_p$, the error difference between a source domain $\mu$ and a target domain $\nu$ for a node classifier $h$ is bounded by:
$$| \epsilon_\mu(h) - \epsilon_\nu(h) | \le \rho \sqrt[p]{R^2 + 1} W_p(D_\mu, D_\nu)$$
where $R$ and $\rho$ represent the respective Lipschitz constants of the loss and hypothesis functions.

### Multi Source Domain Adaptation And Density Shifts
When the source domain is heterogeneous, it is modeled as $N$ distinct source distributions $P_{S_1}, P_{S_2}, \dots, P_{S_N}$. MSDA must resolve both domain-to-target shifts and inter-domain shifts. When establishing generalization bounds under smoothness conditions, a double exponential dependency arises in the bounding constant $C$ relative to the derivatives of the density functions:
$$c_{\infty} \geq \|\log p\|_{\infty} \quad \text{and} \quad c_r \geq \|\partial^m_{x_i} \log p_i\|_{L_2}$$
This double exponential dependency weakens when considering a higher number of derivatives $r$ or higher-order dimensions $m$.

### Regularization And The Balancing Principle
Domain adaptation algorithms typically minimize a joint objective balancing source task error and domain discrepancy:
$$\min_{f, \phi} \mathcal{L}_{\text{task}}(f(\phi(X_S)), Y_S) + \alpha \cdot d(\phi(X_S), \phi(X_T))$$
where $d$ is a distance measure, $\phi$ is the feature encoder, $f$ is the task predictor, and $\alpha \in [0, \infty)$ is a regularization parameter. The Balancing Principle for Domain Adaptation (BPDA) balances learning errors and domain distances. Target error bounds are represented as:
$$\epsilon_T(f) \leq D(\alpha) + E(\alpha)$$
where $D(\alpha)$ represents the domain distance in the latent space and $E(\alpha)$ represents the computable learning errors, bounded by a constant $B > 0$.

### Correlation Alignment
Correlation Alignment (CORAL) minimizes the discrepancy, measured by the Frobenius norm, between the covariance matrices of the source ($C_S$) and target ($C_T$) domains:
$$\min \|C_S - C_T\|_F^2$$
The Frobenius norm of a matrix $A$ is defined as:
$$\|A\|_F = \sqrt{\sum_{i,j} A_{i,j}^2}$$

### Sliced And Projected Wasserstein Metrics
Sliced Wasserstein (SW) metrics project high-dimensional distributions onto one-dimensional subspaces. Linear Merging Projection (LMP) identifies projections that minimize the between-class scatter matrix ($S_B$). The LMP projection vector $w \in \mathbb{R}^d$ is obtained by solving:
$$\min_{w} w^T S_B w \quad \text{subject to} \quad \|w\| = 1$$
which yields the eigenvalue problem:
$$S_B w = \lambda w$$
The optimal projection direction $w$ is the eigenvector associated with the smallest non-zero eigenvalue $\lambda$.

### Task Similarity And Embeddings
Task-level distances can be quantified using architecture-dependent task embeddings:
* Task2Vec: Summarizes a task as a vector by taking the diagonal of the Fisher Information Matrix (FIM) of network parameters. The FIM is computed as:
$$F_{ii} = \mathbb{E}\left[ \left( \frac{\partial \log p(y|x, \theta)}{\partial \theta_i} \right)^2 \right]$$
* MoTSE: Extracts features through an Attribution Method and Molecular Representation Similarity Analysis (MRSA).

### Fused Gromov Wasserstein Formulations
The Gromov-Wasserstein (GW) distance evaluates how well intra-domain relational structures are preserved under a soft alignment $\Gamma$ between two metric measure spaces $(X, d_X, \mu_X)$ and $(Y, d_Y, \mu_Y)$:
$$\text{GW}_p^p(\mu_X, \mu_Y) = \inf_{\pi \in \Pi(\mu_X, \mu_Y)} \int_{X \times Y} \int_{X \times Y} |d_X(x, x') - d_Y(y, y')|^p d\pi(x, y) d\pi(x', y')$$
Fused Gromov-Wasserstein (FGW) distance compares unregistered probability distributions on different product metric spaces, combining local node feature alignment (Wasserstein distance) with structural topology alignment (Gromov-Wasserstein distance):
$$\text{FGW}_\alpha(\mu_X, \mu_Y) = \inf_{\pi \in \Pi(\mu_X, \mu_Y)} \int_{X \times Y} \int_{X \times Y} \left( (1-\alpha)\|f_X(x) - f_Y(y)\|^2 + \alpha |C(x, x') - d_Y(y, y')|^2 \right) d\pi(x, y) d\pi(x', y')$$
where $\alpha$ balances local feature-level and global structural alignment. The FGW-CLIP framework utilizes FGW to align enzyme and reaction representation spaces.

---

## Architecture Of Selective Transfer Mixture Of Experts And Gating

### Sparse Gating Mechanisms And Mathematical Foundations
For an input vector $\mathbf{x}$, the final layer output $\mathbf{y}$ of a sparsely-gated Mixture of Experts (MoE) is defined as a weighted combination of $N$ independent expert networks:
$$\mathbf{y} = \sum_{i=1}^{N} G(\mathbf{x})_i E_i(\mathbf{x})$$
where $E_i(\mathbf{x})$ represents the output of the $i$-th expert network, and $G(\mathbf{x})$ is a gating or routing network. The gating network projects an input token $x \in \mathbb{R}^d$ using a trainable weight matrix $W_g \in \mathbb{R}^{d \times N}$:
$$H = x \cdot W_g$$
The raw logits $H$ are converted into a probability distribution:
$$g(x) = \text{softmax}(H) = \frac{\exp(H_i)}{\sum_{j=1}^{N} \exp(H_j)}$$
To enforce sparse computation, a top-$k$ selection mechanism restricts activation to the top-$k$ experts:
$$G(\mathbf{x}) = \text{Softmax}(\text{KeepTopK}(\mathbf{h}(\mathbf{x}) + \mathbf{\epsilon}, k))$$
where $\mathbf{\epsilon}$ represents a noise term drawn from a uniform distribution $\text{Unif}[0,1]$ or normal distribution. Optimization objectives integrate a load-balancing auxiliary loss combined with a $z$-loss to prevent lazy gate networks. The AntMoE framework implements an expert regularization loss composed of an orthogonal loss, an expert balance loss, and a stability loss.

### Hierarchical And Sequential Gating Networks
In Hierarchical Mixtures of Experts (HMEs), the overall system output is computed recursively as:
$$P(\mathbf{y} \mid \mathbf{x}) = \sum_{j} g_j(\mathbf{x}) \sum_{k} g_{k \mid j}(\mathbf{x}) P_k(\mathbf{y} \mid \mathbf{x}, \mathbf{\theta}_{jk})$$
where $g_j(\mathbf{x})$ is the high-level gating coefficient, $g_{k \mid j}(\mathbf{x})$ is the conditional gating coefficient at the next level, and $P_k$ represents the output model of the leaf expert. The COMET sparse gate implements a tree-based routing mechanism. Neural Bayesian Sequential Routing (NBSR) models inference as an active traversal over a hierarchical Directed Acyclic Graph (DAG), coupling the Bayesian belief update with a Gumbel-Softmax Straight-Through estimator.

### Evidential Deep Learning And Dirichlet Modeling
Evidential Deep Learning (EDL) maps input feature vectors to class-specific logits, yielding evidence values converted into Dirichlet concentration parameters. The spread of the Dirichlet distribution represents epistemic uncertainty, while the mean represents aleatoric uncertainty. Strategies include Variational Inference over Latent Mixtures and Method of Moments Ensemble Construction. The Uncertainty-aware Mixture of Experts (uMoE) framework targets aleatoric uncertainty by partitioning the uncertain input space into manageable subspaces.

### Rejection Policies And Epistemic Uncertainty Routing
Selective prediction frameworks utilize consensus confidence and internal disagreement (variance). The Dynamic Ensembles Gating for REjection (DEGRE) framework trains a lightweight gating network on ensemble signals, achieving an average risk-coverage (AURC) reduction of 68.2% compared to standard ensemble baselines. [22] Uncertainty estimation uses the SNR derived from the means ($\mu$) and standard deviations ($\sigma$) of class probability distributions from Bayesian model averaging (BMA) approximations. The adjusted probability distribution $\tilde{p}_{m,k}$ uses a sensitivity adjustment $k$:
$$\text{When } k\sigma(y) \ll \mu(y), \quad \Gamma_k(y) \rightarrow 1 \quad \text{and} \quad \tilde{p}_{m,k} \approx p$$
The Curiosity-Driven Quantized Mixture-of-Experts routes inputs based on Bayesian epistemic uncertainty across heterogeneous experts (BitNet ternary, 1-to-16 bit BitLinear). On ESC-50, Quinn, and UrbanSound8K, 4-bit quantization maintains 99.9% of full-precision F1-score performance (0.858 compared to 0.859 for full precision) with a 4x compression ratio and 31% energy savings compared to 8-bit quantization. [23] On the Quinn dataset, the F1-score increased from 0.802 to 0.809, while cross-fold variance dropped by 85%. [24] The Leave One Expert Out (LEO) architecture utilizes a designated null expert representing the prior belief and employs Intrinsic Cross-Validation (ICV).

### Gaussian Process And Infinite Expert Architectures
The Infinite Mixture of Gaussian Process Experts (IMoGPE) uses a Dirichlet Process (DP). Each GP expert learns localized functional characteristics defined with a stationary Gaussian covariance function:
$$\theta = \{ \text{length scales } (l), \text{ signal variance } (\sigma_f^2), \text{ noise variance } (\sigma_n^2) \}$$
The nested Sequential Monte Carlo (SMC2) sampler framework updates gating parameters and GP hyperparameters simultaneously. The Gaussian Process-Gated Hierarchical Mixture of Experts (GPHME) constructs gating functions using GPs based on random features. The Ultra-fast Deep Mixture of Gaussian Process Experts framework designs the gating network using a deep neural network (DNN) with methods including Cluster-Classify-Regress (CCR), CCR-Markov Model (CCR-MM), and Markov Model-Markov Model (MM-MM).

### Dynamic Expert Specialization And Catastrophic Forgetting Prevention
The Dynamic Expert Specialization (DES-MoE) framework achieves expert isolation through an Adaptive Router, Real-Time Expert-Domain Correlation Mapping, and a Three-Phase Adaptive Fine-Tuning Schedule. Across six domains, DES-MoE reduced catastrophic forgetting by 89% compared to full fine-tuning as domains scaled from 2 to 6, and achieved 68% faster convergence. [25]

### Spectral Graph Alignment And Domain Adaptation
The BRIDGE framework aligns multi-domain graph features using domain-invariant aligners. The Frequency Aware Contrastive Graph Network (FracNet) integrates contrastive learning with Maximum Mean Discrepancy (MMD) metrics. Spectral Augmentation for Graph Domain Adaptation (SA-GDA) aligns category feature spaces in the spectral domain. In source-free graph domain adaptation, the Rank and Align (RNA) framework transfers knowledge using only the source model. Homophily-Agnostic Reconstructing Structure processes heterophily and homophily representations, utilizing Scaled Cosine Error with sharpening parameter $\beta \ge 1$:
$$L_{RE} = \sum_{i=1}^N \left(1 - \frac{Z_i^\top \bar{Z}_i}{\|Z_i\| \cdot \|\bar{Z}_i\|}\right)^\beta$$
Latent space misalignment is resolved by computing the normalized graph Laplacian:
$$\mathbf{L} = \mathbf{I} - \mathbf{D}^{-\frac{1}{2}} \mathbf{A} \mathbf{D}^{-\frac{1}{2}}$$
Descriptors are projected onto the reduced spectral subspace to obtain spectral coefficients:
$$\hat{\mathbf{F}}_1 = \Phi_1^{\top} \mathbf{F}_1, \quad \hat{\mathbf{F}}_2 = \Phi_2^{\top} \mathbf{F}_2$$
A functional map $\mathbf{C}_{12} \in \mathbb{R}^{r \times r}$ is estimated under bijectivity and orthogonality constraints, followed by greedy matching via cosine similarity $\mathbf{S} = \hat{\mathbf{Z}}_s \hat{\mathbf{Z}}_t^{\top}$.

### Optimal Transport And Cross Modality Alignment
Unbalanced Optimal Transport (UOT) is employed in scOT-LT and SCOT. Cross-modal alignment is optimized using a hybrid cost matrix $\mathbf{C}$:
$$\mathbf{C}_{ij} = \text{Distance}(\mathbf{z}_i, \mathbf{z}_j) + \beta \text{SemanticLoss}(\mathbf{y}_i, \hat{\mathbf{y}}_j)$$

### Unsupervised Test Time Adaptation And Meta Distillation
The Meta-Distillation of Mixture-of-Experts (Meta-DMoE) framework uses bi-level optimization as a meta-learning strategy to train a transformer-based aggregator. In multi-source transfer learning using a pre-trained BERT model, combining deterministic one-hot encoding of the source dataset with data augmentation resolved out-of-domain interference, raising the baseline F1 score from 48.43 to 52.07. [21] The MoE for Open Set Domain Adaptation (OSDA) framework utilizes Dual-Space Detection and a Graph Router.

### Routing Manifold Alignment And Gating Regularization
Routing Manifold Alignment (RoMA) introduces a manifold alignment loss term alongside the task-specific prediction loss to encourage intermediate routing weights to align with those of topologically or chemically similar successful neighbors in the task embedding space.

### Topological And Multiscale Structured Graph Experts
TopExpert specializes experts to handle distinct topological groups using an MLP combined with Gumbel-Softmax. The Multiscale Interaction Mixture of Experts (MI-MoE) framework operates on molecular interaction graphs $\mathcal{G}^{(c_k)} = (\mathcal{V}, \mathcal{E}^{(c_k)}, \mathbf{R})$ induced by distinct spatial distance cutoffs $c_k$:
$$\mathcal{G}^{(c_k)} = \left\{ \mathcal{G}^{(c_k)} = (\mathcal{V}, \mathcal{E}^{(c_k)}, \mathbf{R}); \quad k=1, \dots, K \right\}$$
The node features at layer $L$ are aggregated via a readout function:
$$\mathbf{h}_{\mathcal{G}^{(c_k)}} = \text{READOUT}\left( \left\{ \mathbf{h}_i^{(L)} \mid i \in \mathcal{V} \right\} \right)$$
HierMolMoE implements a hierarchical MoE operating at atom-level, motif-level, and global-level experts, routing based on scaffold similarity. The Expert-Guided Substructure Information Bottleneck (ESIB-Mol) framework leverages the Information Bottleneck principle.

### Molecular Representation Fusion And Multitask Learning
MoL-MoE (and Mol-MVMoE) integrates SMILES, SELFIES, and molecular graphs utilizing 12 experts. Multitask Neural Networks (MTNNs) use MoE architectures for cardiotoxicity assessment. The SMI-TED family scales from a 289 million parameter base variant (SMI-TED289M) to a Mixture-of-Experts variant (MoE-OSMI) scaling to 8x289 million parameters. [26] Analysis shows near-perfect linear relationships between functional group families (R² = 0.99, MSE = 0.002) and preserves high accuracy on reaction yield predictions with 2.5% fine-tuning data. Knowledge-directed Expert Merging (KDEM) and Parameter-projection Expert Merging (PPEM) merge weights of top-2 or top-3 experts, achieving 5.27% and 4.35% improvement in recall on the Link2 dataset group. [27] The GRAVER framework utilizes graphon-based generative experts and a Mixture-of-Experts/Co-Expert (MoE-CoE) routing mechanism.

### Chemical Reaction Outcome Prediction And Retrosynthetic Translation
The Sequential Mixture-of-Experts approach applies a dropout strategy to each expert to increase electron redistribution diversity. RetroMoE frames retrosynthesis as a latent translation problem utilizing a non-symmetric variational autoencoder (VAE) and a Mixture-of-Experts translation network. The Uncertainty-Aware Multimodal (UAM) yield prediction model implements MoE layers on the Buchwald-Hartwig High-Throughput Experimentation (HTE) dataset. Ablation of the MoE module results in an approximate 10% performance drop.

### Biomolecular Interaction Modeling And Spectroscopic Identification
For classifying materials from X-ray diffraction (XRD) spectra, an MoE ensemble uses 73 expert models tailored to 73 general chemical elements (excluding radioactive elements and noble gases, and avoiding direct conditioning on hydrogen and oxygen). This ensemble scales spectroscopic identification to 136,899 distinct classes, achieving a top-1 accuracy of 98%. [28] The Biomolecular Interaction Transformer (BIT) implements a dual MoE formulation: Mixture-of-Domain-Experts (MoDE) and Mixture-of-Structure-Experts (MoSE). ConPLex predicts drug-target interactions using supervised contrastive learning. The ALipSol architecture is a multi-task, attention-driven MoE model. It sums the individual expert embeddings $h_i \in \mathbb{R}^{200}$ to initialize the task embedding $h_{t1} \in \mathbb{R}^{200}$. Each expert-task pair is concatenated to calculate a dynamic alignment score $s = \text{Align}(h_i, h_{t1})$. The ALipSol+ variant averages predictions of two independent MoE architectures. A two-stage Bayesian framework concatenates sampled classification probability $\hat{p}_c(i)$ with the molecular representation $x$:
$$x_{\text{aug}} = [x, \hat{p}_c(i)]$$

### Spatial Domain Partitioning In Interatomic Potentials
The Mixture of Crystal Expert (MoCE) combines an SE(3)-invariant module, an SO(3)-invariant module, and a dynamic graph module. The Multi-view Graph Transformer (MGT) achieved up to a 14% reduction in Mean Absolute Error (MAE) compared to state-of-the-art crystal property benchmarks, and performance improvements of up to 58% over baseline models in transfer learning. [29] An E(3)-equivariant Allegro architecture uses a high-fidelity expert for complex regions and a low-fidelity expert for simpler regions.
MoE-SVD compresses expert weights:
$$\mathbf{W}_i \approx \mathbf{U}_i \mathbf{\Sigma}_i \mathbf{V}_i^{\top}$$
RS-MoE compresses layers by decomposing the weight matrix into a low-rank component and a sparse component:
$$\mathbf{W}_i = \mathbf{L}_i + \mathbf{S}_i$$

### Routing Mechanics And Instability In Mixture Of Experts
Sparse MoE models are highly sensitive to routing instability and representation collapse. The Grouter method distills routing structures from fully-trained MoE models to serve as a fixed router. The AMRO-S architecture leverages a supervised fine-tuned small language model for intent inference.

### Source Gated Transfer Versus Monolithic Models
Source-gated transfer frameworks use Graph Isomorphism Network with Edge features (GINE) encoders pretrained on a specific supervised quantum chemical source task (from the QM9 dataset).

---

## Conformal Prediction Calibration And Uncertainty Quantification

### Foundations Of Conformal Prediction And Exchangeability
Given a significance level $\alpha \in (0,1)$, a conformal predictor outputs a prediction set $C(X)$ for a query $X$ such that the true label $Y$ is contained within the set with a probability of at least $1-\alpha$:
$$P(Y \in C(X)) \ge 1-\alpha$$
These guarantees hold under the assumption of exchangeability. For regression tasks, a common nonconformity score is the absolute residual:
$$s(X, y) = |y - \hat{\mu}(X)|$$
For classification tasks, the inverse probability score (hinge score) is:
$$s(X, y) = 1 - \hat{P}(Y=y \mid X)$$

### Inductive And Transductive Conformal Prediction
Transductive (Full) Conformal Prediction (TCP) utilizes the entire dataset without requiring a separate calibration set but requires retraining the underlying model twice for each test point. Inductive Conformal Prediction (ICP) requires dividing the available data into a proper training set (70–80%) and a calibration set (10–15%).

### Multidimensional And Conjugate Conformal Prediction
Multidimensional conformal prediction utilizes nonconformity scores taking vector values in $\mathbb{R}^d$. Conjugate conformal prediction establishes acceptance sets determined by vector-valued test statistics.

### Weighted Conformal Prediction And Density Ratio Estimation
Weighted split-conformal prediction threshold is defined as a weighted quantile:
$$\hat{q} = \text{Quantile}_{1-\alpha} \left( \sum_{i=1}^{n} w_i \delta_{s(X_i, Y_i)} + w_{n+1} \delta_{+\infty} \right)$$
where the weights $w_i \propto f_{\tilde{X}}(X_i) / f_X(X_i)$. Clipped Least-Squares Importance Fitting (CLISF) reduces variance. Coverage Target Inflation corrects empirical undercoverage with an inflated target coverage level:
$$1 - \alpha + \hat{\Delta}_B$$

### Covariate And Label Shifts With Density Ratio Corrections
Under label shift, conformal scores are weighted using marginal label probability ratios:
$$w(y) = \frac{P_{\tilde{Y}}(y)}{P_Y(y)}$$
The 1-Wasserstein distance requires sorting with a computational complexity of $\mathcal{O}((m+n) \log(m+n))$, while fitting a Gaussian Kernel Density Estimate (KDE) on $n$ calibration samples incurs a computational cost of $\mathcal{O}(k \cdot n)$. Target domain coverage is guaranteed asymptotically as long as the transferability level is bounded by a drift parameter $h$:
$$\|P^{(k)}(Y^{(k)}|X^{(k)}) - Q(Y^{(k)}|X^{(k)})\|_{\infty} \le h$$

### Feedback Covariate Shift In Iterative Biomolecular Design
Under Feedback Covariate Shift (FCS), the test data are statistically dependent on the training data. If $P_X^D$ is absolutely continuous with respect to $P_X$, the full conformal confidence set $C_{\text{FCS}}$ satisfies:
$$P(Y \in C_{\text{FCS}}(X)) \ge 1 - \alpha$$

### Domain Shift Aware Conformal Prediction
Domain-Shift-Aware Conformal Prediction (DS-CP) uses a regularization parameter $\lambda$ that controls the trade-off between conservativeness and adaptivity. Randomly Localized Conformal Prediction (RLCP) provides relaxed local coverage guarantees.

### Transductive Split Conformal Adaptation
Conf-OT operates jointly over the combined calibration and query sets, improving set efficiency by up to 20% and executing up to 15 times faster. Transductive Split Conformal Adaptation (SCA-T) regularizes marginal data distributions, improving set efficiency by nearly 18% and conditional coverage by 7% to 18%. [30]

### Multi Distribution Robust Conformal Prediction
Multi-Distribution Robust Conformal Prediction (MDCP) constructs a prediction set that is uniformly valid across multiple source distributions without observing the test point's specific source membership at inference time.

### Multi Source Conformal Inference With Missing Outcomes
Under missing outcomes ($R \perp\perp Y \mid T, X$ under Missing at Random and positivity $P[P[R = 1 \mid T, X] \ge \epsilon] = 1$), efficient influence functions are derived, achieving parametric rates of convergence:
$$P(Y \in \hat{C}_\alpha(X) \mid T = 0, R = 0) \ge 1 - \alpha$$

### Foundations Of Conformal Risk Control
Conformal Risk Control (CRC) generalizes split conformal prediction to control the expected value of any bounded, monotone loss function:
$$\mathbb{E}[L_{n+1}(\hat{\lambda})] \le \alpha$$
CRC calibrates a decision threshold $\lambda$ on a holdout calibration set $D_{\text{cal}} = \{(X_i^c, Y_i^c)\}_{i=1}^{n_c}$ to guarantee:
$$\mathbb{E}[L(\mathcal{C}_{\lambda}(X_{\text{test}}), Y_{\text{test}})] \le \alpha$$
The prediction set is constructed as:
$$C_\lambda(X) = \{k \in \mathcal{Y} : f_k(X) \ge \lambda\}$$

### Certification Bounds And The Impossibility Of Calibration
Analytical bounds form a certification hierarchy:
$$\text{Hoeffding} \subseteq \text{Bernstein} \subseteq e\text{-CRC}$$
Moving from a Hoeffding to a Bernstein bound recovers 37% more valid certifications in low-variance regimes. The Impossibility Bound states that if the base risk $\mu$ exceeds the target risk threshold $\alpha$, no distribution-free method can certify predictions without abstaining on at least:
$$\frac{\mu - \alpha}{1 - \alpha}$$
Adaptive Conformal Inference (ACI) updates the decision threshold dynamically at each step $t$ via $\gamma_t > 0$.

### Certified Domain Consistency And Retrieval Control
Certified Domain-Consistency for Multi-Domain Retrieval ($C^3R$) employs a two-split conformal scheme to bound the domain router's error rates and calibrate a demotion threshold. Sem-CRC applies semantically adaptive risk control to CT denoising and segmentation.

### Deferral Policies And Expert Routing
The Conformal Deferral Rule defers decisions when $|\Gamma_\alpha(x)| > 1$ to the expert with the highest segregativity score ($\varsigma_k$). This reduces the training labels required per expert by up to 91.3%. [31] CP-Router introduces the Full and Binary Entropy (FBE) criterion.

### Cost Asymmetric High Stakes Decision Making
Conformal Non-Coverage Risk Control (CNCRC) bounds both non-coverage risk and ambiguity risk. Theoretical analysis of conformal calibration under non-adversarial, contaminated reference data yields conservative type I error control causing a loss in statistical power.

### Biological And Medical Applications Of Conformal Risk Control
CPEC provides function predictions with an empirical FDR of 0.03 at $\alpha = 0.1$ for sequences with identity as low as $[0, 30\%)$. [32] ALLCoP reduces the FNR of the ALLIUM classifier from 8.95% to 3.5% and decreases empty predictions from 37% to 17% at tolerances of 7.5% to 30%. [33]

### Conformal Selective Borrowing And Hybrid Clinical Trials
The Conformal Selective Borrowing (CSB) estimator is formulated as:
$$\hat{\tau}_{\gamma} = \frac{1}{n_R} \sum_{i=1}^{n} S_i \hat{\mu}_{1,R}(X_i) + S_i \frac{A_i}{\hat{e}(X_i)} \{Y_i - \hat{\mu}_{1,R}(X_i)\} - S_i \hat{\mu}_{0,R+\hat{\mathcal{E}}(\gamma)}(X_i) - V_i \{Y_i - \hat{\mu}_{0,R+\hat{\mathcal{E}}(\gamma)}(X_i)\}$$
The selected subset of ECs is defined as $\hat{\mathcal{E}}_{\rm CSB}(\gamma) = \{i : p_i > \gamma\}$. When $\gamma = 1$, no ECs are borrowed ($\hat{\tau}_1 \equiv \hat{\tau}_R$). When $\gamma = 0$, all ECs are borrowed ($\hat{\tau}_0 = \hat{\tau}_{R+E}$). In trial simulations, CSB performance was: Estimate = 0.138 (or 0.236), SE = 0.058 (or 0.062), 95% CI = (0.024, 0.252) or (0.114, 0.359), Asymptotic p-value = 0.018 or < 0.001, Type I Error = 0.046 or 0.028, Borrowed ECs = 264. The intFRT R package provides implementation with the lungcancer dataset.

### Mixture Of Experts Conformal Prediction Architecture
In MoE-CP, the prediction of the MoE model is represented as:
$$\hat{\mu}(X) = \sum_{k} \pi_k(X) \mu_k(X)$$
Calibration residuals are weighted according to gating vector similarity:
$$w_i(x_{n+1}) = \text{Similarity}(\pi_K(\mathbf{x}_i), \pi_K(\mathbf{x}_{\text{test}}))$$
The prediction interval $\hat{C}^{MoE}_n(X_{n+1})$ is formulated as:
$$\hat{C}^{MoE}_n(X_{n+1}) = \left\{ y \in \mathbb{R} : |y - \hat{\mu}(X_{n+1})| \le Q_{1-\alpha}\left( \sum_{i=1}^n \tilde{w}_i \delta_{S_i} + \tilde{w}_{n+1}\delta_{+\infty} \right) \right\}$$

### Expert Routing And Conformal Gating Algorithms
TESSERA optimizes the Coverage-Width Criterion (CWC) and minimizes the Area Under the Sparsification Error (AUSE), evaluated via Size-Stratified Coverage (SSC) with $J \in \{3, 5, 10\}$ bins, achieving near-nominal coverage ($1-\alpha = 0.90$). MoGU correlates calibrated uncertainty estimates with empirical error ($p < 10^{-5}$). EnsDTI integrates experts and an independent ICP module, achieving a 2.7% accuracy improvement over baselines.

### Multimodal Architectures And Hazardous Chemical Prediction
HazChemNet processes a 516-length vector (512-bit fingerprint and 4 descriptors) from 2428 hazardous compounds, achieving 92.3% accuracy for hazardous and 84.6% for non-hazardous classifications on 52 unseen chemicals. [34]

### Conformal Active Learning And Candidate Set Query
The CoPAL algorithm uses CP-derived uncertainty for remaining useful life estimation. The Candidate Set Query (CSQ) framework achieved a 42% to 48% reduction in labeling cost on the ImageNet64x64 benchmark. [35,36] Conformalized UCB directs search using:
$$\text{Acquisition}(x) = \hat{\mu}(x) + \beta \cdot \text{Width}_{\text{Conformal}}(x)$$

### Conformal Prediction In Cheminformatics And QSAR Modeling
Efficiency of QSAR conformal regressors is calculated as:
$$\text{Efficiency Ratio} = \frac{\text{Width of Raw Conformal Interval}}{\text{Width of Interval in No-Model Case}}$$

### Handling Class Imbalance With Mondrian Conformal Prediction
Mondrian (class-conditional) conformal prediction computes thresholds independently. A test compound is assigned to Active Only, Inactive Only, Both, or Empty categories. On the ClinTox dataset, standard conformal prediction minority class coverage collapses to 4.2%. [37] Label Conditional Mondrian Conformal Prediction (LCMCP) and Mondrian Cross-Conformal Prediction (MCCP) ensure target coverage.

### Applicability Domain And Conformal Efficiency Metrics
Conformal efficiency metric evaluates the fraction of single-class label predictions ($\{0\}$ or $\{1\}$) at error rate $\epsilon = 0.05$. Distance-Based Conformal Prediction (DCP) scales interval width logarithmically:
$$\text{Interval Width} \propto \log(\text{Distance})$$
yielding a 4.7% to 7.3% coverage improvement over standard FCP. The Dynamic Applicability Domain (dAD) utilizes a dynamic calibration set specific to each compound-target pair. eMOSAIC achieved a 21.21% lower RMSE and a 23.72% higher Pearson correlation than the conformal baseline under scaffold splits. [38] AdaDetect controls the False Discovery Rate (FDR).

### Endocrine Disruption And Mutagenicity Screening
CP applied to endocrine activity screening across 14 hormone receptors for 55,000 chemicals quantified uncertainty at significance levels of 0.1, 0.15, 0.2, 0.25, and 0.3. Mondrian CP is used in mutagenicity modeling on the AMES test.

### Catalyst Discovery And Reaction Engineering
Catlas identifies 144 promising binary intermetallics from 947 surfaces. [39] Selectivity heatmaps indicate target adsorption energies of $0$ to $-0.75$ eV for $*{\rm OH}$ and $-1.25$ to $-1.75$ eV for $*{\rm CO}$. Machine learning models with CP predicted Suzuki cross-coupling reaction success with 10% to 25% greater accuracy than expert intuition (60% to 70% success rates). [40]

### Thermodynamic And Safety Property Estimation
In predicting Heat of Combustion for cyclic compounds, a hybrid routing system expanded the cyclic calibration set from 12 to 55 compounds and achieved an $R^2$ of 0.918 using Random Forest with DFT-derived descriptors, [41] while acyclic molecules used the base MPNN.

### Log Transformed Conformal Inference In Sparse Regimes
Log-transformed conformal prediction handles extreme heteroscedasticity of void swelling data:
$$s(X, y) = \left| \log(y) - \log(\hat{\mu}(X)) \right|$$

---

## Active Learning Bayesian Optimization And Sample Efficiency

### Quantification Of Sample Saving And Experimental Iteration Reductions
On the ltc_conc dataset, a TabPFN foundation-model surrogate combined with active learning yields a 29.4% saving in extra evaluation steps relative to a GP surrogate and a 35.4% saving relative to a Random Forest (RF) surrogate. [42] In targeted molecular searches, active learning achieves data savings of up to 64%. [43] 

Combining RL with AL (RL-AL) delivers a 5-fold to 66-fold increase in hits generated (up to 30,000 oracle calls, batch size 128 over 100,000 compounds) and a 4-fold to 64-fold reduction in computational time. [44] The discovered compounds display average MPO scores of 0.83 plus or minus 0.1 for ROCS and 0.7 plus or minus 0.14 for ADV docking, compared to RL baseline scores of 0.7 plus or minus 0.14 (ROCS) and 0.53 plus or minus 0.27 (ADV). Scaffold diversity was 0.251 plus or minus 0.018 and 0.286 plus or minus 0.005 for RL-AL compared to 0.178 plus or minus 0.003 and 0.162 plus or minus 0.002 for the baseline RL. 

In optimizing thermal stability across eight experimental parameters, BO converges within 25 experiments versus 128 for DoE. In solvation free energy prediction, theory-informed machine learning models at small data limits ($10^1$ to $10^2$ samples) reduce required training data size by more than 65%. 

In MOF alchemical adsorption simulations across 1800 MOFs, AL resulted in a 57.5% reduction in training data (from 5 million to 2.1 million). Combining alchemical adsorbates with 3445 MOFs yielded 99.8% data savings. [45] In AutoML benchmarks across 17 AL strategies and 9 datasets, uncertainty-driven strategies (LCMD, Tree-based-R) and diversity-hybrid strategies (RD-GS) outperformed heuristics (GSx, EGAL). QBC schemes achieve performance parity querying only 30% of the pool, providing a 70% to 95% reduction in labeling. For perovskite band gaps, querying 10% compressed the prediction MAE to 0.18 eV. [46]

### Virtual Screening And Hit Enrichment Metrics
Virtual screening active learning (VS-AL) recovers 42 ± 4.0% of hit SMILES for ROCS and 35 ± 4% for docking using 5,000 oracle calls (oracle-call-efficiency of 0.25% for ROCS and 2.54% for docking, a 7-fold to 11-fold improvement). VS-AL achieves 100% hit recovery after 8,927 ± 1,750 calls for ROCS, and 96% (~356 hits) after 30,000 calls for docking. 

A pretrained MoLFormer model identifies 58.97% of the top-50,000 compounds after exploring 0.6% of a 99.5 million compound library. On the Enamine HTS dataset at a 0.6% budget, D-MPNN achieves an 89.88% top-k retrieval rate, MolCLR 86.98%, LightGBM 82.5%, and RF 68.18%. [47] Reducing the batch size to 0.1% recovers 78.4% of the top-1,000 docking scores (enrichment factor of 131 vs 0.6% random baseline). The GLARE framework reports a 64.8% average improvement in Enrichment Factors and up to an 8-fold improvement in EF0.5% for DrugCLIP using 15 active molecules. [47] The ActiveDelta paired approach selects statistically more potent leads (p < 0.04) by the 200th iteration.

### Active Learning In High Class Imbalance And Specific Splits
For datasets with hit rates as low as 0.01% (up to 10,000-fold more inactive than active), the Gini index is calculated per active learning task across 20 repeated runs to quantify non-uniform selection. The muTOX-AL framework achieves 95% of supervised accuracy (target 80.52% from baseline 84.76%) using 24% of the training data on a 5,988-sample set. On the ONT barcode dataset, AL requires a 50% labeling amount; on the RNA type classification dataset, 15%.

For a cysteine protease dataset, using a GBM regressor and 1.5% batch steps with KNN SV or DVRL yielded statistically significant differences in active compound discovery rates (p = $1.07 \times 10^{-14}$). Deep learning models evaluated using the Dynamic Range Fraction (DRF) consistently outperform trivial baselines.

### Classical And Advanced Acquisition Formulations
Acquisition functions guide AL and BO campaigns by mapping posterior means $\mu(x)$ and variances $\sigma^2(x)$. The Expected Improvement (EI) metric evaluates:
$$(\mu(x) - f^*)\Phi(Z) + \sigma(x)\phi(Z)$$
Multipoint Probability of Optimality (qPO) maximizes the probability that a selected batch contains the global optimum:
$$\alpha_{\text{qPO}}(X_{\text{acq}}) = P\left(\bigcup_{x \in X_{\text{acq}}} \{x = x^*\}\right)$$
Causal Intervention Active Learning (CIAL) reduces the final-iteration Structural Hamming Distance (SHD) by 76.2% relative to EI baseline (p = 0.0036 for SHD, p < 0.001 for F1). Distilling chemical insights via LLM-EI improves optimization performance in 4 out of 6 datasets.

### Surrogate Model Topologies And Pretraining Dynamics
Deep Kernel Learning (DKL) pairs a neural network with a GP. For alchemical adsorption GPR models defined by $f \sim \text{GP}(m(x), K(x, x'))$ using the Rational Quadratic kernel, a GP mean uncertainty policy threshold of 0.05 mol kg^-1 outperforms a maximum relative error policy of 2%. Theory-Informed Machine Learning Potentials transferred from silicon to germanium achieve energy and force MAEs of 0.127 and 0.69 meV/Å on the source dataset.

### Batch Acquisition And Uncertainty Calibration Metrics
A low Area Under the Sparsification Error (AULSE) indicates precise calibration. A greedy algorithm selects a submatrix $C_B$ from $C$ to maximize the determinant:
$$\max \det(C_B)$$
A MoLFormer surrogate retrieves 81.58% of top-1,000 compounds using a 0.1% batch size compared to 75.9% using a 0.2% batch size after exploring 0.6% of 12,855 molecules.
For time-series AL, sampling terminates based on ErrThresh ($C_e$) or CostThresh ($K$ time-points). Similarity Search for Active Learning and Search (SEALS) restricts the candidate selection pool to nearest neighbors.

### Feature Space Mapping And Bias Constraints
In traditional t-SNE mapping, distances $W = (w_n)$ between center point $O$ and unlabeled samples are normalized and reversed:
$$W = 1 - \text{normalization}(W)$$
yielding biased pool $D_{\text{pool}}' = (x_n, w_n)_{1 \le n \le N}$.
In DEAL-TCN, a pool of 500 unlabeled points is generated across Temperature (1100–1500 K), Pressure (2–6 atm), and Feed ratio (1/25–1/15).
Margin-based uncertainty sampling minimizes the margin:
$$\text{Margin}(x) = P_\theta(y_1|x) - P_\theta(y_2|x)$$

### Active Transfer Learning And Strategic Sampling
Active Transfer Learning (ATL) in carbon-carbon cross-coupling (C(sp3)–C(sp3) between activated amines and carboxylic acids) improves reaction yields within three experimental batches. DeepReac+ implements diversity-based and adversary-based sampling strategies. ActiveDelta optimizes screening by training a surrogate on paired potency differences to identify the single most potent candidate. 

### Multi Task And Multi Fidelity Bayesian Optimization
Multi-Task Bayesian Optimization (MTBO) shares information across related tasks. Multi-Anchor Latent Transduction (MALT) generates an attention-weighted representation:
$$z_{\text{attn}} = \text{Attention}(z_{\text{query}}, Z_{\text{anchors}}, Z_{\text{anchors}})$$
Bilevel frameworks leverage unlabeled data $D_{\text{unlabeled}}$ and context samples $m_i \sim \mathcal{U}_{\text{int}}(0, M)$. ActiveFusion integrates heterogeneous molecular representations on low-data regression tasks (ESOL, FreeSolv, Lipophilicity). Core Subset Iterative Extraction (CSIE) updates a core sample subset. Conditional Kernel GPs and Mean Hierarchical GPs (MHGP) address heterogeneous transfer problems. Hierarchical Coarse-Graining maps high-resolution structures to coarse-grained (CG) force-field representations. Low Fidelity as Bias (LFaB) uses semi-empirical data to train GPR models.

---

## Out Of Distribution Generalization And Molecular Splits

### Random Splits Versus Bemis Murcko Scaffold Splits
Random splits leave an average of 60.7% of test molecules, 78.9% of test Murcko scaffolds, and 36.8% of test solvents present in the training set. The Bemis-Murcko scaffold splitting algorithm removes all degree-one atoms to preserve ring systems. Under scaffold splitting, Tanimoto similarity distributions show higher medians and more compact distributions under random splits. Scaffold splitting leads to larger gaps in label distributions.

### Ambiguities And Structural Gaps Of Scaffold Definitions
Compounds differing by a single atom may possess distinct Bemis-Murcko scaffolds despite sharing a Tanimoto similarity of 0.66. Scaffold splitting does not prevent the test set from being populated by fragments, heterocycles, or functional groups highly represented in the training partition (e.g., piperidine rings).

### Molecular Out Of Distribution Characterization
The Molecular Out-of-Distribution (MOOD) framework calculates the Jensen-Shannon divergence between test-to-train and deployment-to-train distance distributions. Covariate shifts cause prediction performance to drop by up to 60% and uncertainty calibration to degrade by up to 40%.

### Benchmarking Out Of Distribution Molecular Property Predictions
The Benchmarking Out-of-Distribution Molecular Property Predictions (BOOM) framework establishes that top-performing models exhibit an OOD error 3 times larger than their in-distribution (ID) error. Hyperparameter optimization with respect to OOD validation performance improves OOD performance by up to 60%. The baseline RF utilizes 125 chemically-informed features and 86 functional group fraction features.

### Metrics And Split Asymmetry
In ADMET datasets of 5,000 to 20,000 points (30% to 70% active), molecular weight reverse splitting is significantly harder than forward molecular weight splitting. 

### Power Law Batch Schemes And Learning Curve Mathematics
The batch size $N_b$ evolves under a power law (POW) scheme:
$$N_b(t) = 2^t \times N_{\text{const}}$$
where $N_{\text{const}} = 1000$. The cumulative training set size evolves as:
$$N_{TR}(t) = 2^t \times N_{\text{const}} + N_{init} \quad \forall t \in \mathbb{N}$$
with $N_{init} = 1000$. Under the Constant Batch Scheme:
$$N_{TR}(t) = t \times N_{\text{const}} + N_{init} \quad \forall t \in \mathbb{N}$$
where $N_{\text{const}}$ is 1k, 2k, 4k, or 8k. Evaluated on the OE dataset, HOMO energy values range between -12.67 eV and -2.73 eV, with a mode at -7.56 eV, mean of -5.49 eV, and standard deviation of 0.57 eV. Under POW, Strategy D achieves predictive accuracy $\text{MAE}_D = 0.148 \pm 0.002$ eV. 

Area Under the Learning Curve (AULC):
$$\text{AULC} = \sum_{r=1}^{R} M(r) \Delta x_r$$
$$\text{AULC}_{\text{normalized}} = \frac{\sum_{i=1}^{T} P_i}{T}$$
Data Utilization Rate (DUR):
$$\text{DUR} = \frac{N_{\text{AL}}}{N_{\text{Baseline}}}$$
In bioRE benchmarks on 7 datasets, Margin and Least-Confident sampling reduced annotation requirements by 6% to 38%.

### Neural Scaling Laws And Functional Scaling In Biochemistry
Model loss scales as:
$$L(R) = \alpha R^{-\beta}$$
Enzyme functions scale as:
$$y = a x^k$$
where $k < 1.0$ is sublinear, $k = 1.0$ is linear, and $k > 1.0$ is superlinear.
The autoregressive model for molecular generation is:
$$P(X) = \prod_{t=1}^T P(x_t|x_{<t})$$
In the large dataset regime, the scaling exponent is $\beta = 0.17 \pm 0.01$ for models between $10^5$ and $10^7$ parameters, and $\beta = 0.30 \pm 0.01$ for the next largest dataset.

### Causal Deconfounding And Domain Adaptation
Domain-Adversarial Neural Networks (DANN) trained on 3,000 and 335 FTIR samples per device (with an independent test set of 260 samples per device) suppress device-specific variations. Style Deconfounding Causal Learning (SDCL) models style using a Structural Causal Model (SCM), a Style-Guided Expert Module (SGEM), and a Backdoor Causal Learning Module (BDCL). 

The TRANSPIRE-DRP framework uses unsupervised domain adaptation on Cetuximab, Paclitaxel, and Gemcitabine datasets using complete test set isolation. Multi-Domain Adversarial Neural Networks (MDANNs) for foodborne bacterial classification target domains (brightfield 60x, phase contrast 20x, phase contrast 20x with 5 hours incubation), achieving a 33.3% accuracy improvement (43.3% to 76.7%) for the brightfield domain. PDA-Net denoises STM images. CausalML for GNNs splits graphs into causal and non-causal subgraphs. 

### Logit Correction For Spurious Attribute Mitigation
The Logit Correction (LC) loss modifies the softmax cross-entropy loss, achieving an average of 5.5% absolute improvement over ERM benchmarks.

### Cross Domain Knowledge Transfer And Negative Transfer Control
Parameter Fine-Tuning initializes $\theta = \theta_{pre}$ and fine-tunes on target data. ChemNet fine-tuned on Tox21, HIV, and FreeSolv shows performance gains. Pretraining GNNs on ChEMBL or ZINC yields an average 7.2% ROC-AUC improvement. Deep graph neural networks fine-tuned on the COADD database (159 active compounds) screened over a billion compounds, identifying 156 candidates with 54% confirming antibacterial activity (MIC $\le$ 64 $\mu\text{g mL}^{-1}$). Pretraining GNNs with gradient alignment strategies improves target task performance by up to 7.7% over vanilla fine-tuning. Graph-level pretraining outperforms node-level pretraining by 1.4% to 25.4%.

### Mechanisms Of Negative Transfer In Chemical Reactions
Transferring reaction prediction parameters between C-N coupling and Suzuki reactions fails. A Random Forest model trained on phenyl benzamide cross-coupling achieves ROC-AUC = 0.91 on pyrazole reactions but ROC-AUC = 0.13 on pinacol boronate nucleophiles. Transferring from malonate to nitrogen-based nucleophiles yields poor ROC-AUC values between 0.52 and 0.77. One-shot models trained on 10 positive and 10 negative target samples can outperform the Adaptive Domain Adversarial Network (ADAN).

### Target Aware Source Selection Via Policy Optimization
On the SCOPE-Bench benchmark, prediction errors of 3D molecular models increase by a mean of 5.9 times (maximum 8.0 times). The Policy Optimization for Multi-Source Adaptation (POMA) framework reduces the mean absolute error by up to 11.2% (average relative improvement of 6.2%).

### Negative Transfer In Theory Informed Machine Learning
When predicting experimental solvation free energy ($\Delta G_{\text{solv}}^{\text{exp}}$), ratio models predicting the ratio of experimental to theoretical values experience negative transfer at larger training sizes as first-principles theory accuracy declines.

### Simulation To Real Domain Transformation
Chemistry-Informed Domain Transformation maps first-principles computational data to the experimental space. In predicting catalyst activity for the reverse water-gas shift reaction, this achieves positive transfer using fewer than 10 target data points, outperforming a scratch model trained on over 100 data points. Physics-informed transfer learning optimizes Model Predictive Control (MPC) systems via Transductive transfer learning.

### Multilevel Learning And Fragment Level Transfer
Task-Oriented Multilevel Learning BERT (TOML-BERT) uses dual-level (node and graph) pretraining, outperforming baselines by 1.4% to 25.4%. Fragment-based Representation Learning (FREL) integrates fragment-level semantics. Transferring Machine Learning Potentials from bulk Silicon (Si) to Germanium (Ge) achieves a Mean Absolute Error of 43 meV/atom using only 10 training samples (compared to 195 samples from scratch). At 1, 10, 40, 100, and 195 samples, energy prediction MAE is reduced by 59%, 69%, 46%, 27%, and -5%, while force prediction MAE is reduced by 38%, 29%, 16%, 6%, and 4%. A SimNet deep model pre-trained on synthetic spectra achieves 80.47% $\pm$ 6.51% accuracy requiring 2,246 parameters, compared to 83.66% $\pm$ 6.90% with 3.74 million parameters.

---

## Validation Protocols Provenance Tracking And Falsification Controls

### Data Leakage Taxonomy And Detection Metrics
Leakage pathways include Spectral Replicates, Scaffold Overlap, Experimental Replicates, and Batch Effects. Potential leakage is evaluated using Morgan fingerprints (radius 3, 2048 bits) paired with Tanimoto similarity (Median Similarity and Maximum Similarity). Exact provenance exclusion relies on the 14-character connectivity layer of the IUPAC InChIKey to flag duplicates and the full 27-character InChIKey to resolve stereochemical and tautomeric identity. In the Oakuloid framework, zero InChIKey-14 overlap across TDC-401 and Geci yields a proxy score correlation of Pearson $r \approx 0.20$. In polymer composite property predictions, random partitioning yields a 26% RMSE reduction, while leakage-free experimental-group-based partitioning yields a 5% RMSE reduction. In QM9 internal energy modeling, treating temperatures ($T = 0\text{ K}$ and $T = 298\text{ K}$) as an explicit input variable alongside molecular features causes leakage if molecules are not strictly partitioned.

### Split Construction And Structural Frontier Failures
The structural-frontier split reserves the most sparsely represented scaffold groups for the evaluation set. Compared to a standard 70/10/20 scaffold-split control, the structural-frontier split inflates the equally weighted primary error by a task-wise median of 87.0% and a mean of 130.3% (bootstrap confidence interval of 52.1% to 246.0%). Excluding the Blood-Brain Barrier (BBB) endpoint drops the mean error inflation to 75.9%. The BBB endpoint is the only task where score rankings completely invert at the frontier. A high-capacity message-passing graph neural network (MPN) yields a mean error inflation of 82.8%. Multi-View Frontier Risk Extrapolation (MV-FREX) alters normalized frontier error by $+0.16\%$ (interval: $-0.43\%$ to $+0.84\%$) for a perceptron head, and by $-1.9\%$ for a GNN.

### Pre Registration Of Study Protocols And Analysis Plans
Pre-registration distinguishes hypothesis-testing confirmatory research from hypothesis-generating exploratory research. Researchers use sample-splitting protocols. The level-based taxonomy of bias control includes: Registration prior to collection of data, prior to human observation of data, prior to access to the data, and prior to analysis of the data.

### Protocol Requirements For Artificial Intelligence And Machine Learning
Clinical guidelines require software versions, regulatory classifications, clinical settings, human-AI interactions (advisory, autonomous, hybrid), and error case analysis plans. Comparative effectiveness uses TRIPOD-AI and CONSORT-AI guidelines. External validation is mandatory across independent data.

### Structured Provenance Tracking And Event Sourced Architectures
The Event-Sourced Architecture for Materials Provenance Management (ESAMP) tracks state-changing processes through tables (`analysis`, `analysis_details`, `analysis_parent`) and State-Equivalent Relationships (SERs). The pinax system represents analytical processes as Directed Acyclic Graphs (DAGs), where models are nodes and transfer relationships are edges, storing Vickers hardness (Hv) models driven by cooling time $\Delta t_{8/5}$ and composition mass percentages. Materials Cloud tracks crystal structure optimization, GCMC simulation, and electrostatic charges. SynRXN packages datasets with SHA-256 checksums, integrating USPTO_50k, USPTO_MIT, and USPTO_500 benchmarks.

### Ontological Standards
The Chemical Information Ontology (CHEMINF) integrates terms as specializations of the Information Artifact Ontology (IAO) and the Ontology for Biomedical Investigations (OBI). Provenance is classified into Prospective Provenance, Retrospective Provenance, and Domain-Specific Provenance (extending W3C PROV-O).

### False Positive Mitigation And Multistage Filtration
TandemMod models validated on the modification-free IVET dataset maintained false positive rates below 10% for m1A, m6A, m5C, hm5C, m7G, and I, and below 20% for Ψ.
A genetic algorithm using $F_{\beta}$ scoring ($\beta = 0.5$) operating within a five-fold cross-validation scheme identified a Linear Discriminant Analysis (LDA) model using four structural features that restricted false positives to a single case.
The HEDGEHOG benchmark executes a six-stage filtration pipeline: Preprocessing, Physicochemical Descriptor Screening, Structural Alerts and Graph-Sanity Checks, Synthesis Feasibility, Docking and Binding Affinity Estimation, and Three-Dimensional Pose Checks. From 230,000 generated molecules, unconditional models retained 1.80%, ligand-based 1.55%, and protein-based 0.96% prior to docking, with only 0.65% surviving all six stages.

### Molecular Task Arithmetic Using Negative Data
Molecular Task Arithmetic (MTA) extracts property directions from negative data:
$$\theta_{\text{task}} = \theta_{\text{negative}} - \theta_{\text{pre-trained}}$$
The target model adds the scaled negated task vector:
$$\theta_{\text{target}} = \theta_{\text{pre-trained}} - \lambda \theta_{\text{task}}$$
Scaling parameter $\lambda$ varies from 0.05 to 1.00 with step sizes of 0.05 or 0.10.

### Meta Learning For Weight Initialization And Instance Selection
A meta-learning framework derives sample-specific weights for source data points during pre-training to balance negative transfer. Pre-training a base kinase inhibitor model using meta-learned weights yielded statistically significant increases in predictive performance.

### Double Machine Learning And Exposure Specificity Verification
In biomarker discovery using double machine learning (DML) with random forest regressors and five-fold cross-fitting, a negative-control taxon (e.g., *Acidaminococcus intestini*) is introduced against an exposure (*Fusobacterium nucleatum*). Detecting a significant causal effect for the negative-control taxon indicates unaddressed confounding.

### Selective Layer Transfer In Lifelong Learning
Selective layer transfer determines the granularity of knowledge transfer driven by explicit relationships among tasks, isolating layer-wise parameters to prevent representation interference.

### Systematic Biases Confounding And Spurious Correlations
### Instrument Noise And Laboratory Platform Confounding
In laboratory datasets, missing values are systematic or random. 

### Covariate And Batch Confounding In Genomic And Assay Datasets
In genome-wide Perturb-seq, control-control correlations are significantly lower across experimental batches than within the same batch (Mann-Whitney U-test, p = 1.4 x 10^-19). ComBat induces systematic bias and inflates correlations. The BatMan framework mitigates this by incorporating batches directly as strata within Cox proportional hazards regression.

### The Clever Hans Effect And Chemist Style Biases
A GBDT classifier trained on ChEMBL assays to predict publication authors achieves 60% top-5 accuracy across 1,815 classes under a scaffold-split regime. An author-only model given protein target identifiers and author-probability vectors achieves predictive power comparable to models using molecular descriptors, proving models exploit non-causal clustering of chemist style.

### Domain Leakage In Prodrug Likeness Prediction
In Prodrug-ML, a LightGBM model trained on the 2048-bit Avalon fingerprint exhibits high domain predictability. A domain-bias-aware feature selection protocol evaluates subsets on a baseline ROC AUC threshold and discards feature sets that predict domain labels significantly above random chance.

### Selection Bias And Entropy Targeted Mitigation In Materials Databases
The entropy-targeted active learning (ET-AL) framework quantifies database bias using an information entropy metric across crystal systems to guide autonomous acquisition. Quality-Diversity (QD) algorithms deploy generative sampling to plug specific gaps in real-world training distributions.

### Empirical Correction Of Instrument Bias In Mass Spectrometry
In quadrupole mass spectrometry (QMS) measuring $\text{pCO}_2$ at $m/z = 44$, periodic oscillations are corrected using endogenous correlates (lab temperature, total gas pressure voltage, seawater flow rate, water vapor at $m/z = 18$, ion current at $m/z = 15$) and exogenous correlates. A Generalized Additive Model (GAM) successfully removed periodic oscillation better than an LSTM. The IR $\text{pCO}_2$ cell temperature, water wall flow rate, and second equilibrator temperature were eliminated based on $\Delta\text{BIC}$.

### Bibliographic Fingerprints As Spurious Predictors
Predicted bibliographic fingerprints (author, journal, year) can be used as the sole input to a secondary model to predict if an MOF belongs to the top-10% of thermally stable materials with high accuracy, requiring metadata ablations and group splits for falsification.

### Label Inconsistencies And Dataset Standardization
Retrosynthetic planning models apply approximately 1,700 pre-extracted templates to reactants to generate candidate products, subsequently reranked by a reaction likelihood estimator.

### Spurious Correlations In Drug Synergy And Chemometrics
Distributional biases in the DrugComb dataset (4,577 drugs, 75,276 combinations, 145 models) explain up to 0.22 delta AUPRC of performance variability. Drug-wise homogeneity of combinatorial labels causes a shift of 0.16 $\pm$ 0.06 delta AUPRC. Explainable AI distinguishes meaningful structures from scattering artifacts.

### Metrology And Generalization Limits Of Optical Property Predictors
On Deep4Chem and ChemFluor datasets, Row-Level Random Splitting yields MAEs of 12.8 nm (absorption) and 18.9 nm (emission). Scaffold-Family Splitting increases MAEs to 39.2 nm and 46.4 nm. Scaffold+Solvent-Stress Splitting results in MAEs of 50.6 nm and 59.3 nm. Article/Provenance Grouping isolates literature-specific experimental biases.

### Experimental Validation Pre Registration And Reporting Standards
### Clinical Translation And Preclinical Attrition
According to Eroom's Law, NMEs per billion dollars of inflation-adjusted R&D halving every nine years. Capitalized cost is $2.6 billion over 10-15 years. Preclinical pipeline attrition: for 10,000 compounds, 250 enter Phase I, 10 progress to Phase II, 2 reach Phase III, 1 achieves approval. The CONFIRM model identified a 25-gene expression signature with an AUC of 0.79 in an independent validation cohort.

### Stage 1 And Stage 2 Registered Reports
Stage 1: Authors submit a study protocol for In-Principle Acceptance (IPA). Stage 2: Final manuscript is published regardless of positive, negative, or null results.

### Automated Recipe Extraction And Synthesis Validation
An extraction pipeline processed 53,538 solid-state synthesis paragraphs, generating 19,488 codified entries. AI-generated protocols are evaluated against a Framework Score and a Weighted Detail Score.

### Prospective ADME And Molecular Design Benchmarks
Prospective validation on 120 internal datasets over 20 months across six ADME endpoints (3,521 compounds from Enamine, eMolecules, WuXi, Mcule) showed retraining models on a fixed schedule yields consistent improvements, while hyperparameter tuning provides marginal gains. The MAINFRAME open science network coordinates blind benchmarking where the Structural Genomics Consortium prospectively synthesizes and tests predicted compounds. A multi-label deep neural network (MLP-FTIR) predicted functional groups within three complex physical chemical mixtures.

### Leakage Proof Validation Regimes In Reaction Discovery
In nitrene-mediated intermolecular C–O coupling, models using molecular additive fingerprints (MAFs) and multiple-fingerprint features (MFF) across XGB, GBT, RF, and SVR algorithms were evaluated on three tiers: Component-Disjoint Validation Set ($R^2 = 0.80$, MAE = 6.6%), Class-Shift Validation Set, and Prospective Synthesis Set. Sequence clustering for antiplasmodial peptide triage uses CD-HIT at a 40% threshold. Probability Calibration uses cluster-wise temperature scaling minimizing Brier loss. Conformal Risk Control sets an acceptance threshold at the $1-\alpha$ quantile ($\alpha = 0.10$ yields 0.91 coverage). Cooperative Adversarially-Robust Transfer Learning (CARTL) maintains robustness using non-expansive fine-tuning.

### Characterization Requirements For Materials And Nanoparticles
Requirements include Dynamic Light Scattering (DLS) or nanoparticle tracking analysis, and SEM or TEM imaging at three distinct magnification levels with visible bar scales.

### Documentation Of Synthetic Procedures
Procedures must specify absolute mass (g), molar amount (mmol), and calculated percent yields. Conceptual novelty is required for new compounds. Reagents must be commercially available or cited.

### Crystallographic And Computational Reporting Standards
Crystallographic Data requires a Crystallographic Information File (CIF) deposited with the CCDC and a checkCIF report. Computational outputs require absolute energies and coordinates. The ACS Research Data Guidelines require testing mammalian cell lines for mycoplasma. The MDPI Molecules journal requires synthesized validation for QSAR studies. The Royal Society of Chemistry requires the number of imaginary frequencies for stationary points.

### Verification In Inorganic Synthesis And Select Crowd Review
Inorganic Syntheses requires procedures scaled for standard research to be reproduced by an independent laboratory. SYNLETT Select Crowd Review uses up to 16 reviewers generating 20-70 comments in 4 days, reducing the timeline to 22 days (compared to 34 days).

### Physical And Structural Conformal Overlayers In Chemical Engineering
Area-Selective Atomic Layer Deposition (ALD) avoids photolithographic patterning at sub-10 nm CDs. In Top Surface Imaging using Poly(tert-butyl methacrylate) (PtBMA) photoresists, $TiO_2$ ALD utilizes $TiCl_4$ and $H_2O$ precursors at $\le 150^\circ\text{C}$ to form an amorphous $TiO_2$ overlayer 6 nm to 21 nm thick with a growth rate of 0.07 nm per cycle on active -OH sites. Area-Selective Deposition of $HfN$ on 10 nm Cu/$SiO_2$ spacings uses a 1-octadecanethiol (ODT) SAM. Thick $TiO_2$ overlayers suppress the Ferri/ferrocyanide redox reaction (FeRR) current by over 99% (at 160 to 200 ALD cycles) while maintaining the Hydrogen Evolution Reaction (HER) current due to high $H^+$ permeability. Crystalline porous covalent organic overlayers synthesized via plasmonic oxidative activation break linear scaling relationships in heterogeneous catalysis.

---

## Open Questions and Patterns

### 1. Ten Broad and Relevant Open Questions
The following questions are selected from the provided list and ranked by their strategic importance for establishing an operational, falsifiable research programme for "selective knowledge-borrowing."

1.  **Q21:** How can the appropriate granularity of knowledge transfer be determined to prevent interference and catastrophic forgetting in lifelong learning across diverse tasks?
2.  **Q12:** To what extent can hybrid uncertainty quantification approaches, which combine training data coverage with model-derived information, improve prediction reliability under varying degrees of data shift?
3.  **Q19:** How can knowledge from multiple source domains with divergent label distributions be effectively aggregated for target domain adaptation?
4.  **Q22:** How can conformal prediction be optimized to produce tight and usable prediction sets when target tasks have extremely limited training data?
5.  **Q24:** How can uncertainty quantification methods be designed to reliably distinguish between trustworthy predictions and speculative ones in chemical research workflows?
6.  **Q17:** How can the trade-off between target domain accuracy and inherited robustness be managed in transfer learning to prevent model degradation?
7.  **Q1:** What strategies can be employed to effectively bridge traditional mechanistic understanding with AI-driven predictions in the field of computational catalysis?
8.  **Q13:** How can leakage auditing, covering structural, scaffold, and temporal controls, be systematically integrated into machine learning workflows to prevent misleading results in retrospective benchmarks?
9.  **Q10:** How should different evidence levels, such as train-unseen labeled evaluation versus prospective experimental results, be weighted to accurately measure the operational utility of molecular screening policies?
10. **Q7:** How can the chemical community construct and standardize reliable datasets that capture both successful and failed reactivity outcomes to reduce bias in machine learning models?

---

### 2. Analysis of Questions, Knowledge Gaps, and Research Directions

#### **Q21: Granularity of Transfer**
*   **Known:** "Sharing Less is More" research shows that selective layer transfer mitigates catastrophic forgetting and that identifying the right granularity of knowledge is essential for task relationships.
*   **Not Known:** How to algorithmically determine the "optimal" slice of a neural network to transfer when moving between vastly different chemical domains (e.g., solid-state catalysts to organometallic complexes).
*   **Direction 1 (Layer-wise Mapping):** Use selective layer transfer to identify which specific architectural components (e.g., shallow vs. deep) correspond to universal vs. domain-specific chemical features.
*   **Direction 2 (Task-Relationship Metrics):** Develop metrics that quantify the "interference potential" between a source (DFT databases) and a target (experimental yields) to pre-emptively block borrowing.
*   **Unexpected Direction (Information-Theoretic Pruning):** Use the concept of "Sharing Less is More" to aggressively prune source models until only the "mechanistic core" remains, then test if this minimal representation transfers better than the full model.

#### **Q12: Hybrid Uncertainty Quantification (UQ)**
*   **Known:** Error Models (EMs) can use Manhattan distance in latent space and predicted variance to estimate error under data shift.
*   **Not Known:** How to weight data-based metrics (coverage) against model-based metrics (variance) when the source and target have different dimensionality.
*   **Direction 1 (Latent-Space Gating):** Implement Manhattan distance-based gates in GNNs to trigger abstention when a target molecule enters a sparse region of the source training data.
*   **Direction 2 (Error Model Ensembles):** Train secondary EMs on diverse "wrong-source" controls to learn the signature of negative transfer.
*   **Unexpected Direction (Permutation-Based UQ Filtering):** Apply shuffling-based null UQ baselines to "filter" out UQ metrics that appear informative but are actually noise, ensuring only robust signals drive borrowing decisions.

#### **Q19: Multi-Source Aggregation**
*   **Known:** Traditional source selection fails when target label distributions shift; methods exist to combine sources based on their specific relations.
*   **Not Known:** A robust "directed map" for chemistry that identifies which of several possible source domains (e.g., small molecules vs. polymers) is credible for a specific target OOD region.
*   **Direction 1 (Source Credibility Weighting):** Develop a mixture-of-experts (MoE) where each expert is trained on a distinct source (e.g., solid materials vs. molecular catalysts) and weighted by local target alignment.
*   **Direction 2 (Label Distribution Alignment):** Use domain adaptation techniques to adjust for divergent label distributions (e.g., high-throughput screening vs. literature yields) before aggregation.
*   **Unexpected Direction (Adversarial Source Selection):** Treat multi-source transfer as a competitive game where a "gate" must defend the target model against "harmful" source edges.

#### **Q22: Conformal Prediction in Data-Scarce Regimes**
*   **Known:** Meta-learning conformalization can generate tighter prediction sets with marginal guarantees even for tasks with limited data.
*   **Not Known:** How to adapt these guarantees for high-risk chemical discovery where "abstention" is preferred over a large, unhelpful prediction set.
*   **Direction 1 (Exchangeability Auditing):** Use conformal prediction to verify if the "exchangeability" assumption holds between source and target datasets.
*   **Direction 2 (Tightness-Aware Borrowing):** Select source knowledge specifically to minimize the size of the conformal prediction set on the target task.
*   **Unexpected Direction (Conformal Gates for Abstention):** Use the size of the conformal prediction set as a hard "refusal" trigger: if the set exceeds a threshold, the model refuses to borrow and reverts to target-only or random.

#### **Q24: Trustworthy UQ vs. Speculation**
*   **Known:** Epistemic uncertainty relates to OOD lack of knowledge; aleatoric relates to label noise. Calibrated uncertainty is a prerequisite for trustworthy deployment.
*   **Not Known:** How to distinguish between "meaningful OOD" (where borrowing is possible) and "total novelty" (where the model must abstain).
*   **Direction 1 (Calibration for OOD):** Prioritize calibrated uncertainty in pretrained representations to ensure that low-label transfer scenarios remain reliable.
*   **Direction 2 (Decision-Aligned UQ):** Align UQ metrics with real-world endpoints (e.g., catalyst screening) to measure the cost of a "false confident" prediction.
*   **Unexpected Direction (Sequence Shuffling as UQ):** Use sequence shuffling (from peptide studies) as an adversarial test; if a model is "certain" about a shuffled sequence, its UQ is speculative and untrustworthy.

#### **Q17: Robustness vs. Accuracy**
*   **Known:** CARTL shows that transfer learning can improve accuracy while degrading robustness; feature distance minimization can mitigate this.
*   **Not Known:** How this trade-off manifests when borrowing from "textbook" mechanistic knowledge vs. "noisy" experimental datasets.
*   **Direction 1 (Non-Expansive Fine-Tuning):** Apply the CARTL framework to chemical transfer learning to ensure that borrowed knowledge doesn't make the model fragile to target-domain noise.
*   **Direction 2 (Feature Distance Constraints):** Use feature distance minimization to keep target representations close to the "robust" source features while adapting to new labels.
*   **Unexpected Direction (Harmful Edge Mapping):** Explicitly identify "harmful edges" (source data that increases target accuracy but kills OOD robustness) as part of the abstention map.

#### **Q1: Mechanistic Bridging**
*   **Known:** Traditional mechanistic knowledge and intuition are vital for designing ML workflows in catalysis (e.g., microkinetic modeling).
*   **Not Known:** How to turn "intuition" into a falsifiable mechanistic hypothesis card that can be used to gate an ML model.
*   **Direction 1 (Latent-State Alignment):** Design ML architectures where latent states are constrained to align with known mechanistic descriptors (e.g., steric/electronic effects).
*   **Direction 2 (Hybrid ML-DFT Profiling):** Use MLIPs to profile reaction mechanisms rapidly, then use the results to inform whether the model should borrow from a related reaction network.
*   **Unexpected Direction (Textbook-to-Gate Transfer):** Extract "mechanistic rules" from literature to serve as the "logical gate" for an MoE, determining which model "expert" is active.

#### **Q13: Leakage Auditing**
*   **Known:** Scaffold-disjoint and structure-disjoint splits are necessary to avoid misleading results; data leakage is a major risk in retrospective benchmarks.
*   **Not Known:** How to audit for "provenance leakage" where a model borrows knowledge that it was actually trained on in a different format.
*   **Direction 1 (Systematic Scaffold Auditing):** Integrate automated structure-disjoint auditing into the transfer learning pipeline to ensure the target is truly novel.
*   **Direction 2 (Temporal Holdout Controls):** Use temporal cutoffs (data recorded after a specific time) as the primary way to measure the "prospective" utility of borrowed knowledge.
*   **Unexpected Direction (Source-Disjoint Controls):** Test models on "wrong-source" and "shuffled-source" baselines as a standard audit to ensure the borrowing mechanism is actually learning chemical relations.

#### **Q10: Evidence Hierarchy Weighting**
*   **Known:** A hierarchy exists from train-unseen to temporal holdouts to external-source benchmarks.
*   **Not Known:** A mathematical framework to weigh these evidence levels for "prospective discovery" vs. "exploratory findings."
*   **Direction 1 (Decision-Aligned Benchmarking):** Weight external-source benchmarks (like BACE) more heavily than internal holdouts when determining a model's screening utility.
*   **Direction 2 (Prospective Preregistration):** Use "outcome-unseen" targets for preregistration to provide the highest-level evidence for a transfer policy.
*   **Unexpected Direction (Post-Outcome Diagnostics):** Use failed predictions (translational gap) as a "diagnostic" evidence level to refine the borrowing map retrospectively.

#### **Q7: Success/Failure Data Standards**
*   **Known:** Negative/failed data is critical for robust models and avoiding bias, especially in transition-metal complexes.
*   **Not Known:** How to standardize "failed" experiments so they can be effectively utilized by GNNs and other ML models.
*   **Direction 1 (Negative Result Databases):** Construct large-scale databases that explicitly label "failed" reactivity outcomes to train "abstention" experts.
*   **Direction 2 (Reaction Condition Optimization):** Use ML models trained on failures to more efficiently navigate reaction spaces by "fencing off" regions of low probability.
*   **Unexpected Direction (Failure as a Source):** Treat a dataset of "failures" as a unique source domain to learn what *not* to borrow from "success-only" datasets.

---

### 3. Patterns in Research Directions
*   **Pattern 1: The Gatekeeper Role of UQ.** Almost every question points toward UQ (Conformal, Hybrid, Error Models) not just as a performance metric, but as an active "gate" or "switch" for transfer.
*   **Pattern 2: Granularity and Selection.** There is a recurring theme of "selective" borrowing (selective layer transfer, MoE, source credibility) over "global" borrowing.
*   **Pattern 3: Robustness over Pure Accuracy.** Several directions prioritize CARTL-style robustness and "fencing off" failure regions over simply reducing RMSE.
*   **Pattern 4: The Role of Failure.** Failure data and "wrong-source" controls are emerging as essential tools for both training and validation (adversarial-like testing).
*   **Unexpected Pattern:** There is a significant focus on *architectural pruning* and *minimalism* (Sharing Less is More, minimal mechanistic cores) as a pathway to better generalization, which contradicts the typical "foundation model" trend of scaling.

---

### 4. Reasoning about Most Promising Directions
The most promising path forward involves merging **Selective Layer Transfer** (Q21) with **Conformal Gates** (Q22). If we can identify the specific "granularity" of a source model that corresponds to a mechanistic principle (Q1), and then gate that knowledge with a conformal prediction set that guarantees a certain error rate (Q24), we create a "directed, abstaining map." This addresses the "translational gap" by ensuring the model only makes predictions (or borrows knowledge) when the evidence is robust and the "exchangeability" with the target is statistically supported. Furthermore, the use of **Failure Data** (Q7) as a specific source for training "negative gates" provides a unique, falsifiable way to implement the "abstention" rule requested in the goal.

---

### 5. Summary of Promising Directions

1.  **Conformal Gates for Selective Borrowing (Top Priority):** This direction uses conformal prediction to generate prediction sets on the target task; the model is programmed to "abstain" or "refuse to borrow" if the set size exceeds a mechanistic threshold. This directly addresses the goal of an "abstaining map" using a statistically rigorous, distribution-free method (Claims: CP, Meta-learning conformalization).
2.  **Mechanistic Latent-State Alignment:** Hypotheses should be framed as: "If target domain X shares mechanistic descriptor Y with source Z, then borrowing from layer N will reduce OOD error." This moves beyond generic transfer to directed, theory-driven borrowing (Claims: Mechanistic intuition in catalysis, Error Models).
3.  **Hybrid UQ with Manhattan Distance Gates:** Using a combination of predicted variance and latent-space distance to the training set allows models to identify "epistemic voids." This is the most feasible way to quantify when a target is too OOD for a source to be credible (Claims: Error Models, UQ permutation tests).
4.  **CARTL-based Robustness Transfers:** Instead of standard fine-tuning, use feature distance minimization to ensure that borrowed knowledge doesn't degrade the model's ability to handle noisy or diverse target data. This prevents "harmful edges" in the borrowing map (Claims: CARTL, Multi-source adaptation).
5.  **Adversarial Shuffling as a Validation Control:** Every borrowing claim must be tested against a "shuffled-source" baseline. If borrowing from a random/shuffled source produces similar gains, the original claim of "mechanistic transfer" is falsified (Claims: Sequence shuffling, Leakage auditing).
6.  **Granularity-Focused Pruning (Sharing Less is More):** Systematically prune source models to find the "minimal transferable subgraph." This reduces the risk of "catastrophic forgetting" and ensures only high-information features are borrowed (Claims: Selective layer transfer).
7.  **Failure-Data Training for Negative Experts:** Train a specific "expert" in a mixture-of-experts (MoE) architecture exclusively on failed reactivity data. This expert's role is to veto predictions in regions associated with known chemical failures (Claims: Capturing failure data, MoE).
8.  **Temporal Holdouts for Prospective Validation:** To bridge the "translational gap," all borrowing models must be validated on data recorded *after* the model's development. This is the highest level of evidence short of a wet-lab experiment (Claims: Evidence hierarchy, Temporal holdouts).
9.  **Scaffold-Disjoint Provenance Auditing:** Implement rigorous auditing that excludes any structure-disjoint or scaffold-disjoint overlaps between source and target. This ensures the "borrowing" is truly OOD and not just memorized leakage (Claims: Structure-disjoint subsets, MPP reproducibility).
10. **Label Distribution Alignment in Multi-Source MoEs:** When borrowing from multiple sources (e.g., DFT + Experimental), use domain adaptation to align label distributions. This prevents the target model from being biased by the different "scales" of the source data (Claims: Multi-source domain adaptation).

---

## Unexpected Connections

Unexpected connection 1:
* Claims: Sequence shuffling as an adversarial perturbation to distinguish local vs. global property drivers. Domain-specific fingerprints (ECFP) often outperform complex GNNs in peptide tasks. "Sharing Less is More" focuses on identifying the appropriate granularity of knowledge transfer to avoid interference.
* Reasoning: There is a mechanistic link between the physical basis of a molecular property (local substructure vs. global interaction) and the architectural depth at which knowledge should be borrowed. If a source domain's properties are invariant to sequence or graph shuffling, the underlying chemical signal is primarily local/substructural. This implies that borrowing should be restricted to early "substructure-detecting" layers, while higher-order global layers should be frozen or initialized from scratch to prevent the transfer of irrelevant structural noise.
* Novelty: While the distinction between local and global features is established, using adversarial shuffling on a source domain as a dynamic heuristic to set a layer-specific "transfer-depth" policy for a target domain is an undocumented approach in chemical transfer learning.
* Relevance: This supports the establishment of a "Shuffling-Sensitivity Gate." Before borrowing, a permutation test is performed on the source domain. If the source is determined to be "local-heavy," the borrowing method implements a mixture-of-experts where only low-level embeddings are shared. This provides a clear "abstention" rule for deeper layers, addressing the goal's requirement for directed maps of interference.

Unexpected connection 2:
* Claims: Reliable datasets require both successful and failed reactivity outcomes (failure data). Null UQ baselines use permutation tests of true errors to identify uninformative metrics. Error Models (EMs) predict the error of primary models.
* Reasoning: Failure data (experimental negatives) can serve as a mandatory "Negative Control" for Uncertainty Quantification (UQ). An Error Model’s validity can be falsified by its inability to distinguish between a "predicted success with high error" and a "recorded experimental failure." If UQ metrics do not assign higher epistemic uncertainty to known failures than to successful Out-of-Distribution (OOD) predictions, the uncertainty estimation is likely capturing aleatoric noise rather than domain-relevant knowledge gaps.
* Novelty: Using failure data specifically to falsify the validity of an Error Model’s uncertainty ranking—rather than simply using it as a training label—is a novel protocol for Molecular Property Prediction (MPP) benchmarks.
* Relevance: This leads to the "Failure-Aware Calibration" hypothesis. It enables a quantifiable metric, the "Failure-Success Separation" (FSS) score, which measures the overlap of UQ distributions between successful and failed experiments. This fulfills the requirement for high-information experiments to falsify the central thesis of borrowing credibility.

Unexpected connection 3:
* Claims: Simple Multiple Linear Regression (MLR) effectively captures complex organometallic interactions (R2=0.93). Integrating textbook mechanistic knowledge is vital for ML workflows. The "translational gap" is caused by oversimplifying environmental effects (solvent, temperature).
* Reasoning: Interpretable, low-complexity models (MLR) can function as "Transferability Diagnostics." By training MLR models on both source and target domains using standardized physical descriptors (e.g., Sterimol, NBO charges), one can compare the resulting coefficients. If the fundamental mechanistic drivers (steric vs. electronic weights) are orthogonal or significantly divergent, the domains are mechanistically disjoint. In such cases, complex deep learning models should be prohibited from borrowing latent features to avoid the "translational gap."
* Novelty: Utilizing an MLR-based interpretable proxy as a hard "gate" for deep transfer learning is a departure from standard latent-space alignment techniques (like MMD or DANN).
* Relevance: This addresses the requirement for an "MLR-Proxy Gate." It provides a "Post-outcome Diagnostic" to explain transfer failures and serves as a principled abstention trigger when mechanistic alignment ($\Delta\beta$) exceeds a predefined threshold.

Unexpected connection 4:
* Claims: The CARTL framework highlights a trade-off where traditional transfer improves accuracy but degrades inherited robustness. MPP benchmarks should prioritize decision-aligned metrics and specify all sources of randomness. Primary evidence should use structure-disjoint or scaffold-disjoint subsets.
* Reasoning: Adversarial robustness—the model's stability under feature perturbations—can be used as a diagnostic tool for "Latent Alignment." If transferring knowledge from a source to a target improves accuracy but causes a collapse in the robustness inherited from the source, the transfer is likely relying on spurious correlations rather than a shared stable manifold. A "healthy" borrowing event should maintain or enhance the adversarial stability of the target predictions.
* Novelty: Robustness is conventionally treated as a performance metric to be preserved. Using it as a diagnostic instrument to identify true versus spurious domain compatibility is a novel application.
* Relevance: This informs the "Robustness-Compatibility" hypothesis and the design of a "Robustness-Aware Mixture of Experts." It provides a decisive, feasible test for the research programme: if a few-shot trial on a target domain triggers a "Robustness-Collapse," the system must refuse to borrow from that source.

---

## References

[1] **[Ligand field and density functional descriptions of the d-states and bonding in transition metal complexes - PubMed](https://pubmed.ncbi.nlm.nih.gov/14527227/)**  
nih.gov

[2] **[Iron Complexes of a Proton-Responsive SCS Pincer Ligand with a Sensitive Electronic Structure | Inorganic Chemistry - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.inorgchem.1c03499)**  
acs.org

[3] **[Iron Complexes of a Proton-Responsive SCS Pincer Ligand with a Sensitive Electronic Structure - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC8792349/)**  
nih.gov

[4] **[Fundamentals and Perspectives of Positively Charged Single-Metal Site Catalysts for CO2 Electroreduction - ACS Publications](https://pubs.acs.org/doi/10.1021/acsami.4c21988)**  
acs.org

[5] **[Atomically Dispersed Manganese Lewis Acid Sites Catalyze Electrohydrogenation of Nitrogen to Ammonia | CCS Chemistry - Chinese Chemical Society](https://www.chinesechemsoc.org/doi/10.31635/ccschem.021.202101106)**  
chinesechemsoc.org

[6] **[Selectivity Switching by Ligand Coordination Sites  The Key to Promote the CO2/C2H4 Coupling Reaction over the Ru-Based Catalyst | ACS Catalysis](https://pubs.acs.org/doi/10.1021/acscatal.4c03808)**  
acs.org

[7] **[Metal–Ligand Role Reversal: Hydride-Transfer Catalysis by a Functional Phosphorus Ligand with a Spectator Metal | Journal of the American Chemical Society](https://pubs.acs.org/doi/10.1021/jacs.2c10200)**  
acs.org

[8] **[Revealing axial-ligand-induced switching of spin states for controllable single electron transfer-based radical initiation](https://pubs.rsc.org/de-at/content/articlepdf/2025/sc/d5sc02194d)**  
rsc.org

[9] **[Interpretable machine learning screening and analysis of pressure sensitivity and high-pressure emission line shifts in lanthanide- and transition-metal-doped phosphors - Royal Society of Chemistry journals](https://xlink.rsc.org/?DOI=D6TC00745G)**  
rsc.org

[10] **[Decoding the Stability of Transition-Metal Alloys with Theory-infused Deep Learning - arXiv](https://arxiv.org/html/2506.03031v2)**  
arxiv.org

[11] **[Structural and Chemical Features Giving Rise to Defect Tolerance of Binary Semiconductors](https://pubs.acs.org/doi/10.1021/acs.chemmater.8b01505)**  
acs.org

[12] **[New Insights into the Negative Thermal Expansion: Direct Experimental Evidence for the “Guitar-String” Effect in Cubic ScF3 | Journal of the American Chemical Society](https://pubs.acs.org/doi/10.1021/jacs.6b02370)**  
acs.org

[13] **[Two Decades of Negative Thermal Expansion Research: Where Do We Stand? - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC5448970/)**  
nih.gov

[14] **[Mechanisms and Materials for NTE - PMC - NIH](https://pmc.ncbi.nlm.nih.gov/articles/PMC6113360/)**  
nih.gov

[15] **[Giant Magnetoelastic Effect at the Opening of a Spin-Gap in Ba3BiIr2O9 - ACS Publications](https://pubs.acs.org/doi/10.1021/ja211517h)**  
acs.org

[16] **[Structurally and electronically driven uniaxial negative thermal expansion in BaIrO3](https://pubs.rsc.org/en/content/articlepdf/2025/cc/d4cc06174h)**  
rsc.org

[17] **[Mechanisms and Materials for NTE - Frontiers](https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2018.00371/full)**  
frontiersin.org

[18] **[(a) Schematic structure of an Al/PE interface, containing crystalline... - ResearchGate](https://www.researchgate.net/figure/a-Schematic-structure-of-an-Al-PE-interface-containing-crystalline-and-amorphous_fig1_318619665)**  
researchgate.net

[19] **[Uniform binding and negative catalysis at the origin of enzymes - PMC - NIH](https://pmc.ncbi.nlm.nih.gov/articles/PMC9281367/)**  
nih.gov

[20] **[ChemBioSim: Enhancing Conformal Prediction of In Vivo Toxicity by Use of Predicted Bioactivities - ResearchGate](https://www.researchgate.net/publication/352581436_ChemBioSim_Enhancing_Conformal_Prediction_of_In_Vivo_Toxicity_by_Use_of_Predicted_Bioactivities)**  
researchgate.net

[21] **[Dataset Augmentation and Mixture-Of-Experts Adaptation Transfer Learning - Stanford University](https://web.stanford.edu/class/archive/cs/cs224n/cs224n.1214/reports/final_reports/report193.pdf)**  
stanford.edu

[22] **[DEGRE: Dynamic Gating Ensembles for Trust-Aware Rejection in Medical Image Diagnostics | Proceedings of the AAAI Conference on Artificial Intelligence](https://ojs.aaai.org/index.php/AAAI/article/view/42473)**  
aaai.org

[23] **[[2511.11743] Uncertainty Makes It Stable: Curiosity-Driven Quantized Mixture-of-Experts](https://arxiv.org/abs/2511.11743)**  
arxiv.org

[24] **[Uncertainty Makes It Stable: Curiosity-Driven Quantized Mixture-of-Experts - arXiv](https://arxiv.org/html/2511.11743v3)**  
arxiv.org

[25] **[Dynamic Expert Specialization: Towards Catastrophic Forgetting-Free Multi-Domain MoE Adaptation - ACL Anthology](https://aclanthology.org/2025.emnlp-main.932.pdf)**  
aclanthology.org

[26] **[An open-source family of large encoder-decoder foundation models for chemistry - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12216393/)**  
nih.gov

[27] **[Enhanced Expert Merging for Mixture-of-Experts in Graph Foundation Models - OpenReview](https://openreview.net/pdf?id=fyqqd1lHDb)**  
openreview.net

[28] **[Mixture-of-Experts Ensemble with Hierarchical Deep Metric Learning for Spectroscopic Identification](https://ml4physicalsciences.github.io/2021/files/NeurIPS_ML4PS_2021_9.pdf)**  
github.io

[29] **[Improving crystal material property prediction with multi-view geometric graph transformer](https://pubmed.ncbi.nlm.nih.gov/42236702/)**  
nih.gov

[30] **[Trustworthy Few-Shot Transfer of Medical VLMs through Split Conformal Prediction](https://papers.miccai.org/miccai-2025/paper/4783_paper.pdf)**  
miccai.org

[31] **[No Need for Learning to Defer? A Training Free Deferral Framework to Multiple Experts through Conformal Prediction - arXiv](https://arxiv.org/pdf/2509.12573)**  
arxiv.org

[32] **[Leveraging conformal prediction to annotate enzyme function space with limited false positives - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11164347/)**  
nih.gov

[33] **[Error Reduction in Leukemia Machine Learning Classification With Conformal Prediction | JCO Clinical Cancer Informatics - ASCO Publications](https://ascopubs.org/doi/10.1200/CCI-24-00324)**  
ascopubs.org

[34] **[HazChemNet: A Deep Learning Model for Hazardous Chemical Prediction - MDPI](https://www.mdpi.com/1422-0067/26/19/9288)**  
mdpi.com

[35] **[Enhancing Cost Efficiency in Active Learning with Candidate Set Query - arXiv](https://arxiv.org/pdf/2502.06209)**  
arxiv.org

[36] **[Enhancing Cost Efficiency in Active Learning with Candidate Set Query - OpenReview](https://openreview.net/forum?id=qmqRdxQcMA)**  
openreview.net

[37] **[A Quiet Failure in Calibrated Virtual Screening: Marginal Conformal Prediction Under-Covers the Minority Class, and a Class-Conditional Fix Recovers It - arXiv](https://arxiv.org/html/2607.06605v1)**  
arxiv.org

[38] **[eMOSAIC: Multi-modal Out-of-distribution Uncertainty Quantification Streamlines Large-scale Polypharmacology | bioRxiv](https://www.biorxiv.org/content/10.1101/2024.01.05.574359v2.full)**  
biorxiv.org

[39] **[Catlas: an automated framework for catalyst discovery demonstrated for direct syngas conversion† | Catalysis Science & Technology | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlelanding/2022/cy/d2cy01267g)**  
rsc.org

[40] **[Incorporating Synthetic Accessibility in Drug Design: Predicting Reaction Yields of Suzuki Cross-Couplings by Leveraging AbbVie's 15-Year Parallel Library Data Set | Journal of the American Chemical Society](https://pubs.acs.org/doi/10.1021/jacs.4c00098)**  
acs.org

[41] **[Advancing chemical safety prediction: an integrated GNN framework with DFT-augmented cyclic compound solution - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12922296/)**  
nih.gov

[42] **[Foundation-Model Surrogates Enable Data-Efficient Active Learning for Materials Discovery - arXiv](https://arxiv.org/pdf/2603.12567)**  
arxiv.org

[43] **[Active learning of molecular data for task-specific objectives - AIP Publishing](https://pubs.aip.org/aip/jcp/article/162/1/014103/3329103/Active-learning-of-molecular-data-for-task)**  
aip.org

[44] **[Sample efficient reinforcement learning with active learning for molecular design - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10935729/)**  
nih.gov

[45] **[Active learning of alchemical adsorption simulations - NSF Public Access Repository](https://par.nsf.gov/servlets/purl/10574103)**  
nsf.gov

[46] **[Band gap predictions of double perovskite oxides using machine learning - ResearchGate](https://www.researchgate.net/publication/371473880_Band_gap_predictions_of_double_perovskite_oxides_using_machine_learning)**  
researchgate.net

[47] **[Reinforced Active Learning for Large-Scale Virtual Screening with Learnable Policy Model - NIPS](https://papers.neurips.cc/paper_files/paper/2025/file/57ac7ccded0eaaec4ad6f05612289b79-Paper-Conference.pdf)**  
neurips.cc

[48] **[Transfer Learning from Lithium-Ion to Zinc-Ion Batteries: Cross-Chemistry Capacity Prediction with Limited Target Data | ChemRxiv](https://chemrxiv.org/doi/10.26434/chemrxiv.15002657)**  
chemrxiv.org

[49] **[Molecular property prediction in the ultra‐low data regime - PMC - NIH](https://pmc.ncbi.nlm.nih.gov/articles/PMC12238508/)**  
nih.gov

[50] **[Machine Learning in the Design and Performance Prediction of Organic Framework Membranes: Methodologies, Applications, and Industrial Prospects - MDPI](https://www.mdpi.com/2077-0375/15/6/178)**  
mdpi.com

[51] **[AbstainGNN: Teaching Graph Neural Networks to Abstain for Graph Classification - arXiv](https://arxiv.org/html/2605.30786v1)**  
arxiv.org

[52] **[Improved Machine Learning Models for Predicting Selective Compounds - ACS Publications](https://pubs.acs.org/doi/10.1021/ci200346b)**  
acs.org

[53] **[NeurIPS Poster BOOM: Benchmarking Out-Of-distribution Molecular Property Predictions of Machine Learning Models](https://neurips.cc/virtual/2025/poster/121661)**  
neurips.cc

[54] **[Adaptmol: domain adaptation for molecular image recognition with limited supervision](https://pubmed.ncbi.nlm.nih.gov/42070053/)**  
nih.gov

[55] **[Rapid prediction of full spin systems using uncertainty-aware machine learning† | Chemical Science | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlelanding/2023/sc/d3sc01930f)**  
rsc.org

[56] **[CPSign: conformal prediction for cheminformatics modeling - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11214261/)**  
nih.gov

[57] **[Deep graph kernel learning for material & atomic level uncertainty quantification in adsorption energy prediction | Digital Discovery | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlehtml/2026/dd/d6dd00020g)**  
rsc.org

[58] **[Predictive chemistry: machine learning for reaction deployment, reaction development, and reaction discovery | Chemical Science](https://pubs.rsc.org/en/Content/ArticleLanding/2023/SC/D2SC05089G)**  
rsc.org

[59] **[Transfer learning for molecular property predictions from small datasets | AIP Advances](https://pubs.aip.org/aip/adv/article/14/10/105119/3316780/Transfer-learning-for-molecular-property)**  
aip.org

[60] **[A general optimization protocol for molecular property prediction using a deep learning network - Oxford Academic](https://academic.oup.com/bib/article/23/1/bbab367/6366324)**  
oup.com

[61] **[Data-driven and interpretable machine learning for performance-determining interactions governing C–C coupling and C2+ selectivity in Cu-catalyzed CO2 electroreduction](https://pubs.rsc.org/en/Content/ArticleLanding/2026/CP/D6CP00893C)**  
rsc.org

[62] **[Counterfactually Comparing Abstaining Classifiers](https://proceedings.neurips.cc/paper_files/paper/2023/file/59fe467d5e71ba6b8d41bb3928da6f4c-Paper-Conference.pdf)**  
neurips.cc

[63] **[Improved Machine Learning Models for Predicting Selective Compounds - Figshare](https://figshare.com/collections/Improved_Machine_Learning_Models_for_Predicting_Selective_Compounds/2519560)**  
figshare.com

[64] **[Generalization of long-range machine learning potentials in complex chemical spaces | Digital Discovery | The Royal Society of Chemistry](https://pubs.rsc.org/en/Content/ArticleLanding/2025/DD/D5DD00570A)**  
rsc.org

[65] **[AdaptMol: Domain Adaptation for Molecular OCSR (2026) - Hunter Heidenreich](https://hunterheidenreich.com/notes/chemistry/optical-structure-recognition/image-to-graph/adaptmol-2026/)**  
hunterheidenreich.com

[66] **[Uncertainty-Informed Deep Transfer Learning of Perfluoroalkyl and Polyfluoroalkyl Substance Toxicity - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.1c01204)**  
acs.org

[67] **[Reliable machine learning models in genomic medicine using conformal prediction](https://www.frontiersin.org/journals/bioinformatics/articles/10.3389/fbinf.2025.1507448/full)**  
frontiersin.org

[68] **[Computational Materials Design: Accelerate Discovery with AI](https://polymerize.io/knowledge-hub/blogs/computational-materials-design-accelerate-discovery-with-ai)**  
polymerize.io

[69] **[Development of QSAR Models and Web Applications for Predicting hDHFR Inhibitor Bioactivity Using Machine Learning - MDPI](https://www.mdpi.com/1420-3049/30/23/4618)**  
mdpi.com

[70] **[Improving reaction prediction through chemically aware transfer learning† | Digital Discovery | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlelanding/2025/dd/d4dd00412d)**  
rsc.org

[71] **[Fast and effective molecular property prediction with transferability map](https://communities.springernature.com/posts/fast-and-effective-molecular-property-prediction-with-transferability-map)**  
springernature.com

[72] **[Machine Learning and Statistical Analysis for Materials Science: Stability and Transferability of Fingerprint Descriptors and Chemical Insights - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.chemmater.6b04229)**  
acs.org

[73] **[MOLECULE: Molecular-dynamics and Optimized deep Learning for Entropy-regularized Classification and Uncertainty-aware Ligand Evaluation - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12461829/)**  
nih.gov

[74] **[Roadmap: Unlocking machine learning for drug discovery - Bessemer Venture Partners](https://www.bvp.com/atlas/roadmap-unlocking-machine-learning-for-drug-discovery)**  
bvp.com

[75] **[Probing out-of-distribution generalization in machine learning for materials - arXiv](https://arxiv.org/html/2406.06489v1)**  
arxiv.org

[76] **[MolGA: Molecular Graph Adaptation with Pre-trained 2D Graph Encoder | OpenReview](https://openreview.net/forum?id=HAxRIkYbzG)**  
openreview.net

[77] **[Biophysics-guided uncertainty-aware deep learning uncovers high-affinity plastic-binding peptides | Digital Discovery | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlelanding/2025/dd/d4dd00219a)**  
rsc.org

[78] **[Leveraging conformal prediction to annotate enzyme function space with limited false positives | PLOS Computational Biology - Research journals](https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1012135)**  
plos.org

[79] **[Scale-Dependent Input Representation and Confidence Estimation for LLMs in Materials Property Prediction - arXiv](https://arxiv.org/html/2605.03515v1)**  
arxiv.org

[80] **[A multitask GNN-based interpretable model for discovery of selective JAK inhibitors - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC8922399/)**  
nih.gov

[81] **[Selective Transfer: Methods and Applications - Emergent Mind](https://www.emergentmind.com/topics/selective-transfer)**  
emergentmind.com

[82] **[Molecular property prediction in the ultra-low data regime. - KAUST Repository](https://repository.kaust.edu.sa/items/f276a0e5-cb5a-4fb3-bce5-40e3144a6144)**  
kaust.edu.sa

[83] **[Virtual sample generation in machine learning assisted materials design and discovery](https://www.oaepublish.com/articles/jmi.2023.18)**  
oaepublish.com

[84] **[Property Prediction of Organic Donor Molecules for ... - OSTI.GOV](https://www.osti.gov/servlets/purl/1802608)**  
osti.gov

[85] **[An Interpretable Machine Learning Model for Selectivity of Small-Molecules Against Homologous Protein Family - Taylor & Francis](https://www.tandfonline.com/doi/abs/10.4155/fmc-2022-0075)**  
tandfonline.com

[86] **[BOOM: Benchmarking Out-Of-distribution Molecular Property ... - NIPS](https://papers.nips.cc/paper_files/paper/2025/file/b94263f7f98c9766ea9a09761ddd88ee-Paper-Datasets_and_Benchmarks_Track.pdf)**  
nips.cc

[87] **[DAGFormer: A graph-based domain adaptation approach for single-cell cancer drug response prediction | PLOS Computational Biology - Research journals](https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1013832)**  
plos.org

[88] **[Uncertainty-Aware Pseudo-labeling for Quantum Calculations - Proceedings of Machine Learning Research](https://proceedings.mlr.press/v180/huang22a/huang22a.pdf)**  
mlr.press

[89] **[CPSign - Conformal Prediction for Cheminformatics Modeling - bioRxiv](https://www.biorxiv.org/content/10.1101/2023.11.21.568108v1.full.pdf)**  
biorxiv.org

[90] **[Deeply uncertain: comparing methods of uncertainty quantification in deep learning algorithms - ResearchGate](https://www.researchgate.net/publication/343034662_Deeply_uncertain_comparing_methods_of_uncertainty_quantification_in_deep_learning_algorithms)**  
researchgate.net

[91] **[Ranking Molecules with Vanishing Kernels and a Single Parameter: Active Applicability Domain Included | Journal of Chemical Information and Modeling](https://pubs.acs.org/doi/10.1021/acs.jcim.9b01075)**  
acs.org

[92] **[Transfer Learning for Molecular Property Predictions from Small Data Sets - arXiv](https://arxiv.org/html/2404.13393v1)**  
arxiv.org

[93] **[Supervised Source-Task Pretraining for Low-Data Electrochemical Molecular Property Prediction | ChemRxiv](https://chemrxiv.org/doi/10.26434/chemrxiv.15003831)**  
chemrxiv.org

[94] **[An Overview on the Role of Artificial Intelligence in Modern Advancements of Material Science](https://www.espublisher.com/journals/articlehtml/es-general/10.30919-esg1183)**  
espublisher.com

[95] **[Graph Neural Networks for Molecular Property Prediction | by Amit Yadav | Biased-Algorithms | Medium](https://medium.com/biased-algorithms/graph-neural-networks-for-molecular-property-prediction-ed9b87241890)**  
medium.com

[96] **[Model-free selective inference and its applications to drug discovery - NeurIPS 2026](https://neurips.cc/virtual/2023/80007)**  
neurips.cc

[97] **[Probing out-of-distribution generalization in machine learning for ...](https://collaborate.princeton.edu/en/publications/probing-out-of-distribution-generalization-in-machine-learning-fo/)**  
princeton.edu

[98] **[AACDR: Integrating Graph Isomorphism Networks and Asymmetric Adversarial Domain Adaptation for Cancer Drug Response Prediction | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.5c01026)**  
acs.org

[99] **[MACE4IRmol: An uncertainty-aware foundation model for molecular infrared spectroscopy - arXiv](https://arxiv.org/html/2508.19118v2)**  
arxiv.org

[100] **[Conformal Prediction-based Machine Learning in Cheminformatics: Current Applications and New Challenges - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv-2025-p36vt)**  
chemrxiv.org

[101] **[Leveraging Uncertainty from Deep Learning for Trustworthy Material Discovery Workflows | ACS Omega - ACS Publications](https://pubs.acs.org/doi/10.1021/acsomega.1c00975)**  
acs.org

[102] **[(PDF) Efficiency of different measures for defining the applicability domain of classification models - ResearchGate](https://www.researchgate.net/publication/318892230_Efficiency_of_different_measures_for_defining_the_applicability_domain_of_classification_models)**  
researchgate.net

[103] **[Uncertainty-Aware Yield Prediction with Multimodal Molecular Features](https://ojs.aaai.org/index.php/AAAI/article/view/28668/29297)**  
aaai.org

[104] **[Topology-Aware Multiscale Mixture of Experts for Efficient Molecular Property Prediction](https://arxiv.org/html/2601.12637v1)**  
arxiv.org

[105] **[MolDiff-PEFT: Conditional Molecular Graph Diffusion with Parameter-Efficient Fine-Tuning for Molecular Generation and Property Prediction - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv.15003920)**  
chemrxiv.org

[106] **[Learning Molecular Representation in a Cell - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11213146/)**  
nih.gov

[107] **[Joint Hierarchical Representation Learning of Samples and Features via Informed Tree-Wasserstein Distance | OpenReview](https://openreview.net/forum?id=VanvIu0KZU&referrer=%5Bthe%20profile%20of%20Ya-Wei%20Eileen%20Lin%5D(%2Fprofile%3Fid%3D~Ya-Wei_Eileen_Lin1))**  
openreview.net

[108] **[Determining the Credibility of Science Communication - ACL Anthology](https://aclanthology.org/2021.sdp-1.1.pdf)**  
aclanthology.org

[109] **[Molecular Similarity-Based Domain Applicability Metric Efficiently Identifies Out-of-Domain Compounds | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/abs/10.1021/acs.jcim.8b00597)**  
acs.org

[110] **[LOGICS: Learning optimal generative distribution for designing de novo chemical structures](https://pmc.ncbi.nlm.nih.gov/articles/PMC10483765/)**  
nih.gov

[111] **[Accurate prediction of synthesizability and precursors of 3D crystal structures via large language models - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12264133/)**  
nih.gov

[112] **[SLI-GNN: A Self-Learning-Input Graph Neural Network for Predicting Crystal and Molecular Properties | The Journal of Physical Chemistry A - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jpca.3c01558)**  
acs.org

[113] **[Scaling deep learning for materials discovery - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10700131/)**  
nih.gov

[114] **[(PDF) Generative Inverse Design with Abstention via Diagonal Flow Matching](https://www.researchgate.net/publication/402612678_Generative_Inverse_Design_with_Abstention_via_Diagonal_Flow_Matching)**  
researchgate.net

[115] **[Predicting Materials Properties with Little Data Using Shotgun Transfer Learning | ACS Central Science - ACS Publications](https://pubs.acs.org/doi/10.1021/acscentsci.9b00804)**  
acs.org

[116] **[Transfer learning for versatile and training free high content screening analyses - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10730630/)**  
nih.gov

[117] **[Uncertainty-Aware Mixture Models of First Significant Digit Frequencies Detect Irregularities in Scientific Data | ChemRxiv](https://chemrxiv.org/doi/10.26434/chemrxiv.15000459)**  
chemrxiv.org

[118] **[Track: Poster Session 5 - ICML 2026](https://icml.cc/virtual/2021/session/12517)**  
icml.cc

[119] **[A Quiet Failure in Calibrated Virtual Screening: Marginal Conformal Prediction Under-Covers the Minority Class, and a Class-Cond - arXiv](https://arxiv.org/pdf/2607.06605)**  
arxiv.org

[120] **[Mol-MoE: Training Preference-Guided Routers for Molecule Generation - arXiv](https://arxiv.org/html/2502.05633v1)**  
arxiv.org

[121] **[Capsule neural network and its applications in drug discovery - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12002614/)**  
nih.gov

[122] **[MOLE-BERT: RETHINKING PRE-TRAINING GRAPH NEURAL NETWORKS FOR MOLECULES](https://chengtan9907.github.io/assets/publications/iclr23_molbert.pdf)**  
github.io

[123] **[Unsupervised Ground Metric Learning Using Wasserstein Singular Vectors ?](https://proceedings.mlr.press/v162/huizing22a/huizing22a.pdf)**  
mlr.press

[124] **[What Makes Sources Credible? How Source Features Shape Evaluation of Scientific Information | Request PDF - ResearchGate](https://www.researchgate.net/publication/389991525_What_Makes_Sources_Credible_How_Source_Features_Shape_Evaluation_of_Scientific_Information)**  
researchgate.net

[125] **[Molecular Similarity-Based Domain Applicability Metric Efficiently Identifies Out-of-Domain Compounds - PubMed](https://pubmed.ncbi.nlm.nih.gov/30404432/)**  
nih.gov

[126] **[SOT-RM: An equivariant shortcut and optimal transport-based flow ...](https://assets-eu.researchsquare.com/files/rs-8836310/v1_covered_7e0543fb-01f0-46f0-95de-4dd84c48cca0.pdf)**  
researchsquare.com

[127] **[Finetuning-Free Diffusion Model with Adaptive Constraint Guidance for Inorganic Crystal Structure Generation - arXiv](https://arxiv.org/html/2604.13354v1)**  
arxiv.org

[128] **[Deep Learning Meets Crystal Geometry | Research Communities by Springer Nature](https://communities.springernature.com/posts/a-new-frontier-in-catalyst-discovery-deep-learning-meets-crystal-geometry)**  
springernature.com

[129] **[Out-of-Distribution Material Property Prediction Using Adversarial Learning | The Journal of Physical Chemistry C - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jpcc.4c07481)**  
acs.org

[130] **[Knowing When to Quit: A Principled Framework for Dynamic Abstention in LLM Reasoning](https://arxiv.org/html/2604.18419v2)**  
arxiv.org

[131] **[Transfer learning across organic and inorganic materials. (a) Heatmap... - ResearchGate](https://www.researchgate.net/figure/Transfer-learning-across-organic-and-inorganic-materials-a-Heatmap-display-of-290_fig3_336162829)**  
researchgate.net

[132] **[Artificial intelligence for small-molecule chemical probe design: why drug-centric models may not transfer cleanly - Frontiers](https://www.frontiersin.org/journals/drug-discovery/articles/10.3389/fddsv.2026.1836983/full)**  
frontiersin.org

[133] **[Adaptive Individual Uncertainty under Out-Of-Distribution Shift with Expert-Routed Conformal Prediction - arXiv](https://arxiv.org/html/2510.15233v1)**  
arxiv.org

[134] **[Cross-Modal Interaction Fusion-Based Uncertainty-Aware Prediction Method for Industrial Froth Flotation Concentrate Grade by Using a Hybrid SKNet-ViT Framework - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12787880/)**  
nih.gov

[135] **[Dynamic applicability domain (dAD): compound–target binding affinity estimates with local conformal prediction - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10457664/)**  
nih.gov

[136] **[Multi-View Mixture-of-Experts for Predicting Molecular Properties Using SMILES, SELFIES, and Graph-Based - OpenReview](https://openreview.net/pdf/1f7179af049b59922ce925854b40854eeb553458.pdf)**  
openreview.net

[137] **[A dynamic routing-guided interpretable framework for salt–solvent chemistry | Request PDF](https://www.researchgate.net/publication/400946032_A_dynamic_routing-guided_interpretable_framework_for_salt-solvent_chemistry)**  
researchgate.net

[138] **[A survey of contrastive learning methods in molecular representation - Oxford Academic](https://academic.oup.com/bib/article/27/1/bbaf731/8472815)**  
oup.com

[139] **[WDA: An Improved Wasserstein Distance-Based Transfer Learning Fault Diagnosis Method](https://www.mdpi.com/1424-8220/21/13/4394)**  
mdpi.com

[140] **[Transfer Learning for Drug Discovery | Journal of Medicinal Chemistry - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jmedchem.9b02147)**  
acs.org

[141] **[Molecular Similarity-Based Domain Applicability Metric Efficiently Identifies Out-of-Domain Compounds - BHSAI](https://bhsai.org/pubs/Liu_2019_Molecular_Similarity_Based_Domain_Applicability.pdf)**  
bhsai.org

[142] **[Fast 3D Molecule Generation via Unified Geometric Optimal Transport - arXiv](https://arxiv.org/html/2405.15252v1)**  
arxiv.org

[143] **[3-D Inorganic Crystal Structure Generation and Property Prediction via Representation Learning | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.0c00464)**  
acs.org

[144] **[Coarse-Grained Crystal Graph Neural Networks for Reticular Materials Design | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.3c02083)**  
acs.org

[145] **[Probing out-of-distribution generalization in machine learning for materials - ResearchGate](https://www.researchgate.net/publication/387940418_Probing_out-of-distribution_generalization_in_machine_learning_for_materials)**  
researchgate.net

[146] **[Machine learning with asymmetric abstention for biomedical decision-making - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC8549182/)**  
nih.gov

[147] **[Machine learning prediction of materials properties from chemical composition: Status and prospects - AIP Publishing](https://pubs.aip.org/aip/cpr/article/5/4/041313/3328484/Machine-learning-prediction-of-materials)**  
aip.org

[148] **[Predicting reaction conditions from limited data through active transfer learning - Chemical Science (RSC Publishing) DOI:10.1039/D1SC06932B](https://pubs.rsc.org/en/content/articlehtml/2022/sc/d1sc06932b)**  
rsc.org

[149] **[Uncertainty-Aware Expert Allocation for Efficient Multitask Fine-Tuning of Large Language Models - MDPI](https://www.mdpi.com/2306-5729/11/7/172)**  
mdpi.com

[150] **[Personalized Federated Conformal Prediction with Localization - NIPS](https://proceedings.neurips.cc/paper_files/paper/2025/file/930a720c815416c263b0a090448ee901-Paper-Conference.pdf)**  
neurips.cc

[151] **[Scaling Molecular Representation Learning with Hierarchical Mixture-of-Experts - bioRxiv](https://www.biorxiv.org/content/10.1101/2025.08.09.669511v1.full.pdf)**  
biorxiv.org

[152] **[Deep Reinforcement Learning-based Approach for Efficient and Reliable Droplet Routing on MEDA Biochips* - Cyber-Physical Systems Lab - Duke University](https://cpsl.pratt.duke.edu/sites/cpsl.pratt.duke.edu/files/docs/elfar_drl4meda22.pdf)**  
duke.edu

[153] **[ICML Poster LDMol: A Text-to-Molecule Diffusion Model with Structurally Informative Latent Space Surpasses AR Models - ICML 2026](https://icml.cc/virtual/2025/poster/44220)**  
icml.cc

[154] **[Aggregating Residue-Level Protein Language Model Embeddings with Optimal Transport](https://www.biorxiv.org/content/10.1101/2024.01.29.577794v2.full-text)**  
biorxiv.org

[155] **[Practical Applications as a Source of Credibility: A Comparison of Three Fields of Dutch Academic Chemistry - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC3115055/)**  
nih.gov

[156] **[Evaluating molecular similarity measures: Do similarity measures reflect electronic structure properties? | ChemRxiv](https://chemrxiv.org/doi/10.26434/chemrxiv-2025-9zrh0)**  
chemrxiv.org

[157] **[Electron Density Transport During Chemical Reactions | Journal of Chemical Theory and Computation - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jctc.5c01509)**  
acs.org

[158] **[3-D Inorganic Crystal Structure Generation and Property Prediction via Representation Learning - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC7592118/)**  
nih.gov

[159] **[Universal and Experiment-calibrated Prediction of XANES through Crystal Graph Neural Network and Transfer Learning Strategy - arXiv](https://arxiv.org/html/2512.23449v2)**  
arxiv.org

[160] **[[2408.09297] Out-of-distribution materials property prediction using adversarial learning based fine-tuning - arXiv](https://arxiv.org/abs/2408.09297)**  
arxiv.org

[161] **[When Silence Is Golden: Can LLMs Learn to Abstain in Temporal QA and Beyond?](https://www.alphaxiv.org/abs/2602.04755)**  
alphaxiv.org

[162] **[Accelerating materials property prediction via a hybrid Transformer Graph framework that leverages four body interactions - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11742729/)**  
nih.gov

[163] **[Look the Other Way: Designing 'Positive' Molecules with Negative Data via Task Arithmetic](https://arxiv.org/html/2507.17876v1)**  
arxiv.org

[164] **[Uncertainty-Aware First-Principles Exploration of Chemical Reaction Networks | The Journal of Physical Chemistry A - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jpca.3c08386)**  
acs.org

[165] **[TECP: Token-Entropy Conformal Prediction for LLMs - MDPI](https://www.mdpi.com/2227-7390/13/20/3351)**  
mdpi.com

[166] **[Efficient Conformal Prediction via Cascaded Inference with Expanded Admission - OpenReview](https://openreview.net/pdf?id=tnSo6VRLmT)**  
openreview.net

[167] **[Learning Topology-Specific Experts for Molecular Property Prediction](https://ojs.aaai.org/index.php/AAAI/article/view/26000/25772)**  
aaai.org

[168] **[Dynamic Routing and Wavelength Assignment with Reinforcement Learning | INFORMS Journal on Optimization - PubsOnLine](https://pubsonline.informs.org/doi/10.1287/ijoo.2023.0092)**  
informs.org

[169] **[LatentChem: From Textual CoT to Latent Thinking in Chemical Reasoning - arXiv](https://arxiv.org/html/2602.07075v5)**  
arxiv.org

[170] **[Plots of Wasserstein-1 distance between distributions of molecules in... - ResearchGate](https://www.researchgate.net/figure/Plots-of-Wasserstein-1-distance-between-distributions-of-molecules-in-the-generated-and_fig5_353517366)**  
researchgate.net

[171] **[Real-time prediction of 1H and 13C chemical shifts with DFT accuracy using a 3D graph neural network - Royal Society of Chemistry journals](https://pubs.rsc.org/sc/article/12/36/12012/746456/Real-time-prediction-of-1H-and-13C-chemical-shifts)**  
rsc.org

[172] **[Evaluating Molecular Similarity Measures: Do Similarity Measures Reflect Electronic Structure Properties? | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.5c00175)**  
acs.org

[173] **[Quantum optimal transport and interpolations in quantum chemistry - Curves and Surfaces 2026](https://cs2026.sciencesconf.org/710093/document)**  
sciencesconf.org

[174] **[A Padding Method for Enhanced Encoding of Inorganic Structures with Varying Chemical Compositions - arXiv](https://arxiv.org/html/2605.30743v2)**  
arxiv.org

[175] **[Graph convolutional neural networks with global attention for improved materials property prediction - Royal Society of Chemistry journals](https://xlink.rsc.org/?DOI=D0CP01474E)**  
rsc.org

[176] **[DeepMind's GNoME Discovers New Materials - AI Changes Everything](https://patmcguinness.substack.com/p/deepminds-gnome-discovers-new-materials)**  
substack.com

[177] **[Generative Inverse Design with Abstention via Diagonal Flow Matching - arXiv](https://arxiv.org/html/2603.15925v2)**  
arxiv.org

[178] **[Generative models for inverse design of inorganic solid materials - OAE Publishing](https://www.oaepublish.com/articles/jmi.2021.07)**  
oaepublish.com

[179] **[Transfer learning enables discovery of sub-micromolar antibacterials for ESKAPE pathogens from ultra-large chemical spaces - Royal Society of Chemistry journals](https://pubs.rsc.org/en/content/articlelanding/2025/sc/d5sc03055b)**  
rsc.org

[180] **[Assigning Confidence to Molecular Property Prediction - PMC - NIH](https://pmc.ncbi.nlm.nih.gov/articles/PMC9449894/)**  
nih.gov

[181] **[Reproducibility in Machine Learning-based Research: Overview, Barriers and Drivers](https://arxiv.org/html/2406.14325v2)**  
arxiv.org

[182] **[Transfer learning for a foundational chemistry model† | Chemical Science](https://pubs.rsc.org/en/content/articlelanding/2024/sc/d3sc04928k)**  
rsc.org

[183] **[Leveraging quantum chemical properties in transfer learning for predicting blood-brain barrier permeability of drugs - The Raj Group](https://raj.emorychem.science/wp-content/uploads/2025/11/BBB-paper.pdf)**  
emorychem.science

[184] **[Learning Continuous Solvent Effects from Transient Flow Data: A Graph Neural Network Benchmark on Catechol Rearrangement - arXiv](https://arxiv.org/html/2512.19530v1)**  
arxiv.org

[185] **[AI Catalyst Discovery in Chemistry: 18 Updated Directions (2026) - Yenra](https://yenra.com/ai20/catalyst-discovery-in-chemistry/)**  
yenra.com

[186] **[DFT-Assisted Microkinetic Study of Transfer Hydrogenation over Homogeneous and Immobilized Cp*Ir Complexes](https://eprints.whiterose.ac.uk/id/eprint/224573/1/Benzaldehyde_jp-2024-08718x_accepted.pdf)**  
whiterose.ac.uk

[187] **[Machine Learning Strategies for Reaction Development: Toward the Low-Data Limit - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11163943/)**  
nih.gov

[188] **[Robust Estimation and Inference with Selective Borrowing in Hybrid Controlled Trials: A Tutorial with SelectiveIntegrative and i - arXiv](https://arxiv.org/pdf/2607.00350)**  
arxiv.org

[189] **[Understanding the Limitations of Deep Models for Molecular property prediction: Insights and Solutions | OpenReview](https://openreview.net/forum?id=NLFqlDeuzt)**  
openreview.net

[190] **[Full article: pinax: a provenance management system for materials data science](https://www.tandfonline.com/doi/full/10.1080/27660400.2026.2629051)**  
tandfonline.com

[191] **[M-JEPA: Predictive Self-Supervised Learning for Molecular Graphs with Scaffold-Shift Evaluation on Tox21 | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.6c00828)**  
acs.org

[192] **[Transfer learning graph representations of molecules for pKa, 13 C-NMR, and solubility](https://cdnsciencepub.com/doi/10.1139/cjc-2023-0152)**  
cdnsciencepub.com

[193] **[Machine Learning Strategies for Reaction Development: Toward the Low-Data Limit](https://pubs.acs.org/doi/10.1021/acs.jcim.3c00577)**  
acs.org

[194] **[Heterogeneous vs. Homogeneous Catalysis: Mechanistic Comparisons - ResearchGate](https://www.researchgate.net/publication/397263896_Heterogeneous_vs_Homogeneous_Catalysis_Mechanistic_Comparisons)**  
researchgate.net

[195] **[Learning Hierarchical Representations for Explainable Chemical Reaction Prediction](https://www.mdpi.com/2076-3417/13/9/5311)**  
mdpi.com

[196] **[Improving randomized controlled trial analysis via data-adaptive borrowing - PMC - NIH](https://pmc.ncbi.nlm.nih.gov/articles/PMC11972012/)**  
nih.gov

[197] **[Property-Aware Relation Networks for Few-Shot Molecular Property Prediction](https://proceedings.neurips.cc/paper/2021/file/91bc333f6967019ac47b49ca0f2fa757-Paper.pdf)**  
neurips.cc

[198] **[ESAMP: event-sourced architecture for materials provenance management and application to accelerated materials discovery - Royal Society of Chemistry journals](https://pubs.rsc.org/en/content/articlehtml/2023/dd/d3dd00054k)**  
rsc.org

[199] **[TL-GINDTI: Graph-based Transfer Learning for Drug–target Interaction Prediction - Open Academic Journals Index](https://oaji.net/pdfs.html?n=2026/3603-1776492703.pdf)**  
oaji.net

[200] **[Paradigm Shift: The Promise of Deep Learning in Molecular Systems Engineering and Design - Frontiers](https://www.frontiersin.org/journals/chemical-engineering/articles/10.3389/fceng.2021.700717/full)**  
frontiersin.org

[201] **[Deep Transfer Learning for UAV-Based Cross-Crop Yield Prediction in Root Crops - MDPI](https://www.mdpi.com/2072-4292/17/24/4054)**  
mdpi.com

[202] **[Prospective active transfer learning on the formal coupling of amines and carboxylic acids to form secondary alkyl bonds - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12593407/)**  
nih.gov

[203] **[Single-Atom Catalysis: An Analogy between Heterogeneous and Homogeneous Catalysts - ACS Publications](https://pubs.acs.org/doi/10.1021/bk-2020-1360.ch001)**  
acs.org

[204] **[Lesson 4.2: Chemical Reactions - Biology LibreTexts](https://bio.libretexts.org/Workbench/Human_Physiology%3A_A_Students_Open_Path_to_Understanding_the_Body/04%3A_Energy_Metabolism_and_the_Central_Dogma/4.02%3A_Chemical_Reactions)**  
libretexts.org

[205] **[Enhancing Statistical Validity and Power in Hybrid Controlled Trials: A Randomization Inference Approach with Conformal Selective Borrowing | OpenReview](https://openreview.net/forum?id=WvanLeuEAC)**  
openreview.net

[206] **[Distance-Aware Molecular Property Prediction in Nonlinear Structure–Property Space | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.5c01037)**  
acs.org

[207] **[Data leakage detection in machine learning code: transfer learning, active learning, or low-shot prompting? - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11935776/)**  
nih.gov

[208] **[Scaffold based fold splits a The scaffold extraction procedure is... - ResearchGate](https://www.researchgate.net/figure/Scaffold-based-fold-splits-a-The-scaffold-extraction-procedure-is-illustrated-on-the_fig3_356842612)**  
researchgate.net

[209] **[Understanding Polymers Through Transfer Learning and Explainable AI - MDPI](https://www.mdpi.com/2076-3417/14/22/10413)**  
mdpi.com

[210] **[MetaRF: attention-based random forest for reaction yield prediction with a few trails - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10084704/)**  
nih.gov

[211] **[Boosting Computational Catalysis and Chemical Reactivity with Artificial Intelligence - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC13081113/)**  
nih.gov

[212] **[Heterogeneous catalysis - Wikipedia](https://en.wikipedia.org/wiki/Heterogeneous_catalysis)**  
wikipedia.org

[213] **[Chemical Reactivity - MSU chemistry](https://www2.chemistry.msu.edu/faculty/reusch/virttxtjml/chapt4.htm)**  
msu.edu

[214] **[ICML Poster Enhancing Statistical Validity and Power in Hybrid Controlled Trials: A Randomization Inference Approach with Conformal Selective Borrowing](https://icml.cc/virtual/2025/poster/44990)**  
icml.cc

[215] **[Consistent semantic representation learning for out-of-distribution molecular property prediction | Briefings in Bioinformatics | Oxford Academic](https://academic.oup.com/bib/article/26/2/bbaf147/8109670)**  
oup.com

[216] **[A Leakage-Aware Multimodal Machine Learning Framework for Nutrition Supply–Demand Forecasting Using Temporal and Spatial Data Fusion - MDPI](https://www.mdpi.com/2073-431X/15/3/156)**  
mdpi.com

[217] **[A Leakage-Aware Drug Discovery Workflow for PKM2 and MAPK1 Integrating Scaffold Validation, Molecular Docking and Structural Triage - MDPI](https://www.mdpi.com/1422-0067/27/11/4751)**  
mdpi.com

[218] **[Machine learning-based yield prediction for transition metal-catalyzed cross-coupling reactions | Request PDF - ResearchGate](https://www.researchgate.net/publication/386382489_Machine_learning-based_yield_prediction_for_transition_metal-catalyzed_cross-coupling_reactions)**  
researchgate.net

[219] **[(PDF) Transfer learning across different photocatalytic organic reactions - ResearchGate](https://www.researchgate.net/publication/390664739_Transfer_learning_across_different_photocatalytic_organic_reactions)**  
researchgate.net

[220] **[Olefin metathesis: what have we learned about homogeneous and heterogeneous catalysts from surface organometallic chemistry?† | Chemical Science](https://pubs.rsc.org/en/content/articlelanding/2021/sc/d0sc06880b)**  
rsc.org

[221] **[Prototype-Guided Latent Alignment for Data-Efficient Fine-Tuning of Molecular Foundation Models - ResearchGate](https://www.researchgate.net/publication/405428845_Prototype-Guided_Latent_Alignment_for_Data-Efficient_Fine-Tuning_of_Molecular_Foundation_Models)**  
researchgate.net

[222] **[Minimum Wasserstein distance estimator under covariate shift: closed-form, super-efficiency and irregularity - arXiv](https://arxiv.org/html/2601.07282v1)**  
arxiv.org

[223] **[The topology of molecular representations and its influence on machine learning performance - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12281805/)**  
nih.gov

[224] **[Machine Learning with Conformal Prediction for Predictive Maintenance tasks in Industry 4.0 - DiVA Portal](https://www.diva-portal.org/smash/get/diva2:1765779/FULLTEXT01.pdf)**  
diva-portal.org

[225] **[Conformal Selection for Efficient and Accurate Compound Screening in Drug Discovery - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv-2024-pf3ph)**  
chemrxiv.org

[226] **[Reliable Molecular Retrieval from Mass Spectra using Conformal Prediction - bioRxiv](https://www.biorxiv.org/content/10.64898/2026.03.12.711424v1.full)**  
biorxiv.org

[227] **[Class-Conditional Conformal Prediction for Reliable Anomaly Detection Under Extreme Class Imbalance - MDPI](https://www.mdpi.com/2504-4990/8/7/190)**  
mdpi.com

[228] **[Cross-chemical and cross-species toxicity prediction: Benchmarking and a novel 3D-structure-based deep learning model | Environmental Toxicology and Chemistry | Oxford Academic](https://academic.oup.com/etc/advance-article/doi/10.1093/etojnl/vgag081/8555591)**  
oup.com

[229] **[Active Learning for Rapid Targeted Synthesis of Compositionally Complex Alloys - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11355945/)**  
nih.gov

[230] **[When should we trust the annotation? Selective prediction for molecular structure retrieval from mass spectra - arXiv](https://arxiv.org/pdf/2603.10950)**  
arxiv.org

[231] **[USE-INSPIRED BAYESIAN OPTIMIZATION FOR ENGINEERING DESIGN: FROM MATERIALS AND 3D PRINTING TO CIRCUITS By ALALEH AHMADIANSHALCHI](https://eecs.wsu.edu/~jana/pubs/Alaleh%20Ahmadian%20PhD%20Thesis.pdf)**  
wsu.edu

[232] **[Information-Theoretic Generalization Bounds for Batch Reinforcement Learning - MDPI](https://www.mdpi.com/1099-4300/26/11/995)**  
mdpi.com

[233] **[Auditing Domain Alignment in Latent Representations for Cross-Domain Materials Machine Learning - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv-2026-d4qw9)**  
chemrxiv.org

[234] **[Hybrid Wasserstein Distance: An Approximation for Optimal Transport Distances - MDPI](https://www.mdpi.com/2079-3197/14/3/57)**  
mdpi.com

[235] **[Molecular Similarity in Chemical Informatics and Predictive Toxicity Modeling - LJMU Research Online](https://researchonline.ljmu.ac.uk/id/eprint/23907/3/Molecular%20Similarity%20in%20Chemical%20Informatics%20and%20Predictive%20Toxicity%20Modeling.pdf)**  
ljmu.ac.uk

[236] **[Model Uncertainty Quantification by Conformal Prediction in Continual Learning](https://icml.cc/virtual/2025/poster/45394)**  
icml.cc

[237] **[Conformal Selection for Efficient and Accurate Compound Screening in Drug Discovery - Mathematics and Statistics](https://www.math.mcgill.ca/yyang/papers/JCIM_CSdrug.pdf)**  
mcgill.ca

[238] **[Reliable machine learning models in genomic medicine using conformal prediction](https://www.medrxiv.org/content/10.1101/2024.09.09.24312995v2.full-text)**  
medrxiv.org

[239] **[Selective Omniprediction and Fair Abstention - NIPS](https://proceedings.neurips.cc/paper_files/paper/2025/file/3826a7e2a07ee41ca42eaf57ed337df4-Paper-Conference.pdf)**  
neurips.cc

[240] **[(PDF) A meta-learning framework to mitigate negative transfer in transfer learning applicable to drug design - ResearchGate](https://www.researchgate.net/publication/396373890_A_meta-learning_framework_to_mitigate_negative_transfer_in_transfer_learning_applicable_to_drug_design)**  
researchgate.net

[241] **[Decoding orthogonal geochemical fingerprints in complex soil matrices via multi-model consensus machine learning for high-fidelity forensic provenance | Analytical Methods | The Royal Society of Chemistry](https://pubs.rsc.org/sign-in?returnUrl=%2Fay%2Farticle%2Fdoi%2F10.1039%2Fd6ay01029f%2F1278194%2FDecoding-orthogonal-geochemical-fingerprints-in)**  
rsc.org

[242] **[Transfer learning from first-principles calculations to experiments with chemistry-informed domain transformation - arXiv](https://arxiv.org/html/2504.02848v1)**  
arxiv.org

[243] **[SELECTIVE PREDICTION UNDER DOMAIN SHIFT FOR QUESTION ANSWERING A DISSERTATION SUBMITTED TO THE DEPARTMENT OF COMPUTER SCIENCE AN - Amita Kamath](https://amitakamath.github.io/thesis.pdf)**  
github.io

[244] **[Batch Bayesian Optimization Design for Optimizing a Neurostimulator - Oxford Academic](https://academic.oup.com/biometrics/article/77/2/661/7445071)**  
oup.com

[245] **[On Transferring Transferability: Towards a Theory for Size Generalization](https://proceedings.neurips.cc/paper_files/paper/2025/file/60b393761eea35bf491687c46e4f1a5a-Paper-Conference.pdf)**  
neurips.cc

[246] **[Breaking Isometric Ties and Introducing Priors in Gromov-Wasserstein Distances - Proceedings of Machine Learning Research](https://proceedings.mlr.press/v238/demetci24a/demetci24a.pdf)**  
mlr.press

[247] **[iSIM: instant similarity† | Digital Discovery | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlelanding/2024/dd/d4dd00041b)**  
rsc.org

[248] **[Uncertainty Quantification for Learning-based MPC using Weighted Conformal Prediction | George J. Pappas](https://www.georgejpappas.org/wp-content/uploads/2023/12/Uncertainty_Quantification_for_Learning-based_MPC_using_Weighted_Conformal_Prediction.pdf)**  
georgejpappas.org

[249] **[Conformal Selection for Efficient and Accurate Compound ...](https://www.researchgate.net/publication/398505154_Conformal_Selection_for_Efficient_and_Accurate_Compound_Screening_in_Drug_Discovery)**  
researchgate.net

[250] **[Exploring the performance of Conformal Prediction on Chemical Properties and Its Influencing Factors - DiVA Portal](https://www.diva-portal.org/smash/get/diva2:1869301/FULLTEXT01.pdf)**  
diva-portal.org

[251] **[Partial-Label Learning with Conformal Candidate Cleaning - arXiv](https://arxiv.org/html/2502.07661v2)**  
arxiv.org

[252] **[US11689566B2 - Detecting and mitigating poison attacks using data provenance - Google Patents](https://patents.google.com/patent/US11689566B2/en)**  
google.com

[253] **[Machine learning application in molecular science research field](https://arabjchem.org/machine-learning-application-in-molecular-science-research-field/)**  
arabjchem.org

[254] **[Machine learning meets mechanistic modelling for accurate prediction of experimental activation energies† | Chemical Science | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlelanding/2021/sc/d0sc04896h)**  
rsc.org

[255] **[$\texttt{LLINBO}$: Trustworthy LLM-in-the-Loop Bayesian Optimization | OpenReview](https://openreview.net/forum?id=39CEoMXTHh)**  
openreview.net

[256] **[Transfer Learning with Kernel Methods - PMC - NIH](https://pmc.ncbi.nlm.nih.gov/articles/PMC10492830/)**  
nih.gov

[257] **[A universal foundation model for transfer learning in molecular crystals† | Chemical Science | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlelanding/2025/sc/d5sc00677e)**  
rsc.org

[258] **[Wasserstein Distance Learns Domain Invariant Feature Representations for Drift Compensation of E-Nose - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC6749200/)**  
nih.gov

[259] **[Structural Similarity Methodologies for Small Molecules - Certara](https://www.certara.com/blog/structural-similarity-methodologies-for-small-molecules/)**  
certara.com

[260] **[Conformalized Transfer Learning for Li-ion Battery State of Health Forecasting under Manufacturing and Usage Variability - arXiv](https://arxiv.org/pdf/2603.24475)**  
arxiv.org

[261] **[Online Conformal Selection with Accept-to-Reject Changes - AAAI Publications](https://ojs.aaai.org/index.php/AAAI/article/view/39551/43512)**  
aaai.org

[262] **[Predicting Off-Target Binding Profiles With Confidence Using Conformal Prediction - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC6233526/)**  
nih.gov

[263] **[Classification with Abstention but Without Disparities - Proceedings of Machine Learning Research](https://proceedings.mlr.press/v161/schreuder21a/schreuder21a.pdf)**  
mlr.press

[264] **[Enhancing Drug-Target Interaction Prediction through Transfer Learning from Activity Cliff Prediction Tasks - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12264954/)**  
nih.gov

[265] **[Active Machine Learning for Chemical Engineers: A Bright Future Lies Ahead!](https://www.engineering.org.cn/engi/EN/10.1016/j.eng.2023.02.019)**  
engineering.org.cn

[266] **[Predicting Organic Reaction Outcomes with Weisfeiler-Lehman Network - NIPS](https://proceedings.neurips.cc/paper_files/paper/6854-predicting-organic-reaction-outcomes-with-weisfeiler-lehman-network.pdf)**  
neurips.cc

[267] **[Collaborative and Distributed Bayesian Optimization via Consensus: Showcasing the Power of Collaboration for Optimal Design - arXiv](https://arxiv.org/html/2306.14348v2)**  
arxiv.org

[268] **[The Generalization Crisis: Are Chemical AI Models Learning Science, or Just Memorizing Beaker Metrics? - Research Communities](https://communities.springernature.com/posts/the-generalization-crisis-are-chemical-ai-models-learning-science-or-just-memorizing-beaker-metrics)**  
springernature.com

[269] **[LatentChem: From Textual CoT to Latent Thinking in Chemical Reasoning - arXiv](https://arxiv.org/html/2602.07075v4)**  
arxiv.org

[270] **[Interpretable bilinear attention network with domain adaptation improves drug-target prediction - White Rose Research Online](https://eprints.whiterose.ac.uk/id/eprint/195230/)**  
whiterose.ac.uk

[271] **[Full article: Topological representations of crystal structures: generation, analysis and implementation in the TopCryst system - Taylor & Francis](https://www.tandfonline.com/doi/full/10.1080/27660400.2022.2088041)**  
tandfonline.com

[272] **[Neural Conformal Control for Time Series Forecasting - AAAI Publications](https://ojs.aaai.org/index.php/AAAI/article/view/34029/36184)**  
aaai.org

[273] **[Predicting Endocrine Disruption Using Conformal Prediction – A Prioritization Strategy to Identify Hazardous Chemicals with Confidence - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC9846826/)**  
nih.gov

[274] **[Applying Mondrian Cross-Conformal Prediction To Estimate Prediction Confidence on Large Imbalanced Bioactivity Data Sets | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.7b00159)**  
acs.org

[275] **[Do Large Language Models Know When Not to Answer in Medical QA? - ACL Anthology](https://aclanthology.org/2025.uncertainlp-main.4.pdf)**  
aclanthology.org

[276] **[Model predictive control of nonlinear processes using transfer learning-based recurrent neural networks - UCLA PDC Lab](http://pdclab.seas.ucla.edu/Publications/MAlhajeri/Alhajeri_2024.pdf)**  
ucla.edu

[277] **[Supervised Source-Task Pretraining for Low-Data ... - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv.15003831)**  
chemrxiv.org

[278] **[Transferability of Data Sets between Machine-Learned Interatomic Potential Algorithms | Journal of Chemical Theory and Computation - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jctc.5c00272)**  
acs.org

[279] **[Uncertainty-Aware Protein-Ligand Binding Mode Prediction with ...](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv.15003967)**  
chemrxiv.org

[280] **[A Holistic Data-Driven Approach to Synthesis Predictions of Colloidal Nanocrystal Shapes | Journal of the American Chemical Society](https://pubs.acs.org/doi/10.1021/jacs.4c17283)**  
acs.org

[281] **[Transfer Learning from Lithium-Ion to Zinc-Ion Batteries ... - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv.15002657/v2)**  
chemrxiv.org

[282] **[Scientific Misconduct: A Global Concern - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC6133788/)**  
nih.gov

[283] **[Detection of multi-reference character imbalances enables a transfer learning approach for virtual high throughput screening wit - Royal Society of Chemistry journals](https://pubs.rsc.org/en/content/articlepdf/2022/sc/d2sc00393g)**  
rsc.org

[284] **[(PDF) An Analysis of the Falsification Criterion of Karl Popper: A Critical Review](https://www.researchgate.net/publication/339791892_An_Analysis_of_the_Falsification_Criterion_of_Karl_Popper_A_Critical_Review)**  
researchgate.net

[285] **[What Is Transfer Learning: Accelerate Your R&D in 2026 - Polymerize](https://polymerize.io/knowledge-hub/blogs/what-is-transfer-learning-accelerate-your-r-d-in-2026)**  
polymerize.io

[286] **[Borrower Defense to Repayment Application | Federal Student Aid](https://studentaid.gov/sites/default/files/borrower-defense-application.pdf)**  
studentaid.gov

[287] **[Publications - MLPDS - MIT](https://mlpds.mit.edu/papers/)**  
mit.edu

[288] **[34 CFR Part 668 Subpart F -- Misrepresentation - eCFR](https://www.ecfr.gov/current/title-34/subtitle-B/chapter-VI/part-668/subpart-F)**  
ecfr.gov

[289] **[Transfer Learning Method for Bearing Fault Diagnosis Based on Fully Convolutional Conditional Wasserstein Adversarial Networks - ResearchGate](https://www.researchgate.net/publication/351554433_Transfer_Learning_Method_for_Bearing_Fault_Diagnosis_Based_on_Fully_Convolutional_Conditional_Wasserstein_Adversarial_Networks)**  
researchgate.net

[290] **[Student Assistance General Provisions, Federal Perkins Loan Program, Federal Family Education Loan Program, William D. Ford Federal Direct Loan Program, and Teacher Education Assistance for College and Higher Education Grant Program - Federal Register](https://www.federalregister.gov/documents/2016/11/01/2016-25448/student-assistance-general-provisions-federal-perkins-loan-program-federal-family-education-loan)**  
federalregister.gov

[291] **[Pause and Reflect: Conformal Aggregation for Chain-of-Thought Reasoning - arXiv](https://arxiv.org/html/2605.14098v1)**  
arxiv.org

[292] **[Conformal selective prediction with cost aware deferral for safe clinical triage under distribution shift - ResearchGate](https://www.researchgate.net/publication/401007070_Conformal_selective_prediction_with_cost_aware_deferral_for_safe_clinical_triage_under_distribution_shift)**  
researchgate.net

[293] **[SafePredict: a meta-algorithm for machine learning to ... - SBBD](https://sbbd.org.br/2018/wp-content/uploads/sites/5/2018/08/keynote-shasha.pdf)**  
sbbd.org.br

[294] **[Enhancing Statistical Validity and Power in Hybrid Controlled Trials: A Randomization Inference Approach with Conformal Selectiv - arXiv](https://arxiv.org/pdf/2410.11713)**  
arxiv.org

[295] **[Electron Transfer and Negative Ion Formation | The Journal of Physical Chemistry Letters](https://pubs.acs.org/doi/abs/10.1021/acs.jpclett.5c01686)**  
acs.org

[296] **[AI Hypothesis Generation in Biology: A Practical Framework for ...](https://purna.ai/blog/ai-hypothesis-generation-in-biology-a-practical-framework-for-researchers/)**  
purna.ai

[297] **[Transferable Learning of Reaction Pathways from Geometric Priors - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jpclett.5c02620)**  
acs.org

[298] **[Local structure order parameters and site fingerprints for quantification of coordination environment and crystal structure similarity† | RSC Advances | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlelanding/2020/ra/c9ra07755c)**  
rsc.org

[299] **[A meta-learning framework to mitigate negative transfer in transfer learning applicable to drug design - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12511290/)**  
nih.gov

[300] **[RLVR Datasets and Where to Find Them: Tracing Data Lineage for Better Training Data - arXiv](https://arxiv.org/html/2605.26971v1)**  
arxiv.org

[301] **[Ten simple rules for executing an inherited research plan in computational biology](https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1014357)**  
plos.org

[302] **[Online Active Learning with Surrogate Loss Functions](https://proceedings.neurips.cc/paper_files/paper/2021/file/c1619d2ad66f7629c12c87fe21d32a58-Paper.pdf)**  
neurips.cc

[303] **[Taming Variability: Randomized and Bootstrapped Conformal Risk Control for LLMs - arXiv](https://arxiv.org/html/2509.23007v1)**  
arxiv.org

[304] **[Online Selective Conformal Prediction - Emergent Mind](https://www.emergentmind.com/topics/online-selective-conformal-prediction)**  
emergentmind.com

[305] **[A Pitfall in Conformal Prediction: When Shorter Intervals Are Not Better | OpenReview](https://openreview.net/forum?id=ularVAZFjX)**  
openreview.net

[306] **[Learning Across Boundaries: Statistical and Machine Learning Methods for Biomedical Data Fusion - AI Evolution](https://ww3.aievolution.com/JSMAnnual2026/Events/viewEv?ev=5694)**  
aievolution.com

[307] **[Transductive Learning for Out-of-Distribution Molecular Property Prediction | OpenReview](https://openreview.net/forum?id=rmvO5WRb58)**  
openreview.net

[308] **[How not to be seen: predicting unseen enzyme functions using contrastive learning](https://academic.oup.com/bioinformatics/article/42/Supplement_1/btag215/8726303)**  
oup.com

[309] **[Transferable Learning of Reaction Pathways from Geometric Priors - arXiv](https://arxiv.org/html/2504.15370v1)**  
arxiv.org

[310] **[ChemEnv: a fast and robust coordination environment identification tool - PMC - NIH](https://pmc.ncbi.nlm.nih.gov/articles/PMC7412753/)**  
nih.gov

[311] **[ChemLint: Conversational Cheminformatics with Large Language Models - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv.15000386)**  
chemrxiv.org

[312] **[A Comparison of Machine Learning Approaches for predicting Hepatotoxicity potential using Chemical Structure and Targeted Transcriptomic Data - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11235188/)**  
nih.gov

[313] **[Determining Provenance from Compositional Data - Cambridge University Press & Assessment](https://www.cambridge.org/core/elements/determining-provenance-from-compositional-data/EBA8ADCE476A920F8E39311EF011D367)**  
cambridge.org

[314] **[Adaptive Learning with Gaussian Process Regression: A Comprehensive Review of Methods and Applications - MDPI](https://www.mdpi.com/2504-4990/8/4/101)**  
mdpi.com

[315] **[Conformal Triage for Medical Imaging AI Deployment - medRxiv](https://www.medrxiv.org/content/10.1101/2024.02.09.24302543v1.full-text)**  
medrxiv.org

[316] **[Class-Conditional Conformal Prediction with Many Classes - Stat.berkeley.edu](https://www.stat.berkeley.edu/~ryantibs/papers/classconf.pdf)**  
berkeley.edu

[317] **[Conformal Regression with Reject Option - GitHub](https://raw.githubusercontent.com/mlresearch/v230/main/assets/johansson24a/johansson24a.pdf)**  
githubusercontent.com

[318] **[Electron transfer collisions with spatially oriented CH3CN - The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlelanding/2000/cp/a908275a)**  
rsc.org

[319] **[ProtoMol: enhancing molecular property prediction via prototype-guided multimodal learning | Briefings in Bioinformatics | Oxford Academic](https://academic.oup.com/bib/article/26/6/bbaf629/8374029)**  
oup.com

[320] **[PREFMoDeL: A Systematic Review and Proposed Taxonomy of Biomolecular Features for Deep Learning - MDPI](https://www.mdpi.com/2076-3417/13/7/4356)**  
mdpi.com

[321] **[Transition State Searching Accelerated by Deep Learning Potential - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv-2024-pvttd)**  
chemrxiv.org

[322] **[ChemEnv : A Fast and Robust Coordination Environment Identification Tool - Kristin Persson](https://perssongroup.lbl.gov/papers/ChemEnv___A_Fast_and_Robust_Coordination_Environment_Identification_Tool_v1.pdf)**  
lbl.gov

[323] **[Capturing End-To-End Provenance for Machine Learning Pipelines - ResearchGate](https://www.researchgate.net/publication/387307405_Capturing_End-To-End_Provenance_for_Machine_Learning_Pipelines)**  
researchgate.net

[324] **[Deep Learning Methods for Small Molecule Drug Discovery: A Survey](https://www.computer.org/csdl/journal/ai/2024/02/10058590/1LdkkKN9ZoQ)**  
computer.org

[325] **[Transfer Learning Based Multi-fidelity Surrogate Model for Lithium-ion Battery Pack](http://cs230.stanford.edu/projects_fall_2022/reports/61.pdf)**  
stanford.edu

[326] **[Provenance and distribution of potentially toxic elements (PTEs) in stream sediments from the eastern Hg-district of Mt. Amiata (central Italy) - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11925987/)**  
nih.gov

[327] **[Sample Efficient Learning of Predictors that Complement Humans](https://proceedings.mlr.press/v162/charusaie22a/charusaie22a.pdf)**  
mlr.press

[328] **[SCOPE: Selective Conformal Optimized Pairwise LLM Judging - arXiv](https://arxiv.org/html/2602.13110v3)**  
arxiv.org

[329] **[Enterprise Disk Drive Scrubbing Based on Mondrian Conformal Predictors - Proceedings of Machine Learning Research](https://proceedings.mlr.press/v204/vishwakarma23a/vishwakarma23a.pdf)**  
mlr.press

[330] **[Classification With Reject Option Using Conformal Prediction - DiVA Portal](https://www.diva-portal.org/smash/get/diva2:1259677/FULLTEXT01.pdf)**  
diva-portal.org

[331] **[Enhancing Statistical Validity and Power in Hybrid Controlled Trials: A Randomization Inference Approach with Conformal Selective Borrowing - arXiv](https://arxiv.org/html/2410.11713v1)**  
arxiv.org

[332] **[Activity Cliff-Informed Contrastive Learning for Molecular Property ...](https://pdfs.semanticscholar.org/5242/230c716cc412238039a88c1054aaa68c1ba3.pdf)**  
semanticscholar.org

[333] **[Falsifiability of evolution? - Reddit](https://www.reddit.com/r/evolution/comments/1id6u5g/falsifiability_of_evolution/)**  
reddit.com

[334] **[Adaptive Transition-State Refinement with Learned Equilibrium Flows - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.5c02902)**  
acs.org

[335] **[(a−c) Crystal structures and close-up views of the coordination... - ResearchGate](https://www.researchgate.net/figure/a-c-Crystal-structures-and-close-up-views-of-the-coordination-polyhedra-in-a-RZnBr_fig1_329977451)**  
researchgate.net

[336] **[AI-driven multi-omics integration in precision oncology: bridging the data deluge to clinical decisions - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12634751/)**  
nih.gov

[337] **[Hash Collisions in Molecular Fingerprints: Effects on Property Prediction and Bayesian Optimization - arXiv](https://arxiv.org/html/2511.17078v1)**  
arxiv.org

[338] **[Transfer Learning to Leverage All Data for Machine-Learnt Climate Model Emulation - AWS](https://ccai-papers.s3.us-east-1.amazonaws.com/neurips2022/29/paper.pdf)**  
amazonaws.com

[339] **[12/07/2026 09:07 Exploratory Data Analysis / Li Vigni, M., Durante, C., Cocchi, M. (DATA HANDLING IN SCIENCE AND TECHNOLOGY). - - IRIS Unimore](https://iris.unimore.it/bitstream/11380/971504/2/Exploratorypostprint.pdf)**  
unimore.it

[340] **[ADO-LLM: Analog Design Bayesian Optimization with In-Context Learning of Large Language Models - arXiv](https://arxiv.org/html/2406.18770v2)**  
arxiv.org

[341] **[Selection and Aggregation of Conformal Prediction Sets | Request PDF - ResearchGate](https://www.researchgate.net/publication/379917379_Selection_and_Aggregation_of_Conformal_Prediction_Sets)**  
researchgate.net

[342] **[Distribution-free, Risk-controlling Prediction Sets | Request PDF - ResearchGate](https://www.researchgate.net/publication/357462027_Distribution-free_Risk-controlling_Prediction_Sets)**  
researchgate.net

[343] **[Partial Causal Structure Learning for Valid Selective Conformal Inference under Interventions - arXiv](https://arxiv.org/html/2603.02204v2)**  
arxiv.org

[344] **[Decision Theoretic Foundations for Conformal Prediction: Optimal Uncertainty Quantification for Risk-Averse Agents | OpenReview](https://openreview.net/forum?id=Ukjl86EsIk)**  
openreview.net

[345] **[Selective Information Borrowing for Region-Specific Treatment Effect Inference under Covariate Mismatch in Multi-Regional Clinical Trials - ResearchGate](https://www.researchgate.net/publication/400414622_Selective_Information_Borrowing_for_Region-Specific_Treatment_Effect_Inference_under_Covariate_Mismatch_in_Multi-Regional_Clinical_Trials)**  
researchgate.net

[346] **[Electron Transfer Reactions: a Treatise](http://article.sapub.org/10.5923.j.chemistry.20120202.11.html)**  
sapub.org

[347] **[A Systematic Survey and Benchmark of Deep Learning for Molecular Property Prediction in the Foundation Model Era - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv.15002208)**  
chemrxiv.org

[348] **[Active Inference AI Systems for Scientific Discovery - arXiv](https://arxiv.org/html/2506.21329v4)**  
arxiv.org

[349] **[Learning Condensed Graph via Differentiable Atom Mapping for Reaction Yield Prediction](https://icml.cc/virtual/2025/poster/43812)**  
icml.cc

[350] **[Coordinative Alignment in the Pores of MOFs for the Structural Determination of N‐, S‐, and P‐Containing](https://yaghi.berkeley.edu/pdfPublications/19CAL.pdf)**  
berkeley.edu

[351] **[Look the Other Way: Designing 'Positive' Molecules with Negative Data via Task Arithmetic](https://arxiv.org/html/2507.17876v2)**  
arxiv.org

[352] **[Widespread data leakage inflates accuracy and corrupts biomarker discovery in cancer drug response prediction | bioRxiv](https://www.biorxiv.org/content/10.64898/2026.02.05.704016v2.full-text)**  
biorxiv.org

[353] **[Hash-Based Deep Learning Approach for Remote Sensing Satellite Imagery Detection](https://www.mdpi.com/2073-4441/14/5/707)**  
mdpi.com

[354] **[Physics-Informed Transfer Learning for Process Control Applications - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.iecr.4c02781)**  
acs.org

[355] **[Data Science Methods for Real-World Evidence Generation in Real-World Data - Annual Reviews](https://www.annualreviews.org/content/journals/10.1146/annurev-biodatasci-102423-113220?crawler=true&mimetype=application/pdf)**  
annualreviews.org

[356] **[Active learning for adaptive surrogate model improvement in high-dimensional problems](https://pmc.ncbi.nlm.nih.gov/articles/PMC11236939/)**  
nih.gov

[357] **[(PDF) Look Again Before You Abstain:Budgeted Conformal ...](https://www.researchgate.net/publication/407115545_Look_Again_Before_You_AbstainBudgeted_Conformal_Evidence_Acquisition_for_Reliable_Vision-Language_Model/download)**  
researchgate.net

[358] **[Borrowing Treasures From the Wealthy: Deep Transfer Learning Through Selective Joint Fine-Tuning - CVF Open Access](https://openaccess.thecvf.com/content_cvpr_2017/papers/Ge_Borrowing_Treasures_From_CVPR_2017_paper.pdf)**  
thecvf.com

[359] **[Bayesian Optimization with Conformal Prediction Sets | NSF Public Access Repository](https://par.nsf.gov/biblio/10421379-bayesian-optimization-conformal-prediction-sets)**  
nsf.gov

[360] **[Adaptive Decision Making](https://statml.engin.umich.edu/research/adaptive-decision-making/)**  
umich.edu

[361] **[An introduction to domain adaptation and transfer learning - arXiv](https://arxiv.org/pdf/1812.11806)**  
arxiv.org

[362] **[Emerging Technologies in Chemical Threat Reduction - Austin Publishing Group](https://austinpublishinggroup.com/bioterrorism-biosecurity-biodefense/fulltext/ajbbb-v6-id1011.php)**  
austinpublishinggroup.com

[363] **[Evaluating generalizability of artificial intelligence models for molecular datasets - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10925170/)**  
nih.gov

[364] **[End-to-end sequence-structure-function meta-learning predicts genome-wide chemical-protein interactions for dark proteins - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC9886305/)**  
nih.gov

[365] **[Transfer Learning for Chemical Property Prediction: A Practical Primer - ChemCopilot](https://www.chemcopilot.com/blog/transfer-learning-for-chemical-property-prediction-a-practical-primer)**  
chemcopilot.com

[366] **[[2606.16667] Look Again Before You Abstain:Budgeted Conformal Evidence Acquisition for Reliable Vision-Language Model - arXiv](https://arxiv.org/abs/2606.16667)**  
arxiv.org

[367] **[Bayesian selective response‐adaptive design using the historical control - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC6221103/)**  
nih.gov

[368] **[Online Calibrated and Conformal Prediction Improves Bayesian Optimization - PMC - NIH](https://pmc.ncbi.nlm.nih.gov/articles/PMC11482741/)**  
nih.gov

[369] **[Efficient Active Learning with Abstention - NIPS](https://proceedings.neurips.cc/paper_files/paper/2022/file/e5aa7171449b83f8b4eec1623eac9906-Supplemental-Conference.pdf)**  
neurips.cc

[370] **[Transfer Learning: Making Retrosynthetic Predictions Based on a Small Chemical Reaction Dataset Scale to a New Level - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC7287934/)**  
nih.gov

[371] **[Combining Machine Learning and Computational Chemistry for Predictive Insights Into Chemical Systems - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.chemrev.1c00107)**  
acs.org

[372] **[Generalization Bounds for Message Passing Networks on Mixture of Graphons | SIAM Journal on Mathematics of Data Science](https://epubs.siam.org/doi/10.1137/24M1651526)**  
siam.org

[373] **[ASPEST: Bridging the Gap Between Active Learning and Selective Prediction - OpenReview](https://openreview.net/pdf?id=3nprbNR3HB)**  
openreview.net

[374] **[(PDF) Integrating Randomized Placebo-Controlled Trial Data with External Controls: A Semiparametric Approach with Selective Borrowing - ResearchGate](https://www.researchgate.net/publication/371953814_Integrating_Randomized_Placebo-Controlled_Trial_Data_with_External_Controls_A_Semiparametric_Approach_with_Selective_Borrowing)**  
researchgate.net

[375] **[[2210.12496] Bayesian Optimization with Conformal Prediction Sets - arXiv](https://arxiv.org/abs/2210.12496)**  
arxiv.org

[376] **[Efficient Active Learning with Abstention - arXiv](https://arxiv.org/html/2204.00043v3)**  
arxiv.org

[377] **[Development of Adversarial Transfer Learning Soft Sensor for Multigrade Processes | Industrial & Engineering Chemistry Research - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.iecr.0c02398)**  
acs.org

[378] **[Industrial data science – a review of machine learning applications for chemical and process industries† | Reaction Chemistry & Engineering](https://pubs.rsc.org/en/Content/ArticleLanding/2022/RE/D1RE00541C)**  
rsc.org

[379] **[Rethinking Molecular OOD Generalization via Target-Aware Source Selection - arXiv](https://arxiv.org/html/2605.13932v1)**  
arxiv.org

[380] **[Transfer learning for cross-context prediction of protein expression from 5'UTR sequence | Nucleic Acids Research | Oxford Academic](https://academic.oup.com/nar/article/52/13/e58/7691520)**  
oup.com

[381] **[Transfer learning with graph neural networks for improved molecular property prediction in the multi-fidelity setting | ChemRxiv](https://chemrxiv.org/doi/10.26434/chemrxiv-2022-dsbm5)**  
chemrxiv.org

[382] **[Selective prediction for extracting unstructured clinical data - PMC - NIH](https://pmc.ncbi.nlm.nih.gov/articles/PMC10746316/)**  
nih.gov

[383] **[Private markets enter selective phase, says Aberdeen](https://www.aberdeenplc.com/en-gb/news/all-news/private-markets-enter-more-selective-phase-as-fundamentals-take-centre-stage-says-aberdeen)**  
aberdeenplc.com

[384] **[samuelstanton/conformal-bayesopt: Bayesian optimization with conformal coverage guarantees - GitHub](https://github.com/samuelstanton/conformal-bayesopt)**  
github.com

[385] **[MERA: Mechanistic Error Reduction with Abstention - Emergent Mind](https://www.emergentmind.com/topics/mechanistic-error-reduction-with-abstention-mera)**  
emergentmind.com

[386] **[(PDF) Transfer learning from first-principles calculations to experiments with chemistry-informed domain transformation - ResearchGate](https://www.researchgate.net/publication/390855556_Transfer_learning_from_first-principles_calculations_to_experiments_with_chemistry-informed_domain_transformation)**  
researchgate.net

[387] **[AI bias: exploring discriminatory algorithmic decision-making models and the application of possible machine-centric solutions adapted from the pharmaceutical industry - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC8830968/)**  
nih.gov

[388] **[Information-Theoretic Generalization Bounds for Transductive Learning and its Applications](https://jmlr.org/papers/volume25/23-1368/23-1368.pdf)**  
jmlr.org

[389] **[Survey of Transfer Learning Approaches in the Machine Learning of Digital Health Sensing Data - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10744730/)**  
nih.gov

[390] **[Know Your Limits: A Survey of Abstention in Large Language Models - MIT Press Direct](https://direct.mit.edu/tacl/article/doi/10.1162/tacl_a_00754/131566/Know-Your-Limits-A-Survey-of-Abstention-in-Large)**  
mit.edu

[391] **[Active Learning](https://web.stanford.edu/class/cs329h/slide_pdfs/Active_Learning.pdf)**  
stanford.edu

[392] **[Active Learning of Conditional Mean Embeddings via Bayesian Optimisation](http://proceedings.mlr.press/v124/ray-chowdhury20a/ray-chowdhury20a.pdf)**  
mlr.press

[393] **[ADVERSARIAL INDUCTIVE TRANSFER LEARNING WITH INPUT AND OUTPUT SPACE ADAPTATION - OpenReview](https://openreview.net/pdf/8501a0a10f8badb29128089fe4923bc314417d4a.pdf)**  
openreview.net

[394] **[Collaborative Intelligence in Sequential Experiments: A Human-in-the-Loop Framework for Drug Discovery | Information Systems Research - PubsOnLine](https://pubsonline.informs.org/doi/10.1287/isre.2024.1154)**  
informs.org

[395] **[A Modelling Study of the Correlation between the Layer Obtained by Selective Transfer and the Dislocations Movement at the Friction Surfaces Limit - MDPI](https://www.mdpi.com/2075-4701/12/2/180)**  
mdpi.com

[396] **[Transfer learning with graph neural networks for improved molecular property prediction in the multi-fidelity setting. - Apollo](https://www.repository.cam.ac.uk/items/6f3d0c21-1d71-4b6a-b0d8-886ce72cb7fa)**  
cam.ac.uk

[397] **[Fast and scalable Wasserstein-1 neural optimal transport solver for single-cell perturbation prediction - Oxford Academic](https://academic.oup.com/bioinformatics/article/41/Supplement_1/i513/8199349)**  
oup.com

[398] **[Conformal Prediction and Ensemble Learning for Uncertainty-Aware ICU Mortality Stratification - medRxiv](https://www.medrxiv.org/content/10.64898/2026.05.29.26354474v1.full.pdf)**  
medrxiv.org

[399] **[Conformal Prediction for Quantum Entanglement: Robustness and Detection - Preprints.org](https://www.preprints.org/manuscript/202511.1754)**  
preprints.org

[400] **[SEL-BALD: Deep Bayesian Active Learning with Selective Labels - NIPS](https://proceedings.neurips.cc/paper_files/paper/2024/file/4809dd4b628b6253d0aad0154014f7a3-Paper-Conference.pdf)**  
neurips.cc

[401] **[Generalization Bounds for Domain Adaptation | Request PDF - ResearchGate](https://www.researchgate.net/publication/236118787_Generalization_Bounds_for_Domain_Adaptation)**  
researchgate.net

[402] **[CNNs for Vis-NIR Chemometrics: From Contradiction to Conditional Design - arXiv](https://arxiv.org/html/2605.02636v1)**  
arxiv.org

[403] **[Transfer Learning for Soft Sensors in Process Industries: A Review and Future Perspectives](https://pubs.acs.org/doi/10.1021/acs.iecr.5c05144)**  
acs.org

[404] **[Look Again Before You Abstain: Budgeted Conformal Evidence Acquisition for Reliable Vision-Language Models - arXiv](https://arxiv.org/html/2606.16667v2)**  
arxiv.org

[405] **[Label-Free Per-Domain Contamination Control with Conformal Risk Guarant - arXiv](https://arxiv.org/pdf/2607.14157)**  
arxiv.org

[406] **[CONSTRAINED BAYESIAN OPTIMIZATION WITH ADAP- TIVE ACTIVE LEARNING OF UNKNOWN CONSTRAINTS - OpenReview](https://openreview.net/pdf?id=WKALcMvCdm)**  
openreview.net

[407] **[Enhancing Molecular Property Prediction through Task-Oriented Transfer Learning: Integrating Universal Structural Insights and Domain-Specific Knowledge | Journal of Medicinal Chemistry - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jmedchem.4c00692)**  
acs.org

[408] **[TO-UGDA: target-oriented unsupervised graph domain adaptation - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11576983/)**  
nih.gov

[409] **[A Deep-Learning View of Chemical Space Designed to Facilitate Drug Discovery](https://pubs.acs.org/doi/10.1021/acs.jcim.0c00321)**  
acs.org

[410] **[Pairwise Optimal Transports for Training All-to-All Flow-Based Condition Transfer Model - NIPS](https://papers.nips.cc/paper_files/paper/2025/file/a821bd31e93435b50c0a461337fe75c0-Paper-Conference.pdf)**  
nips.cc

[411] **[Dynamic applicability domain (dAD): compound–target binding affinity estimates with local conformal prediction | Bioinformatics | Oxford Academic](https://academic.oup.com/bioinformatics/article/39/8/btad465/7245860)**  
oup.com

[412] **[Reliable Automated Triage in Spanish Clinical Notes: A Hybrid Framework for Risk-Aware HIV Suspicion Identification - ACL Anthology](https://aclanthology.org/2026.bionlp-1.8.pdf)**  
aclanthology.org

[413] **[constrained bayesian optimization with adap - arXiv](https://arxiv.org/pdf/2310.08751)**  
arxiv.org

[414] **[Cross-Domain Transfer Learning from Peptides to Metabolites Using a Multi-Property Fine-Tuned LLM - Oxford Academic](https://academic.oup.com/bioinformatics/advance-article-pdf/doi/10.1093/bioinformatics/btag493/68697909/btag493.pdf)**  
oup.com

[415] **[Do LLMs Truly Generalize in the Molecular Domain? A Perturbation-Based Analysis - arXiv](https://arxiv.org/html/2607.01800v1)**  
arxiv.org

[416] **[Progressive transfer learning for advancing machine learning-based reduced-order modeling - ResearchGate](https://www.researchgate.net/publication/382079579_Progressive_transfer_learning_for_advancing_machine_learning-based_reduced-order_modeling)**  
researchgate.net

[417] **[MoleProLink-RL: geometric transport for domain-policy reinforcement learning in drug-target interaction prediction - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12749010/)**  
nih.gov

[418] **[Smart sensing-enabled risk-aware nitrogen prescriptions via conformal profit bounds for precision agriculture - Frontiers](https://www.frontiersin.org/journals/plant-science/articles/10.3389/fpls.2026.1821003/full)**  
frontiersin.org

[419] **[(PDF) Selective Conformal Risk Control - ResearchGate](https://www.researchgate.net/publication/398721023_Selective_Conformal_Risk_Control)**  
researchgate.net

[420] **[ACTIVE LEARNING IN BAYESIAN NEURAL NETWORKS WITH BALANCED ENTROPY LEARNING PRINCIPLE - OpenReview](https://openreview.net/pdf/4919425fc00a999aa99ff64ba1e275ca945e9f6f.pdf)**  
openreview.net

[421] **[Do LLMs Truly Generalize in the Molecular Domain? A Perturbation-Based Analysis - arXiv](https://arxiv.org/pdf/2607.01800)**  
arxiv.org

[422] **[AI for scientific discovery is a social problem - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC13100680/)**  
nih.gov

[423] **[Wasserstein Distances Made Explainable: Insights Into Dataset Shifts and Transport Phenomena - ResearchGate](https://www.researchgate.net/publication/400003910_Wasserstein_Distances_Made_Explainable_Insights_into_Dataset_Shifts_and_Transport_Phenomena)**  
researchgate.net

[424] **[SCOPE: Selective Conformal Optimized Pairwise LLM Judging | OpenReview](https://openreview.net/forum?id=ggrMMfC3Gw)**  
openreview.net

[425] **[TRUST-GATED STATE SPACE MODELS FOR ... - OpenReview](https://openreview.net/pdf?id=X3PqW2iv8Q)**  
openreview.net

[426] **[Bayesian Active Learning By Distribution Disagreement - arXiv](https://arxiv.org/html/2501.01248v1)**  
arxiv.org

[427] **[Degree-aware Spiking Graph Domain Adaptation for Classification - OpenReview](https://openreview.net/forum?id=nVbbB3Jmyo)**  
openreview.net

[428] **[Leakage and the reproducibility crisis in machine-learning-based science - ResearchGate](https://www.researchgate.net/publication/372931250_Leakage_and_the_reproducibility_crisis_in_machine-learning-based_science)**  
researchgate.net

[429] **[Uncertainty-aware mixture of experts for robust multimodal sentiment analysis](https://scholar.hit.edu.cn/en/publications/uncertainty-aware-mixture-of-experts-for-robust-multimodal-sentim/)**  
hit.edu.cn

[430] **[Uncertainty-Aware Gating Mechanism - Emergent Mind](https://www.emergentmind.com/topics/uncertainty-aware-gating-mechanism)**  
emergentmind.com

[431] **[Gaussian Process Gating in Expert Models - Emergent Mind](https://www.emergentmind.com/topics/gaussian-process-gating)**  
emergentmind.com

[432] **[Mixture-of-Experts under Finite-Rate Gating: Communication–Generalization Trade-offs](https://arxiv.org/html/2602.15091v2)**  
arxiv.org

[433] **[Dynamic Mixture of Experts: An Auto-Tuning Approach for Efficient Transformer Models](https://openreview.net/forum?id=T26f9z2rEe)**  
openreview.net

[434] **[[2311.00285] Mixture-of-Experts for Open Set Domain Adaptation: A Dual-Space Detection Approach - arXiv](https://arxiv.org/abs/2311.00285)**  
arxiv.org

[435] **[Mixture-of-Experts with Expert Choice Routing](https://papers.neurips.cc/paper_files/paper/2022/file/2f00ecd787b432c1d36f3de9800728eb-Paper-Conference.pdf)**  
neurips.cc

[436] **[MoCE: Mixture of Experts Representation for Robust Crystal Material Property Prediction](https://openreview.net/forum?id=Oit5bHPmjx)**  
openreview.net

[437] **[Beyond the Typical: Modeling Rare Plausible Patterns in Chemical Reactions by Leveraging Sequential Mixture-of-Experts - arXiv](https://arxiv.org/html/2310.04674v2)**  
arxiv.org

[438] **[Multi-View Mixture-of-Experts for Predicting Molecular Properties Using SMILES, SELFIES, and Graph-Based Representations - NeurIPS 2026](https://neurips.cc/virtual/2024/105918)**  
neurips.cc

[439] **[Mixture of experts for multitask learning in cardiotoxicity assessment - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12395882/)**  
nih.gov

[440] **[Uncertainty-Aware Mixture of Experts for Video Action Anticipation - ResearchGate](https://www.researchgate.net/publication/392461609_Uncertainty-aware_Mixture_of_Experts_for_Video_Action_Anticipation)**  
researchgate.net

[441] **[[2302.04947] Gaussian Process-Gated Hierarchical Mixtures of Experts - arXiv](https://arxiv.org/abs/2302.04947)**  
arxiv.org

[442] **[What Is a Mixture of Experts (MoE)? | by Annemsony - Medium](https://medium.com/@annemsony/what-is-a-mixture-of-experts-moe-63f62b8586f1)**  
medium.com

[443] **[MoDEM: Mixture of Domain Expert Models - arXiv](https://arxiv.org/html/2410.07490v1)**  
arxiv.org

[444] **[Dynamic Expert Specialization: Towards Catastrophic Forgetting-Free Multi-Domain MoE Adaptation - ACL Anthology](https://aclanthology.org/2025.emnlp-main.932/)**  
aclanthology.org

[445] **[What Is Mixture of Experts (MoE)? How It Works, Use Cases & More | DataCamp](https://www.datacamp.com/blog/mixture-of-experts-moe)**  
datacamp.com

[446] **[How Much Can Transfer? BRIDGE: Bounded Multi-Domain Graph Foundation Model with Generalization Guarantees - Proceedings of Machine Learning Research](https://proceedings.mlr.press/v267/yuan25h.html)**  
mlr.press

[447] **[Materials - a ibm-research Collection - Hugging Face](https://huggingface.co/collections/ibm-research/materials)**  
huggingface.co

[448] **[MoE_experiments/README.md at main - GitHub](https://github.com/aaronzhfeng/MoE_experiments/blob/main/README.md)**  
github.com

[449] **[Mol-Moe: A multi-view mixture-of-experts framework for molecular property prediction with SMILES, SELFIES, and graph representations - American Chemical Society](https://acs.digitellinc.com/p/s/mol-moe-a-multi-view-mixture-of-experts-framework-for-molecular-property-prediction-with-smiles-selfies-and-graph-representations-622272)**  
digitellinc.com

[450] **[A Survey of Multi‐task Learning Methods in Chemoinformatics - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC6587441/)**  
nih.gov

[451] **[SURE: Synergistic Uncertainty-Aware Reasoning for Multimodal Emotion Recognition in Conversations - Munich Center for Machine Learning](https://mcml.ai/publications/cwm+26/)**  
mcml.ai

[452] **[Improving Deep Ensembles for Better Deep Uncertainty Quantification](https://www.mlmi.eng.cam.ac.uk/files/2020-2021_dissertations/improving_deep_ensembles.pdf)**  
cam.ac.uk

[453] **[Infinite Mixtures of Gaussian Process Experts - NIPS](http://papers.neurips.cc/paper/2055-infinite-mixtures-of-gaussian-process-experts.pdf)**  
neurips.cc

[454] **[Mixture of experts - Wikipedia](https://en.wikipedia.org/wiki/Mixture_of_experts)**  
wikipedia.org

[455] **[Introduction to Mixture of Experts (MoE) | by CyberRaya - Medium](https://medium.com/@CyberRaya/introduction-to-mixture-of-experts-moe-11c80bf197fb)**  
medium.com

[456] **[Nexus: Specialization meets Adaptability for Efficiently Training ...](https://chat.powerdrill.ai/discover/discover-Nexus-Specialization-meets-cm0frqwij118t019cobjowzdh)**  
powerdrill.ai

[457] **[Distributed Mixture-of-Experts and Expert Parallelism - Bruno Magalhaes](https://brunomaga.github.io/Mixture-of-Experts)**  
github.io

[458] **[Meta-DMoE: Adapting to Domain Shift by Meta-Distillation from Mixture-of-Experts - NIPS](https://proceedings.nips.cc/paper_files/paper/2022/file/8bd4f1dbc7a70c6b80ce81b8b4fdc0b2-Paper-Conference.pdf)**  
nips.cc

[459] **[RetroMoE: A Mixture-of-Experts Latent Translation Framework for Single-step Retrosynthesis - IJCAI](https://www.ijcai.org/proceedings/2025/0835.pdf)**  
ijcai.org

[460] **[Hierarchical Mixture of Topological Experts for Molecular Property Prediction - ICLR 2026](https://iclr.cc/virtual/2025/37801)**  
iclr.cc

[461] **[A Multi-task Large Reasoning Model for Molecular Science - arXiv](https://arxiv.org/html/2603.12808)**  
arxiv.org

[462] **[Training of Neural Networks with Uncertain Data: A Mixture of Experts Approach - arXiv](https://arxiv.org/abs/2312.08083)**  
arxiv.org

[463] **[Variance-Gated Ensembles: An Epistemic-Aware Framework for ...](https://www.researchgate.net/publication/400603409_Variance-Gated_Ensembles_An_Epistemic-Aware_Framework_for_Uncertainty_Estimation)**  
researchgate.net

[464] **[clementetienam/Ultra-fast-Deep-Mixtures-of-Gaussian-Process-Experts - GitHub](https://github.com/clementetienam/Ultra-fast-Deep-Mixtures-of-Gaussian-Process-Experts)**  
github.com

[465] **[The MoE Gating Network Explained - ApX Machine Learning](https://apxml.com/courses/mixture-of-experts-advanced-implementation/chapter-1-foundations-of-moe-models/gating-network-formulation)**  
apxml.com

[466] **[Mixture-of-Experts (MoE) LLMs - by Cameron R. Wolfe, Ph.D.](https://cameronrwolfe.substack.com/p/moe-llms)**  
substack.com

[467] **[Applying Mixture of Experts in LLM Architectures | NVIDIA Technical Blog](https://developer.nvidia.com/blog/applying-mixture-of-experts-in-llm-architectures/)**  
nvidia.com

[468] **[How Much Can Transfer? BRIDGE: Bounded Multi-Domain Graph Foundation Model with Generalization Guarantees | OpenReview](https://openreview.net/forum?id=bjDKZ3Roax)**  
openreview.net

[469] **[Enhancing composition-based materials property prediction by cross-modal knowledge transfer - arXiv](https://arxiv.org/html/2511.03371v1)**  
arxiv.org

[470] **[A Multi-View Mixture-of-Experts based on Language and Graphs for Molecular Properties Prediction - OpenReview](https://openreview.net/pdf?id=PkDHmg2JLI)**  
openreview.net

[471] **[HIERARCHICAL MIXTURE OF TOPOLOGICAL EXPERTS FOR MOLECULAR PROPERTY PREDICTION - OpenReview](https://openreview.net/pdf?id=9g4YzEj5WT)**  
openreview.net

[472] **[scMoE: single-cell Multi-Modal Multi-Task Learning via Sparse Mixture-of-Experts](https://openreview.net/forum?id=hZzGX1h9JY)**  
openreview.net

[473] **[Uncertainty-Guided Mixture of Experts - Emergent Mind](https://www.emergentmind.com/topics/uncertainty-guided-mixture-of-experts)**  
emergentmind.com

[474] **[Uncertainty Estimation using Variance-Gated Distributions - OpenReview](https://openreview.net/pdf/44bf2c0ffe389fa262707337c4c32afac4b64e1d.pdf)**  
openreview.net

[475] **[Infinite Mixtures of Gaussian Process Experts - NIPS](https://papers.nips.cc/paper/2055-infinite-mixtures-of-gaussian-process-experts)**  
nips.cc

[476] **[What Is Mixture of Experts (MoE) and How It Works? | NVIDIA Glossary](https://www.nvidia.com/en-us/glossary/mixture-of-experts/)**  
nvidia.com

[477] **[Mixture of LoRA Experts Strategy - Emergent Mind](https://www.emergentmind.com/topics/mixture-of-lora-experts-strategy)**  
emergentmind.com

[478] **[Mixture of Experts Explained - Outcome School](https://outcomeschool.com/blog/mixture-of-experts)**  
outcomeschool.com

[479] **[[2405.11530] Learning More Generalized Experts by Merging Experts in Mixture-of-Experts - arXiv](https://arxiv.org/abs/2405.11530)**  
arxiv.org

[480] **[Introduction to IBM Foundation Models for Materials (FM4M) - GitHub](https://github.com/IBM/materials)**  
github.com

[481] **[A Machine Learning Approach to Predict Chemical Reactions](https://proceedings.neurips.cc/paper_files/paper/4356-a-machine-learning-approach-to-predict-chemical-reactions.pdf)**  
neurips.cc

[482] **[Expert-Guided Substructure Information Bottleneck for Molecular Property Prediction](https://pubmed.ncbi.nlm.nih.gov/40702819/)**  
nih.gov

[483] **[Understanding Mixture of Experts (MoE) Neural Networks - IntuitionLabs](https://intuitionlabs.ai/articles/mixture-of-experts-moe-models)**  
intuitionlabs.ai

[484] **[Adaptive Conformal Prediction via Mixture-of-Experts Gating Similarity - ICLR 2026](https://iclr.cc/virtual/2026/poster/10006832)**  
iclr.cc

[485] **[ConRAD: Conformal Risk-Aware Neural Databases - arXiv](https://arxiv.org/html/2605.03806v1)**  
arxiv.org

[486] **[Publications - Adam Fisch - People | MIT CSAIL](https://people.csail.mit.edu/fisch/publications/)**  
mit.edu

[487] **[Mixture-of-Reasoning Experts (MoRE) - Learn Prompting](https://learnprompting.org/docs/advanced/ensembling/mixture_of_reasoning_experts_more)**  
learnprompting.org

[488] **[Beyond Accuracy: A Modern Framework for Assessing Model Performance in Molecular Property Prediction](http://theochemtek.com/posts/beyond-accuracy-a-modern-framework-for-assessing-model-performance-in-molecular-property-prediction)**  
theochemtek.com

[489] **[LAR-MoE: Latent-Aligned Routing for Mixture of Experts in Robotic Imitation Learning - arXiv](https://arxiv.org/html/2603.08476v1)**  
arxiv.org

[490] **[A modeling framework for adaptive lifelong learning with transfer and savings through gating in the prefrontal cortex | PNAS](https://www.pnas.org/doi/10.1073/pnas.2009591117)**  
pnas.org

[491] **[EnzOracle: Mechanism-aware prediction of enzyme environmental ...](https://www.biorxiv.org/content/10.64898/2026.06.02.729708v1.full-text)**  
biorxiv.org

[492] **[DeepReac+: deep active learning for quantitative modeling of organic chemical reactions](https://pubs.rsc.org/en/content/articlelanding/2021/sc/d1sc02087k)**  
rsc.org

[493] **[[2503.04362] A Generalist Cross-Domain Molecular Learning Framework for Structure-Based Drug Discovery - arXiv](https://arxiv.org/abs/2503.04362)**  
arxiv.org

[494] **[Mixtures of Gaussian Process Experts with SMC2 - arXiv](https://arxiv.org/html/2208.12830v2)**  
arxiv.org

[495] **[A Systematic Survey and Benchmark of Deep Learning for Molecular Property Prediction in the Foundation Model Era - arXiv](https://arxiv.org/html/2604.16586v1)**  
arxiv.org

[496] **[Adaptive Conformal Prediction via Mixture-of-Experts Gating Similarity | OpenReview](https://openreview.net/forum?id=vCmnu4q8C3)**  
openreview.net

[497] **[Conformal convolutional neural network (CCNN) for single-shot sensorless wavefront sensing - Optica Publishing Group](https://opg.optica.org/oe/fulltext.cfm?uri=oe-28-13-19218)**  
optica.org

[498] **[[2305.14628] Getting MoRE out of Mixture of Language Model Reasoning Experts - arXiv](https://arxiv.org/abs/2305.14628)**  
arxiv.org

[499] **[Predicting reaction conditions from limited data through active transfer learning - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC9172577/)**  
nih.gov

[500] **[Physics-Informed Video Generation via Mixture-of-Experts Latent Alignment - arXiv](https://arxiv.org/html/2606.04737v1)**  
arxiv.org

[501] **[MT-GPD: A Multimodal Deep Transfer Learning Model Enhanced by Auxiliary Mechanisms for Cross-Domain Online Fake News Detection](https://webpages.charlotte.edu/mlee173/pdfs/pom25.pdf)**  
charlotte.edu

[502] **[SMI-TED: A LARGE-SCALE FOUNDATION MODEL FOR MATERIALS AND CHEMISTRY - OpenReview](https://openreview.net/pdf?id=MK2cYT64WR)**  
openreview.net

[503] **[Active rejection enables reliable generalization of universal machine-learning interatomic potentials - arXiv](https://arxiv.org/html/2607.09456v1)**  
arxiv.org

[504] **[Gaussian process models of potential energy surfaces with boundary optimization | The Journal of Chemical Physics | AIP Publishing](https://pubs.aip.org/aip/jcp/article/155/14/144106/955919/Gaussian-process-models-of-potential-energy)**  
aip.org

[505] **[Uncertainty quantification for molecular property predictions with graph neural architecture search - Royal Society of Chemistry journals](https://pubs.rsc.org/en/content/articlehtml/2024/dd/d4dd00088a)**  
rsc.org

[506] **[Calibrated Knowledge Aggregation in Bayesian Mixture-of-Experts for Continual VQA - - Mahsa Mozaffari](https://mahsamozaffari.com/wp-content/uploads/2026/05/ICML_2026.pdf)**  
mahsamozaffari.com

[507] **[ADAPTIVE CONFORMAL PREDICTION VIA MIXTURE- OF-EXPERTS GATING SIMILARITY - OpenReview](https://openreview.net/pdf?id=vCmnu4q8C3)**  
openreview.net

[508] **[CondSR: Conditional Shift-Robust Conformal Prediction for Graph Neural Networks](https://www.springerprofessional.de/en/condsr-conditional-shift-robust-conformal-prediction-for-graph-n/52188510)**  
springerprofessional.de

[509] **[Getting MoRE out of Mixture of Language Model Reasoning Experts - ACL Anthology](https://aclanthology.org/2023.findings-emnlp.552.pdf)**  
aclanthology.org

[510] **[[1405.7624] Simultaneous Feature and Expert Selection within Mixture of Experts - arXiv](https://arxiv.org/abs/1405.7624)**  
arxiv.org

[511] **[Multitask methods for predicting molecular properties from heterogeneous data | The Journal of Chemical Physics | AIP Publishing](https://pubs.aip.org/aip/jcp/article/161/1/014114/3302119/Multitask-methods-for-predicting-molecular)**  
aip.org

[512] **[The Evolution of Mixture of Experts: A Survey from Basics to Breakthroughs - Preprints.org](https://www.preprints.org/manuscript/202408.0583)**  
preprints.org

[513] **[Primers • Mixture of Experts - aman.ai](https://aman.ai/primers/ai/mixture-of-experts/)**  
aman.ai

[514] **[Mixture of Experts (MoE): A Big Data Perspective - arXiv](https://arxiv.org/html/2501.16352v1)**  
arxiv.org

[515] **[NeurIPS Poster Enhanced Expert Merging for Mixture-of-Experts in Graph Foundation Models](https://neurips.cc/virtual/2025/poster/116783)**  
neurips.cc

[516] **[Clustering and Prediction with a Gaussian Process Mixture Model](https://lutpub.lut.fi/bitstream/handle/10024/162732/mastersthesis_Rasanen_Elias.pdf?sequence=1&isAllowed=y)**  
lut.fi

[517] **[Neural Bayesian Sequential Routing: A Breakthrough in ...](https://arsa.technology/machine-state/neural-bayesian-sequential-routing-a-breakthrough-ynmsr38r/)**  
arsa.technology

[518] **[Mixture-of-Experts Approach for Enhanced Drug-Target Interaction Prediction and Confidence Assessment | bioRxiv](https://www.biorxiv.org/content/10.1101/2024.08.06.606753v1.full-text)**  
biorxiv.org

[519] **[Critical Assessment of Conformal Prediction Methods Applied in Binary Classification Settings - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.1c00549)**  
acs.org

[520] **[MARVEL: Modular Abstention for Reliable and Versatile Expert LLMs | OpenReview](https://openreview.net/forum?id=cVb6jJilvJ)**  
openreview.net

[521] **[Mixture of Experts Model: A Comprehensive Guide - Lenovo](https://www.lenovo.com/us/en/knowledgebase/mixture-of-experts-model-a-comprehensive-guide/)**  
lenovo.com

[522] **[Transfer Learning in Information Criteria-based Feature Selection](https://www.jmlr.org/papers/volume23/19-816/19-816.pdf)**  
jmlr.org

[523] **[(PDF) Physics-Informed Video Generation via Mixture-of-Experts ...](https://www.researchgate.net/publication/405922808_Physics-Informed_Video_Generation_via_Mixture-of-Experts_Latent_Alignment)**  
researchgate.net

[524] **[Expert Credibility Prediction Model Based on Fuzzy C-Means ...](https://www.researchgate.net/publication/392340341_Expert_Credibility_Prediction_Model_Based_on_Fuzzy_C-Means_Clustering_and_Similarity_Association)**  
researchgate.net

[525] **[SMI-TED: Encoder-Decoder Foundation Models for Chemistry - Hunter Heidenreich](https://hunterheidenreich.com/notes/chemistry/molecular-representations/encoders/smi-ted-encoder-decoder-chemistry/)**  
hunterheidenreich.com

[526] **[Towards Understanding the Mixture-of-Experts Layer in Deep Learning](https://proceedings.neurips.cc/paper_files/paper/2022/file/91edff07232fb1b55a505a9e9f6c0ff3-Paper-Conference.pdf)**  
neurips.cc

[527] **[The Gaussian Processes Web Site](https://gaussianprocess.org/ancient/)**  
gaussianprocess.org

[528] **[Molecular Property Prediction: A Multilevel Quantum Interactions Modeling Perspective](https://ojs.aaai.org/index.php/AAAI/article/view/3896/3774)**  
aaai.org

[529] **[[2510.15233] Adaptive Individual Uncertainty under Out-Of-Distribution Shift with Expert-Routed Conformal Prediction - arXiv](https://arxiv.org/abs/2510.15233)**  
arxiv.org

[530] **[Know Your Limits: A Survey of Abstention in Large Language Models - arXiv](https://arxiv.org/html/2407.18418v3)**  
arxiv.org

[531] **[Adaptive Transfer Learning for Time-to-Event Modeling with Applications in Disease Risk Assessment | medRxiv](https://www.medrxiv.org/content/10.1101/2025.01.14.25320536v1.full-text)**  
medrxiv.org

[532] **[Machine Learning Strategies for Reaction Development: Toward the Low-Data Limit - Ambuj Tewari](https://www.ambujtewari.com/research/shim23machine.pdf)**  
ambujtewari.com

[533] **[RS-MoE: Collaborative Compression for Mixture-of-Experts LLMs based on Low-Rank and Sparse Approximation | OpenReview](https://openreview.net/forum?id=5SQbPbCU6P)**  
openreview.net

[534] **[The Illusion of Specialization: Unveiling the Domain-Invariant "Standing Committee" in Mixture-of-Experts Models - arXiv](https://arxiv.org/html/2601.03425v1)**  
arxiv.org

[535] **[Mixture-of-Experts Machine Learning Framework for Predictive Design of Biomass-Derived Hydrochar to Decarbonize Industrial Heat | Request PDF - ResearchGate](https://www.researchgate.net/publication/403092639_Mixture-of-Experts_Machine_Learning_Framework_for_Predictive_Design_of_Biomass-Derived_Hydrochar_to_Decarbonize_Industrial_Heat)**  
researchgate.net

[536] **[ALipSol: An Attention-Driven Mixture-of-Experts Model for Lipophilicity and Solubility Prediction - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.2c01290)**  
acs.org

[537] **[PotentialNet for Molecular Property Prediction | ACS Central Science - ACS Publications](https://pubs.acs.org/doi/10.1021/acscentsci.8b00507)**  
acs.org

[538] **[Leave one Expert Out: Robust Uncertainty Quantification via Intrinsic Cross-Validation](https://openreview.net/forum?id=HaQCWrbP5Z&noteId=1Q9ui0UQPx)**  
openreview.net

[539] **[AI SAFETY MODEL MOE: A MIXTURE-OF-EXPERTS ARCHITECTURE FOR CERTIFIABLE, RISK-AWARE GENERATION Ian Rudd, PhD¹,* ABSTRACT Mixture - Intellectual Archive](http://www.intellectualarchive.com/getfile.php?file=Jl6KJZWZOfN&orig_file=AI%20Safety%20MoE%20paper%20-%20Dr.%20IAN%20RUDD%20-%20v%202.0.pdf)**  
intellectualarchive.com

[540] **[JUMP-Hand: Learning Joint-wise Uncertainty to Gate Mixture of View Experts - CVF Open Access](https://openaccess.thecvf.com/content/CVPR2026/papers/Kuang_JUMP-Hand_Learning_Joint-wise_Uncertainty_to_Gate_Mixture_of_View_Experts_CVPR_2026_paper.pdf)**  
thecvf.com

[541] **[Bridging Data Gaps in Healthcare: A Scoping Review of Transfer Learning in Structured Data Analysis - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12408193/)**  
nih.gov

[542] **[Ironic Effect of Source Identification on the Perceived Credibility of Online Product Reviewers | Journal of Computer-Mediated Communication | Oxford Academic](https://academic.oup.com/jcmc/article/18/1/16/4065283)**  
oup.com

[543] **[Learning Latent Trajectories in Developmental Time Series with Hidden-Markov Optimal Transport - bioRxiv](https://www.biorxiv.org/content/10.1101/2025.02.14.638351v1.full.pdf)**  
biorxiv.org

[544] **[A Drift-Aware Dynamic Mixture of Experts Framework for Non-Stationary Time Series Forecasting - ICML 2026](https://icml.cc/virtual/2026/poster/64808)**  
icml.cc

[545] **[MPCD: A Multitask Graph Transformer for Molecular Property Prediction by Integrating Common and Domain Knowledge | Journal of Medicinal Chemistry - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jmedchem.4c02193)**  
acs.org

[546] **[Active Learning to Select the Most Suitable Reagents and One-Step Organic Chemistry Reactions for Prioritizing Target-Specific Hits from Ultralarge Chemical Spaces](https://pubs.acs.org/doi/10.1021/acs.jcim.4c02097)**  
acs.org

[547] **[(PDF) Uncertainty-Aware Yield Prediction with Multimodal Molecular Features](https://www.researchgate.net/publication/379275325_Uncertainty-Aware_Yield_Prediction_with_Multimodal_Molecular_Features)**  
researchgate.net

[548] **[ConfDock: Atom-specific Uncertainty Quantification for ... - bioRxiv](https://www.biorxiv.org/content/10.64898/2026.06.29.735353v1.full.pdf)**  
biorxiv.org

[549] **[Conformal Selective Prediction with General Risk Control - arXiv](https://arxiv.org/html/2603.24704v1)**  
arxiv.org

[550] **[Soft Specialization via Mixture-of-Experts Enables Accurate Prediction of Superconducting Tc from Crystal Structures - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv.15000105)**  
chemrxiv.org

[551] **[Bayesian Methods for Mixtures of Experts](https://proceedings.neurips.cc/paper/1167-bayesian-methods-for-mixtures-of-experts.pdf)**  
neurips.cc

[552] **[junfanz1/MoE-Mixture-of-Experts-in-PyTorch: Implementations of a Mixture-of-Experts (MoE) architecture designed for research on large language models (LLMs) and scalable neural network designs. One implementation targets a **single-device/NPU environment** while the other is built for multi-device distributed computing. Both versions showcase the core principles. · GitHub](https://github.com/junfanz1/MoE-Mixture-of-Experts-in-PyTorch)**  
github.com

[553] **[Optimal transport for label transfer in single-cell multi-omics integration - Oxford Academic](https://academic.oup.com/bib/article/27/3/bbag334/8721790)**  
oup.com

[554] **[Optimally-Weighted Maximum Mean Discrepancy Framework for Continual Learning - arXiv](https://arxiv.org/html/2501.12121v1)**  
arxiv.org

[555] **[Graph Alignment via Dual-Pass Spectral Encoding and Latent Space Communication - arXiv](https://arxiv.org/html/2509.09597v3)**  
arxiv.org

[556] **[Active Stacking-Deep Learning with Strategic Sampling for Small and Imbalanced Chemical Toxicity Prediction - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12631473/)**  
nih.gov

[557] **[Physics-Informed Gaussian Process Inference of Liquid Structure from Scattering Data](https://arxiv.org/html/2507.07948v2)**  
arxiv.org

[558] **[Peirce in the Machine: How Mixture of Experts Models Perform Hypothesis Construction | Philosophy of Science - Cambridge University Press & Assessment](https://www.cambridge.org/core/journals/philosophy-of-science/article/peirce-in-the-machine-how-mixture-of-experts-models-perform-hypothesis-construction/2C92DF1A6805195170683CC6EC446125)**  
cambridge.org

[559] **[How Mixture-of-Experts LLMs Work. An innovative approach to make models… | by Greg Sommerville | Google Cloud - Medium](https://medium.com/google-cloud/how-mixture-of-experts-llms-work-58b3ba8e0349)**  
medium.com

[560] **[Efficient Reflectance Capture with a Deep Gated Mixture-of-Experts - Hongzhi Wu](https://svbrdf.github.io/publications/moe/moe.pdf)**  
github.io

[561] **[Weakly-Supervised Transfer Learning with Application in Precision Medicine - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12312616/)**  
nih.gov

[562] **[LLM Mixture of Experts Explained — A 2026 Field Guide | TensorOps](https://tensorops.ai/blog/what-is-mixture-of-experts-llm)**  
tensorops.ai

[563] **[Wasserstein-Aware Transfer: Class-Level Alignment for Robust Diffusion Model Adaptation - AAAI Publications](https://ojs.aaai.org/index.php/AAAI/article/view/39365/43326)**  
aaai.org

[564] **[Dynamic TMoE: A Drift-Aware Dynamic Mixture of Experts ...](https://openreview.net/forum?id=JabkBcaoa9)**  
openreview.net

[565] **[Graph Alignment via Dual-Pass Spectral Encoding and Latent Space Communication - arXiv](https://arxiv.org/html/2509.09597v1)**  
arxiv.org

[566] **[Optimizing Active Learning for Chemical Space Exploration: Strategies for Enhanced Model Performance in Drug Discovery - Theoretical ChemTech Insights](http://theochemtek.com/posts/optimizing-active-learning-for-chemical-space-exploration-strategies-for-enhanced-model-performance-in-drug-discovery)**  
theochemtek.com

[567] **[Prediction of yields of chemical reactions - mediaTUM](https://mediatum.ub.tum.de/doc/1754066/1754066.pdf)**  
tum.de

[568] **[Conformal Prediction for Molecular Properties under Label Shift - OpenReview](https://openreview.net/pdf?id=IR3T2TCmme)**  
openreview.net

[569] **[CAP: A General Algorithm for Online Selective Conformal Prediction with FCR Control - Journal of Machine Learning Research](http://jmlr.org/papers/volume26/24-0452/24-0452.pdf)**  
jmlr.org

[570] **[Bayesian Mixture of Experts For Large Language Models - arXiv](https://arxiv.org/html/2511.08968v1)**  
arxiv.org

[571] **[Preferential Mixture-of-Experts: Interpretable Models that Rely on Human Expertise As Much As Possible - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC8378634/)**  
nih.gov

[572] **[ICML Poster MoE-SVD: Structured Mixture-of-Experts LLMs Compression via Singular Value Decomposition](https://icml.cc/virtual/2025/poster/44786)**  
icml.cc

[573] **[Efficient Detection and Characterization of Targets of Natural Selection Using Transfer Learning | Molecular Biology and Evolution | Oxford Academic](https://academic.oup.com/mbe/article/42/5/msaf094/8127744)**  
oup.com

[574] **[Mixture-of-Experts Explained: Why 8 smaller models are better than 1 gigantic one](https://alexandrabarr.beehiiv.com/p/mixture-of-experts)**  
beehiiv.com

[575] **[Track: Poster Session 7 - ICLR 2026](https://iclr.cc/virtual/2022/session/8355)**  
iclr.cc

[576] **[FreqMoE: Robust Time Series Forecasting via Frequency-Domain Mixture of Experts for Out-of-Distribution Scenarios - MDPI](https://www.mdpi.com/2079-9292/15/13/2865)**  
mdpi.com

[577] **[Graph neural networks for molecular and materials representation - OAE Publishing](https://www.oaepublish.com/articles/jmi.2023.10)**  
oaepublish.com

[578] **[Gaussian Process-Gated Hierarchical Mixtures of Experts - IEEE Computer Society](https://www.computer.org/csdl/journal/tp/2024/09/10480265/1VCTCWYJBhS)**  
computer.org

[579] **[What is Mixture of Experts (MoE)? - Red Hat](https://www.redhat.com/en/topics/ai/mixture-of-experts)**  
redhat.com

[580] **[Contrastive learning in protein language space predicts interactions between drugs and protein targets | PNAS](https://www.pnas.org/doi/10.1073/pnas.2220778120)**  
pnas.org

[581] **[A Mixture of Experts](https://www.missioncloud.com/podcasts/a-mixture-of-experts)**  
missioncloud.com

[582] **[SCOT: Single-Cell Multi-Omics Alignment with Optimal Transport - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC8812493/)**  
nih.gov

[583] **[Dynamic TMoE: A Drift-Aware Dynamic Mixture of Experts ... - arXiv](https://arxiv.org/html/2605.20678v1)**  
arxiv.org

[584] **[FLARE: Fine-grained Learning for Alignment of spectra-molecule REpresentation Enhances Metabolite Annotation | bioRxiv](https://www.biorxiv.org/content/10.64898/2026.01.27.702086v1.full-text)**  
biorxiv.org

[585] **[Active Machine Learning for Chemical Engineers](https://www.engineering.org.cn/engi/EN/PDF/10.1016/j.eng.2023.02.019)**  
engineering.org.cn

[586] **[Towards out-of-distribution generalizable predictions of chemical kinetic properties - arXiv](https://arxiv.org/html/2310.03152v2)**  
arxiv.org

[587] **[MoGU: Mixture-of-Gaussians with Uncertainty-based Gating for Time Series Forecasting](https://arxiv.org/html/2510.07459v2)**  
arxiv.org

[588] **[Conformal prediction - Wikipedia](https://en.wikipedia.org/wiki/Conformal_prediction)**  
wikipedia.org

[589] **[Powerful Selective Inference After Conformity Score Optimization - arXiv](https://arxiv.org/html/2411.17983v1)**  
arxiv.org

[590] **[Multi-Scale Gaussian Mixture Model-Gated Mixture of Experts for Fine-Grained Insect Pest Classification - MDPI](https://www.mdpi.com/2079-9292/15/11/2268)**  
mdpi.com

[591] **[Adversarial Learning with Bayesian Hierarchical Mixtures of Experts - The University of Texas at Dallas](https://www.utdallas.edu/~muratk/publications/sdm14.pdf)**  
utdallas.edu

[592] **[EnsDTI: Predicting Drug-Target Interaction With Mixture-of-Experts and Confidence Assessment - IEEE Computer Society](https://www.computer.org/csdl/journal/bb/2026/03/11353228/2dh4UUrCHMQ)**  
computer.org

[593] **[MoEGP: an efficient crop genomic prediction approach based on the mixture of experts network - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12958669/)**  
nih.gov

[594] **[Multimodal Mixture-of-Experts with Retrieval Augmentation for Protein Active Site Identification - arXiv](https://arxiv.org/html/2603.01511v2)**  
arxiv.org

[595] **[Gate Control Mechanisms of Autoencoders for EEG Signal Reconstruction - PMC - NIH](https://pmc.ncbi.nlm.nih.gov/articles/PMC12158178/)**  
nih.gov

[596] **[ChemPile: A pile of open-source bioactivity data for training foundation models for chemistry and transfer learning application | Poster Board #646 - American Chemical Society](https://acs.digitellinc.com/p/s/chempile-a-pile-of-open-source-bioactivity-data-for-training-foundation-models-for-chemistry-and-transfer-learning-application-poster-board-646-641026)**  
digitellinc.com

[597] **[Rethinking Graph Domain Adaptation: A Spectral Contrastive Perspective - arXiv](https://arxiv.org/pdf/2510.13254)**  
arxiv.org

[598] **[Conformal Prediction for Ensembles: Improving Efficiency via Score-Based Aggregation](https://arxiv.org/html/2405.16246v2)**  
arxiv.org

[599] **[A transfer learning protocol for chemical catalysis using a recurrent neural network adapted from natural language processing - Digital Discovery (RSC Publishing) DOI:10.1039/D1DD00052G - Royal Society of Chemistry journals](https://pubs.rsc.org/en/content/articlehtml/2022/dd/d1dd00052g)**  
rsc.org

[600] **[(PDF) Selective UMLS knowledge infusion for biomedical question answering - ResearchGate](https://www.researchgate.net/publication/373519004_Selective_UMLS_knowledge_infusion_for_biomedical_question_answering)**  
researchgate.net

[601] **[Gaussian Process Regression for Materials and Molecules | Chemical Reviews - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.chemrev.1c00022)**  
acs.org

[602] **[Ensemble-Based Epistemic Uncertainty - Emergent Mind](https://www.emergentmind.com/topics/ensemble-based-epistemic-uncertainty)**  
emergentmind.com

[603] **[Improved Evidential Deep Learning via a Mixture of Dirichlet Distributions - arXiv](https://arxiv.org/html/2402.06160v1)**  
arxiv.org

[604] **[Gated Autoencoder Network for Spectral–Spatial Hyperspectral Unmixing - MDPI](https://www.mdpi.com/2072-4292/13/16/3147)**  
mdpi.com

[605] **[Bridging the Detection-to-Abstention Gap in Reasoning Models under Insufficient Information - arXiv](https://arxiv.org/html/2605.28070v1)**  
arxiv.org

[606] **[Gromov–Wasserstein based optimal transport to align single-cell multi-omics data](https://mlcb.github.io/mlcb2020_proceedings/papers/74_Demetci_etal_2020.pdf)**  
github.io

[607] **[Sim→Exp-MMNMR: A Benchmark for Simulation-to-Experiment Generalization in Multimodal NMR with Chemistry-Aware Metrics - OpenReview](https://openreview.net/pdf/d813042e4065e13458ce62c25333eb4e4bac1544.pdf)**  
openreview.net

[608] **[Graph Domain Adaptation via Homophily-Agnostic Reconstructing Structure](https://ojs.aaai.org/index.php/AAAI/article/view/39247/43208)**  
aaai.org

[609] **[Hybrid Deep Learning with Conformal Prediction for Recycled Aggregate Self-Compacting Concrete Strength Prediction - MDPI](https://www.mdpi.com/2075-5309/15/24/4419)**  
mdpi.com

[610] **[Distribution-free prediction intervals with conformal prediction for acoustical estimation](https://www.researchgate.net/publication/385049872_Distribution-free_prediction_intervals_with_conformal_prediction_for_acoustical_estimation)**  
researchgate.net

[611] **[Full article: Evidence informed policy? The Australian Education Research Organisation's borrowed knowledge-rich curriculum dispositif - Taylor & Francis](https://www.tandfonline.com/doi/full/10.1080/01596306.2025.2567654)**  
tandfonline.com

[612] **[Neural Bayesian Sequential Routing - arXiv](https://arxiv.org/html/2605.26147v1)**  
arxiv.org

[613] **[Dirichlet-based Uncertainty Quantification for Personalized Federated Learning with Improved Posterior Networks - IJCAI](https://www.ijcai.org/proceedings/2024/0788.pdf)**  
ijcai.org

[614] **[Continuity of autoencoders, unsupervised anomaly detection and Deep Atlases Charles A. Arnal](https://www.mlmi.eng.cam.ac.uk/files/2020-2021_dissertations/continuity_of_autoencoders.pdf)**  
cam.ac.uk

[615] **[WNetAlign: fast and accurate spectra alignment using truncated Wasserstein distance and network simplex | Briefings in Bioinformatics | Oxford Academic](https://academic.oup.com/bib/article/27/3/bbag247/8692742)**  
oup.com

[616] **[Out-of-distribution machine learning for materials discovery: Challenges and opportunities](https://pubs.aip.org/aip/cpr/article/7/1/011317/3384237/Out-of-distribution-machine-learning-for-materials)**  
aip.org

[617] **[SA-GDA: Spectral Augmentation for Graph Domain Adaptation - arXiv](https://arxiv.org/html/2408.09189v1)**  
arxiv.org

[618] **[Uncertainty Without Bayes: Weighted Mondrian Conformal Prediction, Optimal-Transport Drift Tests… Introduction - Medium](https://rabmcmenemy.medium.com/uncertainty-without-bayes-weighted-mondrian-conformal-prediction-optimal-transport-drift-tests-de6acac94029)**  
medium.com

[619] **[log-RRIM: Yield Prediction via Local-to-global Reaction Representation Learning and Interaction Modeling - NSF PAR](https://par.nsf.gov/servlets/purl/10555683)**  
nsf.gov

[620] **[Meaningful Metrics: A 21st-Century Librarian's Guide to Bibliometrics, Altmetrics, and Research Impact - American Library Association](https://www.ala.org/sites/default/files/acrl/content/publications/booksanddigitalresources/digital/9780838987568_metrics_OA.pdf)**  
ala.org

[621] **[Gaussian processes for modeling physical systems - DTU Research Database](https://orbit.dtu.dk/files/258637720/Thesis.pdf)**  
dtu.dk

[622] **[Probabilistic Aircraft Trajectory Prediction with Weather Uncertainties using Approximate Bayesian Variational Inference to Neural Networks - NASA University Leadership Initiative](https://uli.asu.edu/wp-content/uploads/sites/44/2021/10/5.Probabilistic-Aircraft-Trajectory-Prediction-with-Weather-Uncertainties-using-Approximate-Bayesian-Variational-Inference-to-Neural-Networks.pdf)**  
asu.edu

[623] **[[2512.16963] Compression is Routing: Reconstruction Error as an Intrinsic Signal for Modular Language Models - arXiv](https://arxiv.org/abs/2512.16963)**  
arxiv.org

[624] **[Gromov-Wasserstein optimal transport to align single-cell multi-omics data - bioRxiv](https://www.biorxiv.org/content/10.1101/2020.04.28.066787v2.full)**  
biorxiv.org

[625] **[Maximum Mean Discrepancy on Exponential Windows for Online Change Detection - arXiv](https://arxiv.org/html/2205.12706v3)**  
arxiv.org

[626] **[Rank and Align: Towards Effective Source-free Graph Domain Adaptation - IJCAI](https://www.ijcai.org/proceedings/2024/0520.pdf)**  
ijcai.org

[627] **[LeanPaper | Conformal Contextual Robust Optimization - Yash Patel](https://ypatel.io/leanpaper/app.html)**  
ypatel.io

[628] **[Prediction Intervals: Split Normal Mixture from Quality-Driven Deep Ensembles](https://proceedings.mlr.press/v124/saleh-salem20a/saleh-salem20a.pdf)**  
mlr.press

[629] **[MetaRF: Differentiable Random Forest for Reaction Yield Prediction with a Few Trails - arXiv](https://arxiv.org/pdf/2208.10083)**  
arxiv.org

[630] **[Deep knowledge tracing and cognitive load estimation for personalized learning path generation using neural network architecture - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12246154/)**  
nih.gov

[631] **[GAUCHE: A Library for Gaussian Processes in Chemistry - Henry Moss](https://henrymoss.github.io/files/gauche.pdf)**  
github.io

[632] **[Variational Routing: A Scalable Bayesian Framework for Calibrated Mixture-of-Experts Transformers - arXiv](https://arxiv.org/html/2603.09453v1)**  
arxiv.org

[633] **[Ensemble-Based Dirichlet Modeling for Predictive Uncertainty and Selective Classification](https://www.researchgate.net/publication/403605492_Ensemble-Based_Dirichlet_Modeling_for_Predictive_Uncertainty_and_Selective_Classification)**  
researchgate.net

[634] **[TGCAE: Temporal Graph Convolutional Autoencoder for Robust ...](https://assets-eu.researchsquare.com/files/rs-8816450/v1_covered_ab86896d-5475-414e-b5b6-882da628b8d1.pdf)**  
researchsquare.com

[635] **[Explainable Domain Adaptation Learning Framework for Credit Scoring in Internet Finance Through Adversarial Transfer Learning and Ensemble Fusion Model - MDPI](https://www.mdpi.com/2227-7390/13/7/1045)**  
mdpi.com

[636] **[Complex Network Construction of Univariate Chaotic Time Series Based on Maximum Mean Discrepancy - MDPI](https://www.mdpi.com/1099-4300/22/2/142)**  
mdpi.com

[637] **[Spectral Generation Methods & Applications - Emergent Mind](https://www.emergentmind.com/topics/spectral-generation)**  
emergentmind.com

[638] **[mapie.regression.MapieTimeSeriesRegressor — MAPIE 0.8.6 documentation](https://mapie.readthedocs.io/en/v0.8.6/generated/mapie.regression.MapieTimeSeriesRegressor.html)**  
readthedocs.io

[639] **[A Tutorial on Distribution-Free Uncertainty Quantification Using Conformal Prediction](https://www.researchgate.net/publication/397281346_A_Tutorial_on_Distribution-Free_Uncertainty_Quantification_Using_Conformal_Prediction)**  
researchgate.net

[640] **[RefusalBench: Generative Evaluation of Selective Refusal in Grounded Language Models - ACL Anthology](https://aclanthology.org/2026.eacl-long.321.pdf)**  
aclanthology.org

[641] **[Quantum Gaussian process model of potential energy surface for a polyatomic molecule](https://pubs.aip.org/aip/jcp/article/156/18/184802/2841296/Quantum-Gaussian-process-model-of-potential-energy)**  
aip.org

[642] **[Quantifying Uncertainty in Neural Network Ensembles using U-Statistics - Gianforte School of Computing](https://www.cs.montana.edu/users/john.sheppard/pubs/ijcnn-2020c.pdf)**  
montana.edu

[643] **[Evaluating Machine Learning Models for Molecular Property Prediction: Performance and Robustness on Out-of-Distribution Data - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12529777/)**  
nih.gov

[644] **[(PDF) Uncertainty estimation for out-of-distribution detection in computational histopathology](https://www.researchgate.net/publication/364440120_Uncertainty_estimation_for_out-of-distribution_detection_in_computational_histopathology)**  
researchgate.net

[645] **[Multimodal Out-of-Distribution Individual Uncertainty Quantification Enhances Binding Affinity Prediction for Polypharmacology | Code Ocean](https://codeocean.com/explore/f3316dc4-bbad-4c66-b4e7-fd78a90d1052?query=journal%3ANature%20Methods&page=1&filter=all)**  
codeocean.com

[646] **[(PDF) Adaptive Individual Uncertainty under Out-Of-Distribution Shift with Expert-Routed Conformal Prediction - ResearchGate](https://www.researchgate.net/publication/396692772_Adaptive_Individual_Uncertainty_under_Out-Of-Distribution_Shift_with_Expert-Routed_Conformal_Prediction)**  
researchgate.net

[647] **[A Gentle Introduction to Conformal Prediction and Distribution-Free Uncertainty Quantification - ResearchGate](https://www.researchgate.net/publication/353284898_A_Gentle_Introduction_to_Conformal_Prediction_and_Distribution-Free_Uncertainty_Quantification)**  
researchgate.net

[648] **[Analyzing Uncertainty of LLM-as-a-Judge: Interval Evaluations with Conformal Prediction](https://arxiv.org/html/2509.18658v1)**  
arxiv.org

[649] **[Continual Learning: The Missing Capability for Reliable AI at Scale - Medium](https://medium.com/@adnanmasood/continual-learning-the-missing-capability-for-reliable-ai-at-scale-c225e1a523de)**  
medium.com

[650] **[Being Bayesian about Categorical Probability - Proceedings of Machine Learning Research](http://proceedings.mlr.press/v119/joo20a/joo20a.pdf)**  
mlr.press

[651] **[Mixture of Autoencoder Experts - Emergent Mind](https://www.emergentmind.com/topics/mixture-of-autoencoder-experts)**  
emergentmind.com

[652] **[Knowing When Not to Answer: Evaluating Abstention in Multimodal Reasoning Systems](https://arxiv.org/html/2604.14799v1)**  
arxiv.org

[653] **[Catastrophic Forgetting Meets Negative Transfer: Batch Spectral Shrinkage for Safe Transfer Learning - NIPS](https://papers.nips.cc/paper_files/paper/2019/file/c6bff625bdb0393992c9d4db0c6bbe45-Paper.pdf)**  
nips.cc

[654] **[Wasserstein Distance Guided Representation Learning for Domain Adaptation | Request PDF - ResearchGate](https://www.researchgate.net/publication/363007166_Wasserstein_Distance_Guided_Representation_Learning_for_Domain_Adaptation)**  
researchgate.net

[655] **[Discrepancy-Based Networks for Unsupervised Domain Adaptation: A Comparative Study - CVF Open Access](https://openaccess.thecvf.com/content_ICCV_2017_workshops/papers/w38/Csurka_Discrepancy-Based_Networks_for_ICCV_2017_paper.pdf)**  
thecvf.com

[656] **[Artificial Intelligence in Spectroscopy: Advancing Chemistry from Prediction To Generation and Beyond - IJCAI](https://www.ijcai.org/proceedings/2025/1160.pdf)**  
ijcai.org

[657] **[Mixture of Experts Framework in Machine Learning Interatomic Potentials for Atomistic Simulations - arXiv](https://arxiv.org/html/2604.26143v1)**  
arxiv.org

[658] **[The Deferral Frontier: Reliability-Gated Selective Prediction for ...](https://assets-eu.researchsquare.com/files/rs-9887494/v1_covered_407c54ce-2494-4789-9521-063d5e10bec9.pdf)**  
researchsquare.com

[659] **[Multitask Learning Using Non Linear Model for Forecasting Task - White Rose eTheses Online](https://etheses.whiterose.ac.uk/id/eprint/36236/1/Multitask%20Learning%20Using%20Nonlinear%20Model%20for%20Forecasting%20Task.pdf)**  
whiterose.ac.uk

[660] **[An Alternative Infinite Mixture Of Gaussian Process Experts - Department of Computer Science, University of Toronto](https://www.cs.toronto.edu/~osindero/PUBLICATIONS/MeedsOsindero_dpme_nips.pdf)**  
toronto.edu

[661] **[Progressive Mixture-of-Experts with autoencoder routing for continual RANS turbulence modelling - arXiv](https://arxiv.org/html/2601.09305v1)**  
arxiv.org

[662] **[Cascaded Language Models for Cost-Effective Human–AI Decision-Making | OpenReview](https://openreview.net/forum?id=4Q1vA6P9J9)**  
openreview.net

[663] **[Transfer-learning on federated observational healthcare data for prediction models using Bayesian sparse logistic regression with informed priors - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12844582/)**  
nih.gov

[664] **[Latent Wasserstein Adversarial Imitation Learning - OpenReview](https://openreview.net/forum?id=xfnR9ok8HJ)**  
openreview.net

[665] **[FedDA-TSformer: Federated Domain Adaptation with vision TimeSformer for left ventricle segmentation on gated myocardial perfusion SPECT image - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12862020/)**  
nih.gov

[666] **[GRAVER: Generative Graph Vocabularies for Robust Graph Foundation Models Fine-tuning - Advances in Neural Information Processing Systems](https://papers.nips.cc/paper_files/paper/2025/file/185969291540b3cd86e70c51e8af5d08-Paper-Conference.pdf)**  
nips.cc

[667] **[Mixtures of Gaussian Process Experts with SMC2 - Journal of Machine Learning Research](http://www.jmlr.org/papers/volume26/22-0973/22-0973.pdf)**  
jmlr.org

[668] **[Conformal Deferral Rule: Hybrid Decision Making - Emergent Mind](https://www.emergentmind.com/topics/conformal-deferral-rule)**  
emergentmind.com

[669] **[Reliable machine learning models in genomic medicine using conformal prediction - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11891349/)**  
nih.gov

[670] **[Multi-Model Online Conformal Prediction - Emergent Mind](https://www.emergentmind.com/topics/multi-model-online-conformal-prediction)**  
emergentmind.com

[671] **[Towards a Better Microcredit Decision - arXiv](https://arxiv.org/pdf/2209.07574)**  
arxiv.org

[672] **[Nonlinear Models Using Dirichlet Process Mixtures - Journal of Machine Learning Research](https://jmlr.org/papers/volume10/shahbaba09a/shahbaba09a.pdf)**  
jmlr.org

[673] **[Mixture-of-Experts Variational Autoencoder for clustering and generating from similarity-based representations on single cell data | PLOS Computational Biology](https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1009086)**  
plos.org

[674] **[Cascaded Language Models for Cost-Effective Human–AI Decision-Making - NIPS](https://papers.neurips.cc/paper_files/paper/2025/file/10e0c427408ccc6e073d9464e2280f89-Paper-Conference.pdf)**  
neurips.cc

[675] **[Transfer Learning for Class Imbalance Problems with Inadequate Data - PMC - NIH](https://pmc.ncbi.nlm.nih.gov/articles/PMC4929860/)**  
nih.gov

[676] **[Hidden States Know Where Reasoning Diverges: Credit Assignment via Span-Level Wasserstein Distance - arXiv](https://arxiv.org/html/2604.23318v1)**  
arxiv.org

[677] **[Rethinking Joint Maximum Mean Discrepancy for Domain Adaptation - NIPS](https://proceedings.neurips.cc/paper_files/paper/2025/file/de2bc3eed995c24307e8011161ac1438-Paper-Conference.pdf)**  
neurips.cc

[678] **[Quantifying the Hardness of Bioactivity Prediction Tasks for Transfer Learning | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.4c00160)**  
acs.org

[679] **[a chemically-grounded explainability framework for spectral-based machine learning models - arXiv](https://arxiv.org/html/2605.02684v1)**  
arxiv.org

[680] **[Why massive context lengths and a Mixture of Experts could lead towards AGI. - Reddit](https://www.reddit.com/r/singularity/comments/14ybisu/why_massive_context_lengths_and_a_mixture_of/)**  
reddit.com

[681] **[Variational Mixture of Gaussian Process Experts](https://proceedings.neurips.cc/paper_files/paper/3395-variational-mixture-of-gaussian-process-experts.pdf)**  
neurips.cc

[682] **[The Coverage-Deferral Trade-Off: Fairness Implications of Conformal Prediction in Human-in-the-Loop Decision Systems](https://www.preprints.org/manuscript/202512.2631)**  
preprints.org

[683] **[Valid Selection among Conformal Sets - OpenReview](https://openreview.net/pdf?id=S1Gxt8c8pC)**  
openreview.net

[684] **[Online Localized Conformal Prediction](https://arxiv.org/html/2605.05497v2)**  
arxiv.org

[685] **[Trimmed Conformal Prediction for High-Dimensional Models - ResearchGate](https://www.researchgate.net/publication/311222751_Trimmed_Conformal_Prediction_for_High-Dimensional_Models)**  
researchgate.net

[686] **[Can we replace gemini vision with our own 4.7M param model? | by Ankit Agrawal](https://pub.towardsai.net/how-i-distilled-a-gemini-vision-model-into-a-4-6m-parameter-a44a6c40e4c2)**  
towardsai.net

[687] **[Information Aware max-norm Dirichlet networks for predictive uncertainty estimation](https://www.researchgate.net/publication/348080089_Information_Aware_max-norm_Dirichlet_networks_for_predictive_uncertainty_estimation)**  
researchgate.net

[688] **[Multi-Gate Mixture-of-Experts Stacked Autoencoders for Quality Prediction in Blast Furnace Ironmaking | ACS Omega - ACS Publications](https://pubs.acs.org/doi/10.1021/acsomega.2c05029)**  
acs.org

[689] **[Integrating Model Explainability and Uncertainty Quantification for Trustworthy Fraud Detection - MDPI](https://www.mdpi.com/2227-7080/14/4/212)**  
mdpi.com

[690] **[Bio-inspired fine-tuning for selective transfer learning in image classification - arXiv](https://arxiv.org/html/2601.11235v1)**  
arxiv.org

[691] **[Leveraging Distribution Alignment via Stein Path for Cross-Domain Cold-Start Recommendation - NIPS](https://proceedings.neurips.cc/paper/2021/file/a0443c8c8c3372d662e9173c18faaa2c-Paper.pdf)**  
neurips.cc

[692] **[Domain Adaptation via Maximizing Surrogate Mutual Information - IJCAI](https://www.ijcai.org/proceedings/2022/0237.pdf)**  
ijcai.org

[693] **[Machine Learning Methods for Small Data Challenges in Molecular Science - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10999174/)**  
nih.gov

[694] **[When Do Quantum Mechanical Descriptors Help Graph Neural Networks to Predict Chemical Properties? - ACS Publications](https://pubs.acs.org/doi/10.1021/jacs.4c04670)**  
acs.org

[695] **[Routing Manifold Alignment Improves Generalization of Mixture-of-Experts LLMs - arXiv](https://arxiv.org/html/2511.07419v1)**  
arxiv.org

[696] **[Mixture-of-Experts Approach for Enhanced Drug-Target Interaction Prediction and Confidence Assessment - bioRxiv](https://www.biorxiv.org/content/10.1101/2024.08.06.606753v1.full.pdf)**  
biorxiv.org

[697] **[No Need for Learning to Defer? A Training Free Deferral Framework to Multiple Experts through Conformal Prediction - arXiv](https://arxiv.org/html/2509.12573v3)**  
arxiv.org

[698] **[TECP: Token-Entropy Conformal Prediction for LLMs - arXiv](https://arxiv.org/html/2509.00461v1)**  
arxiv.org

[699] **[Valid Selection among Conformal Sets - OpenReview](https://openreview.net/forum?id=S1Gxt8c8pC)**  
openreview.net

[700] **[Optimizing LLM Decision-making with Conformal Prediction](https://icml.cc/media/icml-2025/Slides/46415.pdf)**  
icml.cc

[701] **[Combining Parameter-efficient Modules for Task-level Generalisation - ACL Anthology](https://aclanthology.org/2023.eacl-main.49.pdf)**  
aclanthology.org

[702] **[Deep Embedded Clustering as MoE - Machine Learning - HTM Forum](https://discourse.numenta.org/t/deep-embedded-clustering-as-moe/11085)**  
numenta.org

[703] **[Large language models for porous materials: from text mining to autonomous laboratory | Digital Discovery | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlehtml/2026/dd/d5dd00578g/)**  
rsc.org

[704] **[Pick-a-back: Selective Device-to-Device Knowledge Transfer in Federated Continual Learning - ECVA](https://www.ecva.net/papers/eccv_2024/papers_ECCV/papers/07822.pdf)**  
ecva.net

[705] **[TransMarker: Unveiling dynamic network biomarkers in cancer progression through cross-state graph alignment and optimal transport - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12668635/)**  
nih.gov

[706] **[Point-to-Set Metric-Gated Mixture of Experts for Multisource Domain Adaptation Fault Diagnosis - Home | Department of Computing](https://web.comp.polyu.edu.hk/pli/CoRR/TNNLS/TNNLS2025_Early_1.pdf)**  
polyu.edu.hk

[707] **[ICML Poster How Much Can Transfer? BRIDGE: Bounded Multi-Domain Graph Foundation Model with Generalization Guarantees](https://icml.cc/virtual/2025/poster/44723)**  
icml.cc

[708] **[Advancing Expert Specialization for Better MoE - NIPS](https://papers.nips.cc/paper_files/paper/2025/file/4598de7d243d528e38eb0c5d8155fb52-Paper-Conference.pdf)**  
nips.cc

[709] **[Identifiable Mixtures of Sparse Variational Gaussian Process Experts](https://aidanscannell.com/publications/identifiable-mixtures-of-sparse-variational-gaussian-process-experts/oxford-2021-mogpe.pdf)**  
aidanscannell.com

[710] **[Uncertainty in AI Predictions for Computational Chemistry - KAMI Think Tank](https://www.kamithinktank.com/computational-chemist/uncertainty-in-ai-predictions-for-computational-chemistry)**  
kamithinktank.com

[711] **[Dynamic Routing on a Static Structure: Noradrenergic Gating of Cortical Wave Propagation](https://www.biorxiv.org/content/10.64898/2026.02.10.705210v1.full-text)**  
biorxiv.org

[712] **[Atomic Uncertainty Pinpoints Critical Failure Structures for Trustworthy Molecular Property Prediction | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.6c00973)**  
acs.org

[713] **[LAMBench: A Benchmark for Large Atomic Models - arXiv](https://arxiv.org/html/2504.19578v1)**  
arxiv.org

[714] **[Learning Inducing Points and Uncertainty on Molecular Data by Scalable Variational Gaussian Processes - SIAM Publications Library](https://epubs.siam.org/doi/10.1137/23M1549584)**  
siam.org

[715] **[Reliable and Adaptive Probabilistic Forecasting for Event-Driven Water-Quality Time Series Using a Gated Hybrid–Mixture Density Network - MDPI](https://www.mdpi.com/1424-8220/25/24/7560)**  
mdpi.com

[716] **[Adapting Evidential Neural Networks to Test-Time Neighbor Fusion Improves Molecular Property Prediction - arXiv](https://arxiv.org/html/2607.11091v1)**  
arxiv.org

[717] **[Deep Batch Active Learning for Drug Discovery - eLife](https://elifesciences.org/reviewed-preprints/89679v1)**  
elifesciences.org

[718] **[ChemEval: A Comprehensive Multi-Level Chemical Evalution for Large Language Models - arXiv](https://arxiv.org/pdf/2409.13989)**  
arxiv.org

[719] **[Providing Machine Learning Potentials with High Quality Uncertainty Estimates - arXiv](https://arxiv.org/html/2501.05250v1)**  
arxiv.org

[720] **[Enhanced thermophysical property prediction with uncertainty quantification using group contribution-Gaussian process regression | Molecular Systems Design & Engineering | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlelanding/2026/me/d5me00126a)**  
rsc.org

[721] **[Optimizing Chemical Reactions with Deep Reinforcement Learning | ACS Central Science](https://pubs.acs.org/doi/10.1021/acscentsci.7b00492)**  
acs.org

[722] **[Uncertainty-Aware Multi-Objective Reinforcement Learning-Guided Diffusion Models for 3D De Novo Molecular Design - arXiv](https://arxiv.org/html/2510.21153v1)**  
arxiv.org

[723] **[Towards out-of-distribution generalizable predictions of chemical kinetic properties](https://openreview.net/forum?id=2vernsvOi2)**  
openreview.net

[724] **[Active Learning for Rapid Targeted Synthesis of Compositionally Complex Alloys - MDPI](https://www.mdpi.com/1996-1944/17/16/4038)**  
mdpi.com

[725] **[Prediction of Multi-Pharmacokinetics Property in Multi-Species: Bayesian Neural Network Stacking Model with Uncertainty | Molecular Pharmaceutics - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.molpharmaceut.4c00406)**  
acs.org

[726] **[Learning inducing points and uncertainty on molecular data by scalable variational Gaussian processes - arXiv](https://arxiv.org/html/2207.07654v3)**  
arxiv.org

[727] **[Layer and rhythm specificity for predictive routing - PNAS](https://www.pnas.org/doi/10.1073/pnas.2014868117)**  
pnas.org

[728] **[Bayesian Uncertainty-Guided Fidelity Fusion for Bioactivity Prediction - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.6c01190)**  
acs.org

[729] **[LoRA-Chem: Modular Machine Learning for Multitask Prediction in Organic Reactions | CCS Chemistry - Chinese Chemical Society](https://www.chinesechemsoc.org/doi/10.31635/ccschem.025.202506542)**  
chinesechemsoc.org

[730] **[A Comprehensive Investigation of Active Learning Strategies for Conducting Anti-Cancer Drug Screening - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10854925/)**  
nih.gov

[731] **[(PDF) MolScore: a scoring, evaluation and benchmarking framework for generative models in de novo drug design - ResearchGate](https://www.researchgate.net/publication/381006257_MolScore_a_scoring_evaluation_and_benchmarking_framework_for_generative_models_in_de_novo_drug_design)**  
researchgate.net

[732] **[Physics-Informed Bayesian Optimization for Conformational Ensemble Augmentation](https://pubs.acs.org/doi/10.1021/acs.jcim.5c00522)**  
acs.org

[733] **[Leveraging uncertainty estimates and derivative information in Gaussian process regression for efficient collection and use of molecular simulation data - AIP Publishing](https://pubs.aip.org/aip/jcp/article/158/16/164110/2886897/Leveraging-uncertainty-estimates-and-derivative)**  
aip.org

[734] **[Prediction of chemical reaction yields with large-scale multi-view pre-training - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10895839/)**  
nih.gov

[735] **[Six Open Questions in Machine-Learned Interatomic Potential Foundation Models - arXiv](https://arxiv.org/html/2606.07327v2)**  
arxiv.org

[736] **[NeurIPS 2025 Papers](https://neurips.cc/virtual/2025/papers.html)**  
neurips.cc

[737] **[by Manas Mahale - This Week In Cheminformatics: Issue #021](https://thisweekincheminformatics.substack.com/p/twenty-one)**  
substack.com

[738] **[Uncovering Neural Scaling Laws in Molecular Representation Learning - Yanqiao ZHU](https://sxkdz.github.io/files/publications/NeurIPS/MolScaling/MolScaling.pdf)**  
github.io

[739] **[Towards Unified and Lossless Latent Space for 3D Molecular Latent Diffusion Modeling - NIPS](https://papers.neurips.cc/paper_files/paper/2025/file/2c2f104b95306ab94058a97ba13b8927-Paper-Conference.pdf)**  
neurips.cc

[740] **[Towards interpretable Cryo-EM: disentangling latent spaces of molecular conformations](https://www.frontiersin.org/journals/molecular-biosciences/articles/10.3389/fmolb.2024.1393564/full)**  
frontiersin.org

[741] **[Benchmarking Domain Adaptation for Chemical Processes on the Tennessee Eastman Process](https://ml4cce-ecml.com/papers/54.pdf)**  
ml4cce-ecml.com

[742] **[Drug Discovery under Covariate Shift with Domain-Informed Prior Distributions over Functions](https://proceedings.mlr.press/v202/klarner23a/klarner23a.pdf)**  
mlr.press

[743] **[Quantifying the hardness of bioactivity prediction tasks for transfer learning - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv-2024-871mt)**  
chemrxiv.org

[744] **[MoTSE: an interpretable task similarity estimator for small molecular property prediction tasks | bioRxiv](https://www.biorxiv.org/content/10.1101/2021.01.13.426608v2)**  
biorxiv.org

[745] **[A systematic review of molecular representation learning foundation models - Oxford Academic](https://academic.oup.com/bib/article/27/1/bbaf703/8418201)**  
oup.com

[746] **[Multi-Task Fine-Tuning Enables Robust Out-of-Distribution Generalization in Atomistic Models - arXiv](https://arxiv.org/html/2601.08486v1)**  
arxiv.org

[747] **[Latent spaces for antimicrobial peptide design† | Digital Discovery | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlelanding/2023/dd/d2dd00091a)**  
rsc.org

[748] **[Correcting Nuisance Variation using Wasserstein Distance | OpenReview](https://openreview.net/forum?id=H18uzzWAZ)**  
openreview.net

[749] **[(PDF) Improving molecular representation learning with metric learning-enhanced optimal transport - ResearchGate](https://www.researchgate.net/publication/370037468_Improving_molecular_representation_learning_with_metric_learning-enhanced_optimal_transport)**  
researchgate.net

[750] **[Generative modeling of single-cell gene expression for dose-dependent chemical perturbations - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10436058/)**  
nih.gov

[751] **[Why Engineering Demands Specialized AI | by Souvik Ta | Data Science Collective](https://medium.com/data-science-collective/why-engineering-demands-specialized-ai-03a427beaa7a)**  
medium.com

[752] **[Advanced deep learning methods for molecular property prediction - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12807101/)**  
nih.gov

[753] **[Review of Molecular Representation Learning Models](https://hunterheidenreich.com/notes/chemistry/molecular-representations/notations/molecular-representation-learning-foundation-models-review/)**  
hunterheidenreich.com

[754] **[The Jekyll-and-Hyde electron transfer chemistry of hydrogen bonds - NSF PAR](https://par.nsf.gov/servlets/purl/10563564)**  
nsf.gov

[755] **[Kernel-elastic autoencoder for molecular design - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11059255/)**  
nih.gov

[756] **[The Wasserstein Distance as a Dissimilarity Measure for Mass Spectra with Application to Spectral Deconvolution - DROPS](https://drops.dagstuhl.de/storage/00lipics/lipics-vol113-wabi2018/LIPIcs.WABI.2018.25/LIPIcs.WABI.2018.25.pdf)**  
dagstuhl.de

[757] **[An Innovative Multi-Omics Model Integrating Latent Alignment and Attention Mechanism for Drug Response Prediction - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11277895/)**  
nih.gov

[758] **[Improving molecular representation learning with metric learning-enhanced optimal transport - PubMed](https://pubmed.ncbi.nlm.nih.gov/37123438/)**  
nih.gov

[759] **[Learning Invariant Molecular Representation in Latent Discrete Space - OpenReview](https://openreview.net/pdf?id=r9fzp8eyhZ)**  
openreview.net

[760] **[Latent Variable Machine Learning Framework for Catalysis: General Models, Transfer Learning, and Interpretability | JACS Au - ACS Publications](https://pubs.acs.org/doi/10.1021/jacsau.3c00419)**  
acs.org

[761] **[Transfer Learning Approaches in Bioprocess Engineering ... - KIT](https://publikationen.bibliothek.kit.edu/1000193214/181017391)**  
kit.edu

[762] **[Meta-learning linear models for molecular property prediction | Digital Discovery | The Royal Society of Chemistry](https://pubs.rsc.org/sign-in?returnUrl=%2Fdd%2Farticle%2Fdoi%2F10.1039%2Fd5dd00443h%2F1237388%2FMeta-learning-linear-models-for-molecular-property)**  
rsc.org

[763] **[Machine learning helps make enzyme-powered chemistry greener - IBM Research](https://research.ibm.com/blog/ml-for-enzyme-powered-green-chemistry)**  
ibm.com

[764] **[Molecular Contrastive Pretraining with Collaborative Featur- izations - OpenReview](https://openreview.net/pdf/673cd69207ce99f5afc731914f17dbb45bbd596a.pdf)**  
openreview.net

[765] **[Electronic Structure of Polyethylene: Role of Chemical, Morphological and Interfacial Complexity - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC5522474/)**  
nih.gov

[766] **[Real-World Molecular Out-Of-Distribution: Specification and Investigation | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.3c01774)**  
acs.org

[767] **[Towards Unified and Lossless Latent Space for 3D Molecular Latent Diffusion Modeling - arXiv](https://arxiv.org/html/2503.15567v3)**  
arxiv.org

[768] **[Correcting nuisance variation using Wasserstein distance - PMC - NIH](https://pmc.ncbi.nlm.nih.gov/articles/PMC7050548/)**  
nih.gov

[769] **[Decomposing cell identity for transfer learning across cellular measurements, platforms, tissues, and species - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC6588402/)**  
nih.gov

[770] **[Optimal Transport for Domain Adaptation - arXiv](https://arxiv.org/pdf/1507.00504)**  
arxiv.org

[771] **[TarDis: Achieving Robust and Structured Disentanglement of Multiple Covariates | bioRxiv](https://www.biorxiv.org/content/10.1101/2024.06.20.599903v1.full-text)**  
biorxiv.org

[772] **[Machine Learning for Retention Time Prediction in LC: What the ...](https://www.sepscience.com/machine-learning-for-retention-time-prediction-in-lc-what-the-models-can-actually-do-12556)**  
sepscience.com

[773] **[MoTSE: an interpretable task similarity estimator for small molecular property prediction tasks | bioRxiv](https://www.biorxiv.org/content/10.1101/2021.01.13.426608v2.full-text)**  
biorxiv.org

[774] **[Structurally and electronically driven uniaxial negative thermal expansion in BaIrO 3](https://pubs.rsc.org/zh-hans/content/articlehtml/2025/cc/d4cc06174h)**  
rsc.org

[775] **[Learning Disentangled Equivariant Representation for Explicitly Controllable 3D Molecule Generation - arXiv](https://arxiv.org/html/2412.15086v1)**  
arxiv.org

[776] **[Trustworthy Inverse Molecular Design via Alignment with Molecular Dynamics](https://aidam.mpi-inf.mpg.de/data/pdfs/timdvawmd.pdf)**  
mpg.de

[777] **[Optimal Transport for Domain Adaptation through Gaussian Mixture Models - OpenReview](https://openreview.net/pdf/432c4851ce063ae9e388bc7bbced8518b460fa58.pdf)**  
openreview.net

[778] **[(PDF) Quantification via Gaussian Latent Space Representations - ResearchGate](https://www.researchgate.net/publication/388353894_Quantification_via_Gaussian_Latent_Space_Representations)**  
researchgate.net

[779] **[Assessment of Machine Learning Reliability Methods for Quantifying the Applicability Domain of QSAR Regression Models - ACS Publications - American Chemical Society](https://pubs.acs.org/doi/10.1021/ci4006595)**  
acs.org

[780] **[Pairwise learning for molecular property prediction and optimization - Frontiers](https://www.frontiersin.org/journals/drug-discovery/articles/10.3389/fddsv.2026.1859068/full)**  
frontiersin.org

[781] **[Active Transfer Learning Techniques For Cross-Chemistry MAP Models - PatSnap Eureka](https://eureka.patsnap.com/report-active-transfer-learning-techniques-for-cross-chemistry-map-models)**  
patsnap.com

[782] **[Towards efficient and reliable artificial intelligence through neuromorphic principles - Royal Society Publishing](https://royalsocietypublishing.org/rsta/article/384/2315/20240522/480517/Towards-efficient-and-reliable-artificial)**  
royalsocietypublishing.org

[783] **[Alignment of density maps in Wasserstein distance - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11016369/)**  
nih.gov

[784] **[A Review on Transferability Estimation in Deep Transfer Learning - IEEE Computer Society](https://www.computer.org/csdl/journal/ai/2024/12/10639517/1Zxz3j58LGE)**  
computer.org

[785] **[Optimisation of electronic nose performance with multi-attention and domain adaptation for fire forensics | Analytical Methods | The Royal Society of Chemistry](https://pubs.rsc.org/st/content/articlelanding/2025/ay/d5ay00474h)**  
rsc.org

[786] **[Examining graph neural networks for crystal structures: Limitations and opportunities for capturing periodicity - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10637739/)**  
nih.gov

[787] **[Advancing materials science through next-generation machine learning - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11285097/)**  
nih.gov

[788] **[Graph Comparison of Molecular Crystals in Band Gap Prediction Using Neural Networks](https://pmc.ncbi.nlm.nih.gov/articles/PMC10601046/)**  
nih.gov

[789] **[Personalized federated learning for fault diagnosis with mixture of experts - ResearchGate](https://www.researchgate.net/publication/393284858_Personalized_federated_learning_for_fault_diagnosis_with_mixture_of_experts)**  
researchgate.net

[790] **[Knowing when to trust machine-learned interatomic potentials - arXiv](https://arxiv.org/html/2605.00640v1)**  
arxiv.org

[791] **[ShiftBench: A Benchmark for Per-Cohort Certify-or-Abstain ...](https://openreview.net/pdf?id=JLnxxLg0nX)**  
openreview.net

[792] **[The Latent Space: Foundation, Evolution, Mechanism, Ability, and Outlook - arXiv](https://arxiv.org/html/2604.02029v1)**  
arxiv.org

[793] **[Wasserstein metric - Wikipedia](https://en.wikipedia.org/wiki/Wasserstein_metric)**  
wikipedia.org

[794] **[Chemical Space Covered by Applicability Domains of Quantitative Structure–Property Relationships and Semiempirical Relationships in Chemical Assessments | Environmental Science & Technology - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.est.3c05643)**  
acs.org

[795] **[Combating Negative Transfer From Predictive Distribution Differences - DR-NTU](https://dr.ntu.edu.sg/bitstreams/f3ef1e7f-4f72-409f-a363-cab5e8540c43/download)**  
ntu.edu.sg

[796] **[Efficient Prediction of Transition-Metal NMR Chemical Shifts Using Machine Learning: Do Two-Dimensional Descriptors Suffice? - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.6c01787)**  
acs.org

[797] **[Representations of Materials for Machine Learning - Annual Reviews](https://www.annualreviews.org/content/journals/10.1146/annurev-matsci-080921-085947?crawler=true&mimetype=application/pdf)**  
annualreviews.org

[798] **[Transfer learning on large datasets for the accurate prediction of material properties](https://pubs.rsc.org/en/content/articlehtml/2023/dd/d3dd00030c)**  
rsc.org

[799] **[Advances in graph neural networks for alloy design and properties predictions: a review](https://www.oaepublish.com/articles/jmi.2025.42)**  
oaepublish.com

[800] **[Cyberspace Security Using Adversarial Learning and Conformal Prediction - Scirp.org.](https://www.scirp.org/journal/paperinformation?paperid=57866)**  
scirp.org

[801] **[Reliable Out-of-Distribution Recognition of Synthetic Images - MDPI](https://www.mdpi.com/2313-433X/10/5/110)**  
mdpi.com

[802] **[Reducing cross-sample prediction churn in scientific machine learning - arXiv](https://arxiv.org/html/2605.13826v1)**  
arxiv.org

[803] **[CROSS DOMAIN LATENT SPACE ALIGNMENT FOR ZERO SHOT KNOWLEDGE TRANSFER IN LARGE SCALE NEURO SYMBOLIC FOUNDATION MODELS - ResearchGate](https://www.researchgate.net/publication/406981149_CROSS_DOMAIN_LATENT_SPACE_ALIGNMENT_FOR_ZERO_SHOT_KNOWLEDGE_TRANSFER_IN_LARGE_SCALE_NEURO_SYMBOLIC_FOUNDATION_MODELS)**  
researchgate.net

[804] **[The Unbalanced Gromov Wasserstein Distance: Conic Formulation and Relaxation](https://proceedings.neurips.cc/paper/2021/file/4990974d150d0de5e6e15a1454fe6b0f-Paper.pdf)**  
neurips.cc

[805] **[llms - Chandan Singh](https://csinva.io/notes/research_ovws/ovw_llms.html)**  
csinva.io

[806] **[Quantitative Structure-activity Relationship: A Comprehensive Guide for 2025 - Shadecoder - 100% Invisibile AI Coding Interview Copilot](https://www.shadecoder.com/topics/quantitative-structure-activity-relationship-a-comprehensive-guide-for-2025)**  
shadecoder.com

[807] **[Predicting reaction conditions from limited data through active transfer learning - Ambuj Tewari](https://www.ambujtewari.com/research/kim22predicting.pdf)**  
ambujtewari.com

[808] **[Mechanistic Chromatographic Column Characterization for the Analysis of Flavonoids Using Quantitative Structure-Retention Relationships Based on Density Functional Theory - MDPI](https://www.mdpi.com/1422-0067/21/6/2053)**  
mdpi.com

[809] **[Representations and strategies for transferable machine learning improve model performance in chemical discovery - AIP Publishing](https://pubs.aip.org/aip/jcp/article/156/7/074101/2840729/Representations-and-strategies-for-transferable)**  
aip.org

[810] **[Benchmarking Coordination Number Prediction Algorithms on Inorganic Crystal Structures](https://pubs.acs.org/doi/10.1021/acs.inorgchem.0c02996)**  
acs.org

[811] **[A Universal Deep Learning Framework based on Graph Neural ...](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv.13514903)**  
chemrxiv.org

[812] **[arXiv:2310.09163v2 [cs.LG] 10 May 2024](https://arxiv.org/pdf/2310.09163)**  
arxiv.org

[813] **[Active Learning and the Potential of Neural Networks Accelerate Molecular Screening for the Design of a New Molecule Effective against SARS-CoV-2 - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC8172298/)**  
nih.gov

[814] **[Chemical Space Covered by Applicability Domains of Quantitative Structure–Property Relationships and Semiempirical Relationships in Chemical Assessments - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10882972/)**  
nih.gov

[815] **[Enhancing Machine Learning Potentials through Transfer Learning across Chemical Elements - arXiv](https://arxiv.org/html/2502.13522v1)**  
arxiv.org

[816] **[Mechanistic Study of the Nanoscale Negative-Tone Pattern Transfer from DNA Nanostructures to SiO2 | Chemistry of Materials - ACS Publications](https://pubs.acs.org/doi/10.1021/cm5044914)**  
acs.org

[817] **[Full article: Machine learning reveals orbital interaction in materials - Taylor & Francis](https://www.tandfonline.com/doi/full/10.1080/14686996.2017.1378060)**  
tandfonline.com

[818] **[Wyckoff Transformer: Generation of Symmetric Crystals - arXiv](https://arxiv.org/html/2503.02407v1)**  
arxiv.org

[819] **[Materials representation and transfer learning for multi-property prediction - AIP Publishing](https://pubs.aip.org/aip/apr/article/8/2/021409/1067988/Materials-representation-and-transfer-learning-for)**  
aip.org

[820] **[Model Agnostic Graph Prompt Learning for Crystal Property Prediction - arXiv](https://arxiv.org/html/2607.08996v1)**  
arxiv.org

[821] **[Provenance Information for Biomedical Data and Workflows: Scoping Review](https://www.jmir.org/2024/1/e51297/)**  
jmir.org

[822] **[Software - The Hu Lab](https://phulab.org/software)**  
phulab.org

[823] **[Increasing trustworthiness of machine learning-based drug sensitivity prediction with a multivariate random forest approach | Digital Discovery | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlelanding/2026/dd/d5dd00284b)**  
rsc.org

[824] **[Quantifying the reliability gap in cross-domain plant disease classification: benchmarking the limited efficacy of standard mitigation techniques under controlled-to-field shift - Frontiers](https://www.frontiersin.org/journals/plant-science/articles/10.3389/fpls.2026.1826962/full)**  
frontiersin.org

[825] **[A Deterministic Sampling Method via Maximum Mean Discrepancy Flow with Adaptive Kernel - arXiv](https://arxiv.org/html/2111.10722v4)**  
arxiv.org

[826] **[Joint applicability domain of a single-descriptor quantitative structure-activity relationship](https://www.researchgate.net/figure/Joint-applicability-domain-of-a-single-descriptor-quantitative-structure-activity_fig6_7583123)**  
researchgate.net

[827] **[Molecular representation learning: cross-domain foundations and future Frontiers | Digital Discovery | The Royal Society of Chemistry](https://pubs.rsc.org/dd/article/4/9/2298/889072/Molecular-representation-learning-cross-domain)**  
rsc.org

[828] **[Learning Mechanistic Reasoning for Chemical Reactions with Large Language Models](https://arxiv.org/html/2607.12771v1)**  
arxiv.org

[829] **[Generalizable classification of crystal structure error types using graph attention networks](https://pubs.rsc.org/en/content/articlehtml/2025/ta/d5ta05426e)**  
rsc.org

[830] **[Transfer Learning-Enhanced Prediction of Glass Transition Temperature in Bismaleimide-Based Polyimides - MDPI](https://www.mdpi.com/2073-4360/17/13/1833)**  
mdpi.com

[831] **[Hybrid Graph–Machine Learning Framework for Accurate and Interpretable Band Gap Prediction | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.6c00365)**  
acs.org

[832] **[Provenance-Aware Storage Systems - seltzer.com](https://www.seltzer.com/assets/publications/ProvenanceAware-Storage-Systems.htm)**  
seltzer.com

[833] **[Scaffold splits hide structural-frontier failures in ADMET models - arXiv](https://arxiv.org/html/2607.10729v1)**  
arxiv.org

[834] **[Algorithmically defined therapeutic targets: integrating single-cell transfer learning frameworks with small molecule drugs to reverse disease-associated cell fates - Frontiers](https://www.frontiersin.org/journals/pharmacology/articles/10.3389/fphar.2026.1786561/full)**  
frontiersin.org

[835] **[Chemical technology principles for selective bioconjugation of proteins and antibodies](https://pubs.rsc.org/cs/article/53/1/380/803943/Chemical-technology-principles-for-selective)**  
rsc.org

[836] **[Adapting differential molecular representation with hierarchical prompts for multi-label property prediction | Briefings in Bioinformatics | Oxford Academic](https://academic.oup.com/bib/article/25/5/bbae438/7754116)**  
oup.com

[837] **[Traditional vs. Deep Learning for Molecular Property Prediction: A Comprehensive Comparison for Drug Discovery - Theoretical ChemTech Insights](https://www.theochemtek.com/posts/traditional-vs-deep-learning-for-molecular-property-prediction-a-comprehensive-comparison-for-drug-discovery)**  
theochemtek.com

[838] **[Leveraging Transfer Learning for Predicting Protein–Small-Molecule Interaction Predictions](https://pmc.ncbi.nlm.nih.gov/articles/PMC13091560/)**  
nih.gov

[839] **[Understanding and Improving Feature Learning for Out-of-Distribution Generalization](https://proceedings.neurips.cc/paper_files/paper/2023/file/d73d5645ddbb9ada6c862116435574f6-Paper-Conference.pdf)**  
neurips.cc

[840] **[Engineering selective competitors for the discrimination of highly conserved protein-protein interaction modules - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC6778148/)**  
nih.gov

[841] **[Secure and Differentially Private Federated Graph Learning for Molecular Property Prediction - MDPI](https://www.mdpi.com/2227-7390/14/14/2454)**  
mdpi.com

[842] **[Evaluating AI-Generated Molecules for Drug Discovery: From Generic Metrics to Translational Readiness - MDPI](https://www.mdpi.com/1422-0067/27/13/5916)**  
mdpi.com

[843] **[ICML Poster Sparse Causal Discovery with Generative Intervention for Unsupervised Graph Domain Adaptation](https://icml.cc/virtual/2025/poster/45274)**  
icml.cc

[844] **[Recent Advances in Selective and Irreversible Covalent Ligand Development and Validation - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC6886688/)**  
nih.gov

[845] **[On the Out-Of-Distribution Generalization of Multimodal Large Language Models - arXiv](https://arxiv.org/html/2402.06599v1)**  
arxiv.org

[846] **[The Chemical Information Ontology: Provenance and Disambiguation for Chemical Data on the Biological Semantic Web - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC3184996/)**  
nih.gov

[847] **[Transition-Metal-Catalyzed Transformations for the Synthesis of Marine Drugs - MDPI](https://www.mdpi.com/1660-3397/22/6/253)**  
mdpi.com

[848] **[Inverse Design for Conditional Distribution Matching - arXiv](https://arxiv.org/html/2605.09439v1)**  
arxiv.org

[849] **[Single-Electron-Transfer-Mediated Carbonylation Reactions - PMC - NIH](https://pmc.ncbi.nlm.nih.gov/articles/PMC11924242/)**  
nih.gov

[850] **[Statistical Optimal Transport - Sinho Chewi](https://chewisinho.github.io/st_flour.pdf)**  
github.io

[851] **[The road to green efficiency: exploration of multicomponent reactions from transition metal catalysis to no catalyst conditions - Royal Society of Chemistry journals](https://pubs.rsc.org/en/content/articlelanding/2025/re/d4re00522h)**  
rsc.org

[852] **[Provenance Information for Biomedical Data and Workflows: Scoping Review - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11380065/)**  
nih.gov

[853] **[(PDF) The Role of Transition Metal Complexes in Catalysis: Mechanisms and Industrial Applications - ResearchGate](https://www.researchgate.net/publication/394343033_The_Role_of_Transition_Metal_Complexes_in_Catalysis_Mechanisms_and_Industrial_Applications)**  
researchgate.net

[854] **[Classifier Calibration at Scale: An Empirical Study of Model-Agnostic Post-Hoc Methods](https://arxiv.org/html/2601.19944v1)**  
arxiv.org

[855] **[Representation Similarity Analysis for Efficient Task Taxonomy & Transfer Learning | Request PDF - ResearchGate](https://www.researchgate.net/publication/338509447_Representation_Similarity_Analysis_for_Efficient_Task_Taxonomy_Transfer_Learning)**  
researchgate.net

[856] **[Guiding questions to avoid data leakage in biological machine learning applications](https://www.researchgate.net/publication/383017584_Guiding_questions_to_avoid_data_leakage_in_biological_machine_learning_applications)**  
researchgate.net

[857] **[Preregistration - Center for Open Science (COS)](https://www.cos.io/initiatives/prereg)**  
cos.io

[858] **[Computer Science - arXiv](https://www.arxiv.org/list/cs/pastweek?skip=1550&show=2000)**  
arxiv.org

[859] **[“The distinction between exploratory and confirmatory research cannot be important per se, because it implies that the time at which things are said is important” | Statistical Modeling, Causal Inference, and Social Science](https://statmodeling.stat.columbia.edu/2022/09/15/the-distinction-between-exploratory-and-confirmatory-research-cannot-be-important-per-se-because-it-implies-that-the-time-at-which-things-are-said-is-important/)**  
columbia.edu

[860] **[EvoluNet: Advancing Dynamic Non-IID Transfer Learning on Graphs - arXiv](https://arxiv.org/pdf/2305.00664)**  
arxiv.org

[861] **[csinva.github.io/_notes/research_ovws/ovw_llms.md at master · csinva/csinva.github.io · GitHub](https://github.com/csinva/csinva.github.io/blob/master/_notes/research_ovws/ovw_llms.md)**  
github.com

[862] **[Honest Computing: achieving demonstrable data lineage and provenance for driving data and process-sensitive policies](https://www.cambridge.org/core/journals/data-and-policy/article/honest-computing-achieving-demonstrable-data-lineage-and-provenance-for-driving-data-and-processsensitive-policies/B1F021006F26F202A262051002B50A26)**  
cambridge.org

[863] **[Questionable Research Practices, Low Statistical Power, and Other Obstacles to Replicability: Why Preclinical Neuroscience Research Would Benefit from Registered Reports - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC9351632/)**  
nih.gov

[864] **[Daily Papers - Hugging Face](https://huggingface.co/papers?q=category-conditioned%20routing)**  
huggingface.co

[865] **[Efficient Near-Infrared Spectrum Detection in Nondestructive Wood Testing via Transfer Network Redesign - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10893441/)**  
nih.gov

[866] **[An End-User Audit of Reproducibility, Data Leakage, and Overfitting of the Top-Ranked ADMET Prediction Models in TDC Leaderboards - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.6c00819)**  
acs.org

[867] **[(PDF) External validation of machine learning models - registered models and adaptive sample splitting - ResearchGate](https://www.researchgate.net/publication/376218803_External_validation_of_machine_learning_models_-_registered_models_and_adaptive_sample_splitting)**  
researchgate.net

[868] **[GPF-EVMoLE: An ETS-Driven Variable Selection and Mixture-of-Experts Framework for Multi-Step Garlic Price Forecasting - MDPI](https://www.mdpi.com/2071-1050/18/9/4404)**  
mdpi.com

[869] **[EvoluNet: Advancing Dynamic Non-IID Transfer Learning on Graphs - arXiv](https://arxiv.org/html/2305.00664v5)**  
arxiv.org

[870] **[Prodrug-ML: prodrug-likeness prediction via machine learning on sampled negative decoys - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12790554/)**  
nih.gov

[871] **[CMC Regulatory Strategy: Drug Development Guide May 2026 - Assyro AI](https://www.assyro.com/blog/cmc-regulatory-strategy)**  
assyro.com

[872] **[A hybrid framework integrating structural machine learning and 3D liver-on-chip assay for drug-induced liver injury prediction - bioRxiv](https://www.biorxiv.org/content/10.64898/2026.06.15.732231v1.full.pdf)**  
biorxiv.org

[873] **[Ligand field and density functional descriptions of the d-states and bonding in transition metal complexes | Request PDF - ResearchGate](https://www.researchgate.net/publication/9065425_Ligand_field_and_density_functional_descriptions_of_the_d-states_and_bonding_in_transition_metal_complexes)**  
researchgate.net

[874] **[Benchmarking Domain Adaptation for Chemical Processes on the Tennessee Eastman Process - arXiv](https://arxiv.org/html/2308.11247v2)**  
arxiv.org

[875] **[p–d orbital hybridization induced by transition metal atom sites for room-temperature sodium–sulfur batteries - Oxford Academic](https://academic.oup.com/nsr/advance-article/doi/10.1093/nsr/nwaf241/8160416)**  
oup.com

[876] **[Wasserstein Distance Learns Domain Invariant Feature Representations for Drift Compensation of E-Nose - MDPI](https://www.mdpi.com/1424-8220/19/17/3703)**  
mdpi.com

[877] **[arXiv:2002.08260v3 [stat.ML] 26 Jul 2021](https://arxiv.org/pdf/2002.08260)**  
arxiv.org

[878] **[AI-Driven Analytical and Molecular Data Modeling for Environmental and Pharmaceutical Applications](https://saudijournals.com/media/articles/SIJCMS_94_175-230_VjjUdve.pdf)**  
saudijournals.com

[879] **[Metal-Ligand Role Reversal: Hydride Transfer Catalysis by a Functional Phosphorus Ligand with a Spectator Metal - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC9712262/)**  
nih.gov

[880] **[The balancing principle for parameter choice in distance-regularized domain adaptation](https://proceedings.neurips.cc/paper/2021/file/ae0909a324fb2530e205e52d40266418-Paper.pdf)**  
neurips.cc

[881] **[Revealing axial-ligand-induced switching of spin states for controllable single electron transfer-based radical initiation - Chemical Science (RSC Publishing) DOI:10.1039/D5SC02194D - Royal Society of Chemistry journals](https://pubs.rsc.org/en/content/articlehtml/2025/sc/d5sc02194d)**  
rsc.org

[882] **[Conformal Prediction for Molecular Properties under Label Shift - NeurIPS 2026](https://neurips.cc/virtual/2025/125228)**  
neurips.cc

[883] **[Quantifying Uncertainty in Void Swelling Prediction: A Conformal Prediction Framework for Reactor Safety Margins - arXiv](https://arxiv.org/html/2603.01981v1)**  
arxiv.org

[884] **[Development and Evaluation of Conformal Prediction Methods for Quantitative Structure–Activity Relationship | ACS Omega](https://pubs.acs.org/doi/10.1021/acsomega.4c02017)**  
acs.org

[885] **[Selective Classification via One-Sided Prediction - Proceedings of Machine Learning Research](https://proceedings.mlr.press/v130/gangrade21a/gangrade21a.pdf)**  
mlr.press

[886] **[[2506.21802] Classification with Reject Option: Distribution-free Error Guarantees via Conformal Prediction - arXiv](https://arxiv.org/abs/2506.21802)**  
arxiv.org

[887] **[Conformal prediction under feedback covariate shift for biomolecular design - PNAS](https://www.pnas.org/doi/10.1073/pnas.2204569119)**  
pnas.org

[888] **[Conformalized Graph Learning for Molecular ADMET Property Prediction and Reliable Uncertainty Quantification | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/abs/10.1021/acs.jcim.4c01139)**  
acs.org

[889] **[Distribution-Free Uncertainty Quantification in Mechanical Ventilation Treatment: A Conformal Deep Q-Learning Framework](https://ojs.aaai.org/index.php/AAAI/article/view/35013/37168)**  
aaai.org

[890] **[Materials property prediction with uncertainty quantification: A benchmark study | Applied Physics Reviews | AIP Publishing](https://pubs.aip.org/aip/apr/article/10/2/021409/2892540/Materials-property-prediction-with-uncertainty)**  
aip.org

[891] **[The application of conformal prediction to the drug discovery process](http://oru.diva-portal.org/smash/record.jsf?pid=diva2:1440474)**  
diva-portal.org

[892] **[Uncertainty-Aware Hierarchical Gating - Emergent Mind](https://www.emergentmind.com/topics/uncertainty-aware-hierarchical-gating-strategy)**  
emergentmind.com

[893] **[NeurIPS Poster Valid Selection among Conformal Sets](https://neurips.cc/virtual/2025/poster/117970)**  
neurips.cc

[894] **[Multi-Class Classification With Reject Option and Performance Guarantees Using Conformal Prediction](https://cml.rhul.ac.uk/copa2024/presentations/MultiClassRO_PG_slides.pdf)**  
rhul.ac.uk

[895] **[Generative Conformal Prediction under Covariate Shift - Taylor & Francis Group - Figshare](https://tandf.figshare.com/articles/dataset/Generative_Conformal_Prediction_under_Covariate_Shift/32983922)**  
figshare.com

[896] **[Conformalized Graph Learning for Molecular ADMET Property Prediction and Reliable Uncertainty Quantification - PubMed](https://pubmed.ncbi.nlm.nih.gov/39571080/)**  
nih.gov

[897] **[Distribution-free uncertainty quantification for classification under label shift](https://www.semanticscholar.org/paper/Distribution-free-uncertainty-quantification-for-Podkopaev-Ramdas/828e7d9a06043f742010be77d873fb3a3b5935bb)**  
semanticscholar.org

[898] **[Conformal prediction theory explained | by Artem Ryasik | Low Code for Data Science](https://medium.com/low-code-for-advanced-data-science/conformal-prediction-theory-explained-14a35226df80)**  
medium.com

[899] **[Conformal Drug Property Prediction with Density Estimation under Covariate Shift - arXiv](https://arxiv.org/abs/2310.12033)**  
arxiv.org

[900] **[valeman/awesome-conformal-prediction - GitHub](https://github.com/valeman/awesome-conformal-prediction)**  
github.com

[901] **[Large scale comparison of QSAR and conformal prediction methods and their applications in drug discovery - PubMed](https://pubmed.ncbi.nlm.nih.gov/30631996/)**  
nih.gov

[902] **[Selective Classification via One-Sided Prediction](https://arxiv.org/pdf/2010.07853)**  
arxiv.org

[903] **[Conformal Prediction Under Generalized Covariate Shift with Posterior Drift](https://proceedings.mlr.press/v258/wang25l.html)**  
mlr.press

[904] **[Reliable Molecular Retrieval from Mass Spectra using Conformal Prediction | bioRxiv](https://www.biorxiv.org/content/10.64898/2026.03.12.711424.full)**  
biorxiv.org

[905] **[Uncertainty Quantification under Distribution Shifts - Carnegie Mellon University](https://kilthub.cmu.edu/articles/thesis/Uncertainty_Quantification_under_Distribution_Shifts/23902005)**  
cmu.edu

[906] **[Conformal Autoregressive Generation: Beam Search with Coverage Guarantees - AAAI Publications](https://ojs.aaai.org/index.php/AAAI/article/view/29062/30013)**  
aaai.org

[907] **[A Tutorial on Conformal Prediction - Journal of Machine Learning Research](https://jmlr.csail.mit.edu/papers/volume9/shafer08a/shafer08a.pdf)**  
mit.edu

[908] **[Target prediction, QSAR and conformal prediction - The ChEMBL-og](http://chembl.blogspot.com/2019/02/target-prediction-qsar-and-conformal_7.html)**  
blogspot.com

[909] **[Calibrated Selective Classification - arXiv](https://arxiv.org/html/2208.12084v2)**  
arxiv.org

[910] **[[2603.08907] Cross-Domain Uncertainty Quantification for Selective Prediction: A Comprehensive Bound Ablation with Transfer-Informed Betting - arXiv](https://arxiv.org/abs/2603.08907)**  
arxiv.org

[911] **[Conformal Prediction Under Covariate Shift - Emmanuel Candès](https://candes.su.domains/publications/downloads/WeightedCP.pdf)**  
su.domains

[912] **[[2103.03323] Distribution-free uncertainty quantification for ...](https://ar5iv.labs.arxiv.org/html/2103.03323)**  
arxiv.org

[913] **[Trading Coverage for Precision: Conformal Prediction with Limited False Discoveries](https://openreview.net/forum?id=Gx6Tvlm-hWW)**  
openreview.net

[914] **[Mastering Classical (Transductive) Conformal Prediction in Action | by Valeriy Manokhin, PhD, MBA, CQF](https://valeman.medium.com/how-to-use-full-transductive-conformal-prediction-7ed54dc6b72b)**  
medium.com

[915] **[[2001.07773] Missed opportunities in large scale comparison of QSAR and conformal prediction methods and their applications in drug discovery - arXiv](https://arxiv.org/abs/2001.07773)**  
arxiv.org

[916] **[Conjugate Conformal Prediction for Online Binary Classification](https://www.auai.org/uai2016/proceedings/papers/223.pdf)**  
auai.org

[917] **[Conformal Regression with Reject Option - Proceedings of Machine Learning Research](https://proceedings.mlr.press/v230/johansson24a.html)**  
mlr.press

[918] **[[2404.15018] Conformal Predictive Systems Under Covariate Shift - arXiv](https://arxiv.org/abs/2404.15018)**  
arxiv.org

[919] **[Zero-Shot Uncertainty Quantification - Emergent Mind](https://www.emergentmind.com/topics/zero-shot-uncertainty-quantification)**  
emergentmind.com

[920] **[Conformal Prediction Sets with Limited False Positives - Google Research](https://research.google/pubs/conformal-prediction-sets-with-limited-false-positives/)**  
research.google

[921] **[Transfer Conformal Predictive Inference for Regression](https://www.jmlr.org/papers/v27/24-1899.html)**  
jmlr.org

[922] **[Conformal Transformations for Symmetric Power Transformers - arXiv](https://arxiv.org/html/2503.03269v2)**  
arxiv.org

[923] **[Multi-Distribution Robust Conformal Prediction - arXiv](https://arxiv.org/html/2601.02998v2)**  
arxiv.org

[924] **[Physiobridge: Physiology-Constrained Self-Supervised Foundation Model for Cross-Device ECG–PPG Learning with Conformal Risk Control - PDXScholar - Portland State University](https://pdxscholar.library.pdx.edu/cgi/viewcontent.cgi?article=1885&context=ece_fac)**  
pdx.edu

[925] **[Weight Clipping for Robust Conformal Inference under Unbounded Covariate Shifts](https://openreview.net/forum?id=OPZ2f3MnrQ)**  
openreview.net

[926] **[Active Learning Using Conformal Predictors: Application to Image Classification | Request PDF - ResearchGate](https://www.researchgate.net/publication/233916308_Active_Learning_Using_Conformal_Predictors_Application_to_Image_Classification)**  
researchgate.net

[927] **[[PDF] Conformal Prediction Sets with Limited False Positives - Semantic Scholar](https://www.semanticscholar.org/paper/Conformal-Prediction-Sets-with-Limited-False-Fisch-Schuster/a32d3ab3362ecdab71a040b731e9a4e2eafe2c8a)**  
semanticscholar.org

[928] **[Organic Chemistry as a Catalyst for AI Innovation: Challenges, Methods, and Emerging Paradigms | Chemical Reviews - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.chemrev.5c01081)**  
acs.org

[929] **[CVPR Poster Conformal Prediction for Zero-Shot Models - The Computer Vision Foundation](https://cvpr.thecvf.com/virtual/2025/poster/33189)**  
thecvf.com

[930] **[Conformally Gated Surface Conducting Behaviors of Single-Walled Carbon Nanotube Thin-Film-Transistors - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC8234559/)**  
nih.gov

[931] **[CIDA3D: Conformal Inference aided unsupervised Domain Adaptation for 3D-Aware Classification | OpenReview](https://openreview.net/forum?id=XYFBmp08sP)**  
openreview.net

[932] **[Conformal Risk Control for Semantic Uncertainty Quantification in Computed Tomography - MICCAI Society](https://papers.miccai.org/miccai-2025/paper/2001_paper.pdf)**  
miccai.org

[933] **[NeurIPS Poster Non-exchangeable Conformal Prediction with Optimal Transport: Tackling Distribution Shift with Unlabeled Data](https://neurips.cc/virtual/2025/poster/118951)**  
neurips.cc

[934] **[Conformal novelty detection for multiple metabolic networks - PMC - NIH](https://pmc.ncbi.nlm.nih.gov/articles/PMC11569617/)**  
nih.gov

[935] **[Safety-Calibrated Out-of-Distribution Prediction via Contrastive Embeddings for Safety-Critical Systems - MDPI](https://www.mdpi.com/2079-9292/15/11/2408)**  
mdpi.com

[936] **[arXiv:2210.12496v4 [cs.LG] 12 Dec 2023](https://arxiv.org/pdf/2210.12496)**  
arxiv.org

[937] **[Conformal Prediction with Large Language Models for Multi-Choice Question Answering - arXiv](https://arxiv.org/pdf/2305.18404)**  
arxiv.org

[938] **[Area-Selective Atomic Layer Deposition: Conformal Coating, Subnanometer Thickness Control, and Smart Positioning | ACS Nano - ACS Publications](https://pubs.acs.org/doi/10.1021/acsnano.5b05249)**  
acs.org

[939] **[Calibrating Without Labels: Source-Free Conformal Prediction Using Pseudo-Labels - GitHub](https://raw.githubusercontent.com/mlresearch/v266/main/assets/angelman25a/angelman25a.pdf)**  
githubusercontent.com

[940] **[When Can Conformal Risk Control Certify LLM Outputs? Bounds, Impossibility, and Adaptation for Structured Generation - arXiv](https://arxiv.org/pdf/2606.29054)**  
arxiv.org

[941] **[Group-weighted conformal prediction - arXiv](https://arxiv.org/html/2401.17452v4)**  
arxiv.org

[942] **[Conformal Graph-level Out-of-distribution Detection with Adaptive Data Augmentation - Macquarie University](https://research-management.mq.edu.au/ws/portalfiles/portal/524311633/524098551.pdf)**  
mq.edu.au

[943] **[CoffeeBoost: Gradient Boosting Native Conformal Inference for Bayesian Optimization](https://ojs.aaai.org/index.php/AAAI/article/download/33982/36137)**  
aaai.org

[944] **[From Random Accuracy to Chemical Generalization: A Benchmark for Dye Optical-Property Prediction - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv.15005191)**  
chemrxiv.org

[945] **[Outsmarting Quantum Chemistry Through Transfer Learning - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv.6744440.v1)**  
chemrxiv.org

[946] **[Conformal Prediction for Zero-Shot Models - Julio Silva-Rodríguez](https://jusiro.github.io/projects/confot)**  
github.io

[947] **[US20140120678A1 - Methods for Selective and Conformal Epitaxy of Highly Doped Si-containing Materials for Three Dimensional Structures - Google Patents](https://patents.google.com/patent/US20140120678A1/en)**  
google.com

[948] **[Domain-Shift-Aware Conformal Prediction for Large Language Models - arXiv](https://arxiv.org/html/2510.05566v2)**  
arxiv.org

[949] **[Fast yet Safe: Early-Exiting with Risk Control - arXiv](https://arxiv.org/html/2405.20915v2)**  
arxiv.org

[950] **[Exploring Adaptive and Weighted Conformal Prediction Methods in the Presence of Covariate Shift | by Peter Tettey Yamak | Dev Genius](https://blog.devgenius.io/exploring-adaptive-and-weighted-conformal-prediction-methods-in-the-presence-of-covariate-shift-38ca04029292)**  
devgenius.io

[951] **[Data Centric Methods for Machine Learning on QSAR Data - DiVA portal](https://www.diva-portal.org/smash/get/diva2:1875142/FULLTEXT01.pdf)**  
diva-portal.org

[952] **[Multimodal out-of-distribution individual uncertainty quantification enhances binding affinity prediction for polypharmacology - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12798713/)**  
nih.gov

[953] **[Batch mode active learning for mitotic phenotypes using conformal prediction](https://proceedings.mlr.press/v128/corrigan20a/corrigan20a.pdf)**  
mlr.press

[954] **[Bayesian Optimization with Conformal Prediction Sets - Proceedings of Machine Learning Research](https://proceedings.mlr.press/v206/stanton23a/stanton23a.pdf)**  
mlr.press

[955] **[Convergence of high throughput experimentation and machine learning to rapidly advance application-specific polymer development](https://pubs.rsc.org/en/content/articlelanding/2026/lp/d5lp00380f)**  
rsc.org

[956] **[[2502.17744] Conformal Prediction Under Generalized Covariate Shift with Posterior Drift - arXiv](https://arxiv.org/abs/2502.17744)**  
arxiv.org

[957] **[Scalable Conformal Electronics Based on Roll-to-Roll Exfoliated van der Waals Semiconductors | ACS Nano - ACS Publications](https://pubs.acs.org/doi/10.1021/acsnano.6c04448)**  
acs.org

[958] **[Reliable Learning for Safe Autonomy with Conformal Prediction](https://safeandtrustedai.org/project/reliable-learning-for-safe-autonomy-with-conformal-prediction/)**  
safeandtrustedai.org

[959] **[Conformal prediction with local weights: randomization enables robust guarantees - Oxford Academic](https://academic.oup.com/jrsssb/article/87/2/549/7889096)**  
oup.com

[960] **[Conformal Anomaly Detection of Trajectories with a Multi-class Hierarchy - ResearchGate](https://www.researchgate.net/publication/312828847_Conformal_Anomaly_Detection_of_Trajectories_with_a_Multi-class_Hierarchy)**  
researchgate.net

[961] **[Predicting Endocrine Disruption Using Conformal Prediction – A ...](https://uu.diva-portal.org/smash/get/diva2:1759391/FULLTEXT01.pdf)**  
diva-portal.org

[962] **[Bayesian semi-supervised learning for uncertainty-calibrated prediction of molecular properties and active learning - University of Cambridge](https://www.repository.cam.ac.uk/bitstreams/fdf678ba-adc5-472e-9979-551f132cd04e/download)**  
cam.ac.uk

[963] **[EP4097725A1 - Conformal inference for optimization - Google Patents](https://patents.google.com/patent/EP4097725A1/ko)**  
google.com

[964] **[Combination of Conformal Predictors for Classification - Proceedings of Machine Learning Research](https://proceedings.mlr.press/v60/toccaceli17a/toccaceli17a.pdf)**  
mlr.press

[965] **[ProvMind: Provenance-grounded reasoning for materials synthesis - arXiv](https://arxiv.org/html/2605.28487v1)**  
arxiv.org

[966] **[Externally Controlled Trials: A Review of Design and Borrowing Through a Causal Lens](https://arxiv.org/html/2605.03282v1)**  
arxiv.org

[967] **[Daily TMLR digest for Oct 09, 2025 - Google Groups](https://groups.google.com/g/tmlr-announce-daily/c/VAfK8L2wzHI)**  
google.com

[968] **[Spectral Conformal Risk Control: Distribution-Free Tail Guarantees via Bayesian Quadrature](https://openaccess.thecvf.com/content/CVPR2026/papers/Esfeh_Spectral_Conformal_Risk_Control_Distribution-Free_Tail_Guarantees_via_Bayesian_Quadrature_CVPR_2026_paper.pdf)**  
thecvf.com

[969] **[Tutorial: Quantifying Predictive Uncertainty Without Distributional Assumptions Via Conformal Prediction](https://cml.rhul.ac.uk/copa2022/presentations/conformal_UAI_tutorial_2.pdf)**  
rhul.ac.uk

[970] **[Certified Domain-Consistency for Multi-Domain Retrieval: Label-Free Per-Domain Contamination Control with Conformal Risk Guarantees - arXiv](https://arxiv.org/html/2607.14157v1)**  
arxiv.org

[971] **[Transfer Conformal Predictive Inference for Regression - Journal of Machine Learning Research](https://www.jmlr.org/papers/volume27/24-1899/24-1899.pdf)**  
jmlr.org

[972] **[Conformal Active Learning Aided Screening of Ligand Protected Cu ...](https://www.researchgate.net/publication/384124723_Conformal_Active_Learning_Aided_Screening_of_Ligand_Protected_Cu-Nanoclusters_for_CO2_Reduction_Reactions)**  
researchgate.net

[973] **[Look Again Before You Abstain: Budgeted Conformal Evidence Acquisition for Reliable Vision-Language Models - arXiv](https://arxiv.org/html/2606.16667v1)**  
arxiv.org

[974] **[[2605.00432] Optimal Spatio-Temporal Decoupling for Bayesian Conformal Prediction](https://arxiv.org/abs/2605.00432)**  
arxiv.org

[975] **[[PDF] Learning to Defer to Multiple Experts: Consistent Surrogate ...](https://www.semanticscholar.org/paper/25795c8dff18a2dc5c742805587e33618354444f)**  
semanticscholar.org

[976] **[A Conformal Risk Control Framework for Granular Word Assessment and Uncertainty Calibration of CLIPScore Quality Estimates - ACL Anthology](https://aclanthology.org/2025.findings-acl.638.pdf)**  
aclanthology.org

[977] **[Ensembles based on Conformal Instance Transfer - Proceedings of Machine Learning Research](https://proceedings.mlr.press/v105/zhou19a/zhou19a.pdf)**  
mlr.press

[978] **[Machine-Learning-Driven Molecular Design and Structure–Property–Performance Relationships in Pharmaceutical Chemistry - MDPI](https://www.mdpi.com/1420-3049/31/12/2162)**  
mdpi.com

[979] **[Using Conformal Prediction to Prioritize Compound Synthesis in Drug Discovery - Proceedings of Machine Learning Research](https://proceedings.mlr.press/v60/ahlberg17a/ahlberg17a.pdf)**  
mlr.press

[980] **[Hybrid Control Trials - Emergent Mind](https://www.emergentmind.com/topics/hybrid-control-trials-hcts)**  
emergentmind.com

[981] **[Vocabulary-Aware Conformal Prediction (VACP) - Emergent Mind](https://www.emergentmind.com/topics/vocabulary-aware-conformal-prediction-vacp)**  
emergentmind.com

[982] **[LATA: Laplacian-Assisted Transductive Adaptation for Conformal Uncertainty in Medical VLMs - CVF Open Access](https://openaccess.thecvf.com/content/CVPR2026/papers/Bozorgtabar_LATA_Laplacian-Assisted_Transductive_Adaptation_for_Conformal_Uncertainty_in_Medical_VLMs_CVPR_2026_paper.pdf)**  
thecvf.com

[983] **[HazChemNet: A Deep Learning Model for Hazardous Chemical Prediction - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12524297/)**  
nih.gov

[984] **[[2602.04364] Anytime-Valid Conformal Risk Control - arXiv](https://arxiv.org/abs/2602.04364)**  
arxiv.org

[985] **[Transductive conformal inference with adaptive scores - Etienne Roquain](https://etienneroquain-81.webself.net/file/si1359471/download/GBR2024_published-fi36250005.pdf)**  
webself.net

[986] **[ICML Poster Robust Conformal Outlier Detection under Contaminated Reference Data](https://icml.cc/virtual/2025/poster/43852)**  
icml.cc

[987] **[Conformal Region Classification with Instance-Transfer Boosting - World Scientific Publishing](https://www.worldscientific.com/doi/pdf/10.1142/S0218213015600027?download=true)**  
worldscientific.com

[988] **[Active deep kernel learning of molecular properties from structural embeddings - AIP Publishing](https://pubs.aip.org/aip/aml/article/3/4/046103/3368864/Active-deep-kernel-learning-of-molecular)**  
aip.org

[989] **[A Distribution-Free Test of Covariate Shift Using Conformal Prediction - ResearchGate](https://www.researchgate.net/publication/344662579_A_Distribution-Free_Test_of_Covariate_Shift_Using_Conformal_Prediction)**  
researchgate.net

[990] **[Conformal Risk Control | OpenReview](https://openreview.net/forum?id=33XGfHLtZg)**  
openreview.net

[991] **[Conformal Policy Control - arXiv](https://arxiv.org/html/2603.02196v2)**  
arxiv.org

[992] **[NeurIPS Poster Backward Conformal Prediction](https://neurips.cc/virtual/2025/poster/120178)**  
neurips.cc

[993] **[[PDF] EvoluNet: Advancing Dynamic Non-IID Transfer Learning on ...](https://www.semanticscholar.org/paper/013b8517aa67d317992bae339dcfe705f12a8758)**  
semanticscholar.org

[994] **[Loving, hating, and sometimes misinterpreting conformal prediction for medical decisions](https://statmodeling.stat.columbia.edu/2024/06/14/loving-hating-and-sometimes-misinterpreting-conformal-prediction-for-medical-decisions/)**  
columbia.edu

[995] **[ChemSpaceAL: An Efficient Active Learning Methodology Applied to Protein-Specific Molecular Generation | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.3c01456)**  
acs.org

[996] **[(PDF) Enhancing Statistical Validity and Power in Hybrid Controlled Trials: A Randomization Inference Approach with Conformal Selective Borrowing - ResearchGate](https://www.researchgate.net/publication/384938375_Enhancing_Statistical_Validity_and_Power_in_Hybrid_Controlled_Trials_A_Randomization_Inference_Approach_with_Conformal_Selective_Borrowing)**  
researchgate.net

[997] **[CP-Router: An Uncertainty-Aware Router Between LLM and LRM](https://ojs.aaai.org/index.php/AAAI/article/view/40589/44550)**  
aaai.org

[998] **[Conformal Risk Training: End-to-End Optimization of Conformal Risk Control - NIPS](https://papers.nips.cc/paper_files/paper/2025/file/6559542f75b4452ebaaf82094c7defb7-Paper-Conference.pdf)**  
nips.cc

[999] **[Conformalized Lee Inference: Distribution-Free Individual Treatment Effect Intervals under Monotone Sample Selection - arXiv](https://arxiv.org/html/2607.02898v1)**  
arxiv.org

[1000] **[Negative transfer rate and conformal coverage degradation. - ResearchGate](https://www.researchgate.net/figure/Negative-transfer-rate-and-conformal-coverage-degradation_tbl8_408509952)**  
researchgate.net

[1001] **[Chapter 5: Concepts and Applications of Conformal Prediction in Computational Drug Discovery - Books](https://books.rsc.org/books/edited-volume/1266/chapter/917145/Concepts-and-Applications-of-Conformal-Prediction)**  
rsc.org

[1002] **[A survey of active learning in materials science: Data-driven paradigm for accelerating the research pipeline - arXiv](https://arxiv.org/html/2601.06971v1)**  
arxiv.org

[1003] **[Enhancing Cost Efficiency in Active Learning with Candidate Set Query - Yeho Gwon](https://yehogwon.github.io/csq-al/)**  
github.io

[1004] **[[2502.06209] Enhancing Cost Efficiency in Active Learning with Candidate Set Query - arXiv](https://arxiv.org/abs/2502.06209)**  
arxiv.org

[1005] **[Reverse Conformal Approach for On-line Experimental Design](https://proceedings.mlr.press/v60/nouretdinov17a.html)**  
mlr.press

[1006] **[Conformal Cross-Modal Active Learning - CVF Open Access](https://openaccess.thecvf.com/content/CVPR2026F/papers/Nguyen_Conformal_Cross-Modal_Active_Learning_CVPRF_2026_paper.pdf)**  
thecvf.com

[1007] **[Evaluating the Utility of Conformal Prediction Sets for AI-Advised Image Labeling - Mu Collective](https://mucollective.northwestern.edu/files/2024-conformal.pdf)**  
northwestern.edu

[1008] **[A Top Surface Imaging Method Using Area Selective ALD on Chemically Amplified Polymer Photoresist Films](https://repository.gatech.edu/bitstreams/7a76a794-271f-4d93-87ca-7aa6a75c4096/download)**  
gatech.edu

[1009] **[Individualised Counterfactual Examples Using Conformal Prediction Intervals - arXiv](https://arxiv.org/html/2505.22326v1)**  
arxiv.org

[1010] **[Conformal Prediction Under Generalized Covariate Shift with Posterior Drift - GitHub](https://raw.githubusercontent.com/mlresearch/v258/main/assets/wang25l/wang25l.pdf)**  
githubusercontent.com

[1011] **[Understanding Selectivity Loss Mechanisms in Selective Material Deposition by Area Deactivation on 10 nm Cu/SiO2 Patterns - ACS Publications](https://pubs.acs.org/doi/10.1021/acsaelm.1c01348)**  
acs.org

[1012] **[Robust Estimation and Inference with Selective Borrowing in Hybrid Controlled Trials: A Tutorial with SelectiveIntegrative and intFRT - arXiv](https://arxiv.org/html/2607.00350v1)**  
arxiv.org

[1013] **[Improving Reaction Yield Prediction with Chemical Atom-Level Reaction Learning](https://www.researchgate.net/publication/397041879_Improving_Reaction_Yield_Prediction_with_Chemical_Atom-Level_Reaction_Learning)**  
researchgate.net

[1014] **[Conformal Non-Coverage Risk Control (CNCRC): Risk-Centric Guarantees for Predictive Safety in High-Stakes Settings | OpenReview](https://openreview.net/forum?id=Z7nJXxBjRO)**  
openreview.net

[1015] **[Conformal Prediction Assessment: A Framework for Conditional Coverage Evaluation and Selection - arXiv](https://arxiv.org/html/2603.27189v1)**  
arxiv.org

[1016] **[Conformal Prediction Sets Can Cause Disparate Impact - OpenReview](https://openreview.net/forum?id=fZK6AQXlUU)**  
openreview.net

[1017] **[Enhancing Cost Efficiency in Active Learning with Candidate Set Query - OpenReview](https://openreview.net/forum?id=LhHxl30xQ1)**  
openreview.net

[1018] **[Ultrathin covalent organic overlayers on metal nanocrystals for highly selective plasmonic photocatalysis - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10667221/)**  
nih.gov

[1019] **[GitHub - ke-zhu/intFRT: Fisher Randomization Test and Conformal Selective Borrowing in Hybrid Controlled Trials](https://github.com/ke-zhu/intFRT)**  
github.com

[1020] **[Improved Uncertainty Estimation of Graph Neural Network Potentials ...](https://arxiv.org/html/2407.10844v2)**  
arxiv.org

[1021] **[Conformal Prediction with Orange - Journal of Statistical Software](https://www.jstatsoft.org/article/view/v098i07/1423)**  
jstatsoft.org

[1022] **[Robust Conformal Prediction Using Privileged Information - NIPS](https://proceedings.neurips.cc/paper_files/paper/2024/file/d5ae1c5167be330b90f4c0a1eed7f8f0-Paper-Conference.pdf)**  
neurips.cc

[1023] **[Multi-Source Conformal Inference Under Distribution Shift - GitHub](https://raw.githubusercontent.com/mlresearch/v235/main/assets/liu24ag/liu24ag.pdf)**  
githubusercontent.com

[1024] **[Conformal Prediction Under Generalized Covariate Shift with ...](https://www.researchgate.net/publication/389351191_Conformal_Prediction_Under_Generalized_Covariate_Shift_with_Posterior_Drift)**  
researchgate.net

[1025] **[Stimuli-responsive temporary adhesives: enabling debonding on demand through strategic molecular design](https://pubs.rsc.org/en/content/articlehtml/2021/sc/d1sc03426j)**  
rsc.org

[1026] **[Toward Spatial Control of Reaction Selectivity on Photocatalysts Using Area-Selective Atomic Layer Deposition on the Model Dual Site Electrocatalyst Platform - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11673572/)**  
nih.gov

[1027] **[Using Conformal Prediction in Drug Discovery - DiVA Portal](https://www.diva-portal.org/smash/get/diva2:1514590/FULLTEXT01.pdf)**  
diva-portal.org

[1028] **[Measuring Models' Uncertainty: Conformal Prediction | by Léo Dreyfus-Schmidt | data from the trenches | Medium](https://medium.com/data-from-the-trenches/measuring-models-uncertainty-with-conformal-prediction-f6aa8debb50e)**  
medium.com

[1029] **[Conformalized Lee Inference: Distribution-Free Individual Treatment Effect Intervals under Monotone Sample Selection - arXiv](https://arxiv.org/pdf/2607.02898)**  
arxiv.org

[1030] **[Experimental Design in the AI Era | Eni digiTALKS - Medium](https://medium.com/eni-digitalks/experimental-design-in-the-ai-era-98f7cb095635)**  
medium.com

[1031] **[CoPAL: Conformal Prediction for Active Learning with Application to Remaining Useful Life Estimation in Predictive Maintenance - GitHub](https://raw.githubusercontent.com/mlresearch/v230/main/assets/kharazian24a/kharazian24a.pdf)**  
githubusercontent.com

[1032] **[Direct Writing of Functional Layer by Selective Laser Sintering of Nanoparticles for Emerging Applications: A Review - MDPI](https://www.mdpi.com/1996-1944/15/17/6006)**  
mdpi.com

[1033] **[Track: Poster Session 3 Pavilion 3 - ICLR 2026](https://iclr.cc/virtual/2026/session/10021365)**  
iclr.cc

[1034] **[(PDF) No Need for "Learning" to Defer? A Training Free Deferral Framework to Multiple Experts through Conformal Prediction - ResearchGate](https://www.researchgate.net/publication/395541278_No_Need_for_Learning_to_Defer_A_Training_Free_Deferral_Framework_to_Multiple_Experts_through_Conformal_Prediction)**  
researchgate.net

[1035] **[Transductive conformal inference with adaptive scores - Proceedings of Machine Learning Research](https://proceedings.mlr.press/v238/gazin24a/gazin24a.pdf)**  
mlr.press

[1036] **[Evaluating the Effectiveness of Active Learning Methods in Drug Repurposing - DiVA portal](https://www.diva-portal.org/smash/get/diva2:1698759/FULLTEXT01.pdf)**  
diva-portal.org

[1037] **[Cross-disciplinary perspectives on the potential for artificial intelligence across chemistry](https://pubs.rsc.org/en/content/articlelanding/2025/cs/d5cs00146c)**  
rsc.org

[1038] **[Generalization and Informativeness of Weighted Conformal Risk Control Under Covariate Shift - arXiv](https://arxiv.org/html/2501.11413v1)**  
arxiv.org

[1039] **[Conformal prediction under feedback covariate shift for biomolecular design - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC9618043/)**  
nih.gov

[1040] **[Conformal Risk-Controlled Routing for Large Language Model | OpenReview](https://openreview.net/forum?id=lLR61sHcS5)**  
openreview.net

[1041] **[Extrapolation Techniques in Database Construction for Machine-Learning Potentials: Achieving Subchemical Accuracy in Sampling Conformal Funnels in Catalytic Processes | Journal of Chemical Theory and Computation - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jctc.5c00860?ai=557&mi=qj3l5d&af=R)**  
acs.org

[1042] **[Selection by Prediction with Conformal p-values - Journal of Machine Learning Research](https://www.jmlr.org/papers/volume24/22-1176/22-1176.pdf)**  
jmlr.org

[1043] **[Conformal-in-the-Loop for Learning with Imbalanced Noisy Data - arXiv](https://arxiv.org/html/2411.02281v1)**  
arxiv.org

[1044] **[Generalization and Informativeness of Weighted Conformal Risk Control Under Covariate Shift - arXiv](https://arxiv.org/pdf/2501.11413)**  
arxiv.org

[1045] **[RouteNLP: Closed-Loop LLM Routing with Conformal Cascading and Distillation Co-Optimization - arXiv](https://arxiv.org/pdf/2604.23577)**  
arxiv.org

[1046] **[(PDF) Uncertainty-driven dynamics for active learning of interatomic potentials](https://www.researchgate.net/publication/369033998_Uncertainty-driven_dynamics_for_active_learning_of_interatomic_potentials)**  
researchgate.net

[1047] **[Conformal efficiency as a metric for comparative model assessment befitting federated learning - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv-2022-j3xfk)**  
chemrxiv.org

[1048] **[Track: Poster Session 6 - ICLR 2026](https://iclr.cc/virtual/2025/session/31976)**  
iclr.cc

[1049] **[Conformal Prediction Sets with Limited False Positives - Proceedings of Machine Learning Research](https://proceedings.mlr.press/v162/fisch22a/fisch22a.pdf)**  
mlr.press

[1050] **[Deep Learning-Assisted Spectrum–Structure Correlation: State-of-the-Art and Perspectives | Analytical Chemistry - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.analchem.4c01639)**  
acs.org

[1051] **[Contrastive Conformal Sets - arXiv](https://arxiv.org/pdf/2603.26261)**  
arxiv.org

[1052] **[Generalization and Informativeness of Weighted Conformal Risk ...](https://www.alphaxiv.org/overview/2501.11413)**  
alphaxiv.org

[1053] **[Transformer vs. Mixture of Experts in LLMs - by Avi Chawla - Daily Dose of Data Science](https://blog.dailydoseofds.com/p/transformer-vs-mixture-of-experts)**  
dailydoseofds.com

[1054] **[Characterizing Uncertainty in Machine Learning for Chemistry | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.3c00373)**  
acs.org

[1055] **[Tackling the widespread and critical impact of batch effects in high-throughput data - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC3880143/)**  
nih.gov

[1056] **[Prevention of Leakage in Machine Learning Prediction for Polymer Composite Properties | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.3c01894)**  
acs.org

[1057] **[Out-of-distribution generalisation and scaffold splitting in molecular property prediction | Oxford Protein Informatics Group](https://www.blopig.com/blog/2021/06/out-of-distribution-generalisation-and-scaffold-splitting-in-molecular-property-prediction/)**  
blopig.com

[1058] **[Machine Learning in Drug Discovery: The Definitive Technical and Strategic Guide for Pharma IP Teams, R&D Leaders, and Institutional Investors - DrugPatentWatch](https://www.drugpatentwatch.com/blog/the-application-of-machine-learning-in-drug-discovery-revolutionizing-pharmaceutical-research/)**  
drugpatentwatch.com

[1059] **[Out of distribution learning in bioinformatics: advancements and challenges - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12203079/)**  
nih.gov

[1060] **[Transfer learning enables identification of multiple types of RNA modifications using nanopore direct RNA sequencing - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11094168/)**  
nih.gov

[1061] **[Importance inversion transfer identifies shared principles for cross-domain learning - arXiv](https://arxiv.org/html/2602.09116v2)**  
arxiv.org

[1062] **[Spectral deep learning for prediction and prospective validation of functional groups](https://pubs.rsc.org/en/content/articlelanding/2020/sc/c9sc06240h)**  
rsc.org

[1063] **[Machine Learning Is Not Just for Prediction: Its Role as an Exploratory Analytical Tool in Medicine - J-Stage](https://www.jstage.jst.go.jp/article/avd/19/1/19_ra.26-00055/_html/-char/ja)**  
jst.go.jp

[1064] **[Foundation Models for Drug Discovery: A Systematic Review of Molecular Language, Representation Learning, Target Prediction, Generative Design, and Translational Risk - International Journal of Pharmaceutical and Phytopharmacological Research](https://eijppr.com/article/foundation-models-for-drug-discovery-a-systematic-review-of-molecular-language-representation-lear-cwxxxzc1odlct6l)**  
eijppr.com

[1065] **[What Can We Do About Exploratory Analyses in Clinical Trials? - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC4674334/)**  
nih.gov

[1066] **[Detection and imaging of chemicals and hidden explosives using terahertz time-domain spectroscopy and deep learning | Request PDF - ResearchGate](https://www.researchgate.net/publication/398357723_Detection_and_imaging_of_chemicals_and_hidden_explosives_using_terahertz_time-domain_spectroscopy_and_deep_learning)**  
researchgate.net

[1067] **[Thinking points for effective batch correction on biomedical data - Oxford Academic](https://academic.oup.com/bib/article/25/6/bbae515/7820079)**  
oup.com

[1068] **[Leakage and the Reproducibility Crisis in ML-based Science](https://reproducible.cs.princeton.edu/)**  
princeton.edu

[1069] **[Some Thoughts on Splitting Chemical Datasets - Practical Cheminformatics](http://practicalcheminformatics.blogspot.com/2024/11/some-thoughts-on-splitting-chemical.html)**  
blogspot.com

[1070] **[Generative AI in Drug Discovery Explained | Danaher Life Sciences](https://lifesciences.danaher.com/us/en/library/generative-ai-drug-discovery-overview.html)**  
danaher.com

[1071] **[Exploring Chemical Space with Score-based Out-of-distribution Generation - Proceedings of Machine Learning Research](https://proceedings.mlr.press/v202/lee23f/lee23f.pdf)**  
mlr.press

[1072] **[Transfer learning applied in predicting small molecule bioactivity | bioRxiv](https://www.biorxiv.org/content/10.1101/2025.01.09.632140.full)**  
biorxiv.org

[1073] **[(PDF) Transfer learning across different chemical domains: virtual screening of organic materials with deep learning models pretrained on small molecule and chemical reaction data - ResearchGate](https://www.researchgate.net/publication/382691653_Transfer_learning_across_different_chemical_domains_virtual_screening_of_organic_materials_with_deep_learning_models_pretrained_on_small_molecule_and_chemical_reaction_data)**  
researchgate.net

[1074] **[Position: Why We Must Rethink Empirical Research in Machine Learning - arXiv](https://arxiv.org/html/2405.02200v2)**  
arxiv.org

[1075] **[Full article: Deep generative molecular design and its value in modern drug discovery](https://www.tandfonline.com/doi/full/10.1080/17460441.2026.2636192)**  
tandfonline.com

[1076] **[AI in drug discovery: From target identification to clinical translation](https://www.drugdiscoverynews.com/ai-in-drug-discovery-from-target-identification-to-clinical-translation-17335)**  
drugdiscoverynews.com

[1077] **[CODI: Enhancing machine learning-based molecular profiling through contextual out-of-distribution integration | PNAS Nexus | Oxford Academic](https://academic.oup.com/pnasnexus/article/3/10/pgae449/7823116)**  
oup.com

[1078] **[EXPLORATION OF CHEMICAL SPACE BY MACHINE LEARNING](https://back.skoltech.ru/storage/app/media/defenses/2020/sergey-sosnin/revised/thesis-2.pdf)**  
skoltech.ru

[1079] **[Digital Alchemy: The Rise of Machine and Deep Learning in Small-Molecule Drug Discovery](https://www.mdpi.com/1422-0067/26/14/6807)**  
mdpi.com

[1080] **[BatMan: Mitigating Batch Effects Via Stratification for Survival Outcome Prediction | JCO Clinical Cancer Informatics - ASCO Publications](https://ascopubs.org/doi/10.1200/CCI.22.00138)**  
ascopubs.org

[1081] **[What is Data Leakage in Machine Learning? - IBM](https://www.ibm.com/think/topics/data-leakage-machine-learning)**  
ibm.com

[1082] **[A systematic study of key elements underlying molecular property prediction - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10575948/)**  
nih.gov

[1083] **[Data equity for sustainable chemistry: an informatics governance framework for responsible chemical innovation and environmental justice - Frontiers](https://www.frontiersin.org/journals/environmental-science/articles/10.3389/fenvs.2026.1805980/full)**  
frontiersin.org

[1084] **[A Machine Learning Model to Predict Drug Transfer Across the Human Placenta Barrier](https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2021.714678/full)**  
frontiersin.org

[1085] **[virtual screening of organic materials with deep learning models pretrained on small molecule and chemical reaction data - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11290278/)**  
nih.gov

[1086] **[molecularinformatics/Computational-ADME - GitHub](https://github.com/molecularinformatics/Computational-ADME)**  
github.com

[1087] **[Master's Thesis Confirmatory studies in methodological statistical research: concept and illustration - Open Access LMU](https://epub.ub.uni-muenchen.de/94460/1/MA_Lange_Felix_Julian_BEARB.pdf)**  
uni-muenchen.de

[1088] **[(PDF) Mechanism-Aware Foundation Models in Drug Discovery: From Molecular Representation to Biological Translation - ResearchGate](https://www.researchgate.net/publication/401210396_Mechanism-Aware_Foundation_Models_in_Drug_Discovery_From_Molecular_Representation_to_Biological_Translation)**  
researchgate.net

[1089] **[Cage-to-Code: From Animal Experimentation to AI-driven Drug Discovery](https://www.xiahepublishing.com/2572-5505/JERP-2025-00058)**  
xiahepublishing.com

[1090] **[TxPert: Leveraging Biochemical Relationships for Out-of-Distribution Transcriptomic Perturbation Prediction - Valence Labs](https://www.valencelabs.com/publications/txpert-leveraging-biochemicalrelationships-for-out-of-distributiontranscriptomic-perturbation-prediction/)**  
valencelabs.com

[1091] **[How to prevent Data Leakage problem: Illustrated with Practical Examples - Medium](https://medium.com/codex/how-to-prevent-data-leakage-problem-illustrated-with-practical-examples-10604e83c4ab)**  
medium.com

[1092] **[The problem(s) with scaffold splits, part 1 – RDKit blog - GitHub Pages](https://greglandrum.github.io/rdkit-blog/posts/2024-05-31-scaffold-splits-and-murcko-scaffolds1.html)**  
github.io

[1093] **[The Evolution of Data-Driven Modeling in Organic Chemistry - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC8554870/)**  
nih.gov

[1094] **[HEDGEHOG: Hierarchical Evaluation of Drug Generators Through Rigorous Filtration - arXiv](https://arxiv.org/html/2607.13155v1)**  
arxiv.org

[1095] **[MAINFRAME: A Global Open Science Machine Learning Network for Drug Discovery](https://aircheck.ai/mainframe)**  
aircheck.ai

[1096] **[Mastering Exploratory Data Analysis in Biomedical Science: A Comprehensive Guide with Python and R - Medium](https://medium.com/analytics-mastery/mastering-exploratory-data-analysis-in-biomedical-science-a-comprehensive-guide-with-python-and-r-1b25ca2adfc8)**  
medium.com

[1097] **[Artificial Intelligence and Computational Modeling in Natural Product Drug Discovery](https://premierscience.com/pjs-26-1622/)**  
premierscience.com

[1098] **[Drug Discovery in the Era of Artificial Intelligence: From Target Identification to Clinical Trials](https://www.preprints.org/manuscript/202606.0091)**  
preprints.org

[1099] **[All That Glitters Is Not Gold: Importance of Rigorous Evaluation of Proteochemometric Models - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12529762/)**  
nih.gov

[1100] **[Using Machine Learning for Green Substitution of Industrial Chemicals: Integrating Functionality, Hazard, and Life Cycle Impact - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.chemrev.5c00828)**  
acs.org

[1101] **[Tackling the widespread and critical impact of batch effects in high-throughput data](https://rscharpf.github.io/files/leek_et_al_ngr_2010.pdf)**  
github.io

[1102] **[How to avoid machine learning pitfalls: a guide for academic researchers - arXiv](https://arxiv.org/html/2108.02497v5)**  
arxiv.org

[1103] **[Benchmarking Molecular Property Prediction at Scale - Hunter Heidenreich](https://hunterheidenreich.com/notes/chemistry/molecular-design/property-prediction/systematic-study-molecular-property-prediction/)**  
hunterheidenreich.com

[1104] **[Machine Learning in Chemistry: Innovation & Patent Insight - Researchwire](https://www.researchwire.in/resources/machine-learning-chemistry-patents-innovation/)**  
researchwire.in

[1105] **[Real-World Molecular Out-Of-Distribution: Specification and Investigation - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv-2023-q11q4)**  
chemrxiv.org

[1106] **[Identifying molecular recognition features in intrinsically disordered regions of proteins by transfer learning - Oxford Academic](https://academic.oup.com/bioinformatics/article/36/4/1107/5560335)**  
oup.com

[1107] **[Different Worlds Confirmatory Versus Exploratory Research - ResearchGate](https://www.researchgate.net/publication/340358013_Different_worlds_Confirmatory_versus_exploratory_research)**  
researchgate.net

[1108] **[Generative Molecular Design with Steerable and Granular Synthesizability Control - arXiv](https://arxiv.org/html/2505.08774v2)**  
arxiv.org

[1109] **[Drug Discovery in the Age of Artificial Intelligence: Transformative Target-Based Approaches](https://pmc.ncbi.nlm.nih.gov/articles/PMC11594879/)**  
nih.gov

[1110] **[Quantifying Covariate Shift and Improving Electromyography Driven Gesture Recognition with Calibration and Sample Selection](https://ras.papercept.net/images/temp/AIM/files/0257.pdf)**  
papercept.net

[1111] **[Characterizing Uncertainty in Machine Learning for Chemistry - PMC - NIH](https://pmc.ncbi.nlm.nih.gov/articles/PMC10336963/)**  
nih.gov

[1112] **[Laboratory Data as a Potential Source of Bias in Healthcare Artificial Intelligence and Machine Learning Models - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11609702/)**  
nih.gov

[1113] **[SynRXN: An Open Benchmark and Curated Dataset for Computational Reaction Modeling - arXiv](https://arxiv.org/html/2601.01943v1)**  
arxiv.org

[1114] **[Genetic-to-Chemical Perturbation Transfer Learning Through Unified Multimodal Molecular Representations | bioRxiv](https://www.biorxiv.org/content/10.1101/2025.02.02.635055v2.full-text)**  
biorxiv.org

[1115] **[FML-bench: Benchmarking Machine Learning Agents for Scientific Research - arXiv](https://arxiv.org/html/2510.10472v2)**  
arxiv.org

[1116] **[BOOM: Benchmarking Out-Of-distribution Molecular Property Predictions of Machine Learning Models - arXiv](https://arxiv.org/html/2505.01912v1)**  
arxiv.org

[1117] **[Aitomistic Courses – Upgrade Your Skills in Aitomistic Simulations at Your Pace](https://aitomistic.com/en/sub/course)**  
aitomistic.com

[1118] **[Machine Learning in Materials Science: Data-Driven Discovery and Functional Applications](https://www.mdpi.com/2673-8392/6/7/150)**  
mdpi.com

[1119] **[Machine Learning in Materials Discovery: Confirmed Predictions and Their Underlying Approaches - NSF PAR](https://par.nsf.gov/servlets/purl/10292820)**  
nsf.gov

[1120] **[Two Axes of LLM Abstention: Answer Correctness and Question Answerability - arXiv](https://arxiv.org/pdf/2607.08456)**  
arxiv.org

[1121] **[Chembot: A Machine Learning Approach to Selective Configuration Interaction](https://www.researchgate.net/publication/352393051_Chembot_A_Machine_Learning_Approach_to_Selective_Configuration_Interaction)**  
researchgate.net

[1122] **[Achieving a scalable machine learning workflow for crystal structure discovery with experimental validation - Royal Society of Chemistry journals](https://pubs.rsc.org/en/content/articlehtml/2026/dd/d6dd00132g)**  
rsc.org

[1123] **[Instrument Bias Correction With Machine Learning Algorithms: Application to Field-Portable Mass Spectrometry - Frontiers](https://www.frontiersin.org/journals/earth-science/articles/10.3389/feart.2020.537028/full)**  
frontiersin.org

[1124] **[Machine learning the ropes: principles, applications and directions in synthetic chemistry](https://pubs.rsc.org/en/content/articlelanding/2020/cs/c9cs00786e)**  
rsc.org

[1125] **[Machine learning-driven high-throughput screening of electrocatalysts and electrolytes for electrochemical surfaces and interfaces | Chemical Communications | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlelanding/2026/cc/d6cc01112h)**  
rsc.org

[1126] **[Computational Medicinal Chemistry School](https://www.compmedchem.org/)**  
compmedchem.org

[1127] **[Big data and machine learning for materials science - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC8054236/)**  
nih.gov

[1128] **[Prospective Validation of Machine Learning Algorithms for Absorption, Distribution, Metabolism, and Excretion Prediction: An Industrial Perspective | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/abs/10.1021/acs.jcim.3c00160)**  
acs.org

[1129] **[Autonomous mobile robots for exploratory synthetic chemistry - PMC - NIH](https://pmc.ncbi.nlm.nih.gov/articles/PMC11602721/)**  
nih.gov

[1130] **[Accepted Papers - IJCAI 2026](https://2026.ijcai.org/accepted-papers/)**  
ijcai.org

[1131] **[Big-Data Science in Porous Materials: Materials Genomics and Machine Learning | Chemical Reviews - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.chemrev.0c00004)**  
acs.org

[1132] **[A Vision-Based Deep Learning Framework for Monitoring and Recognition of Chemical Laboratory Operations - MDPI](https://www.mdpi.com/1424-8220/26/4/1106)**  
mdpi.com

[1133] **[ET-AL: Entropy-targeted active learning for bias mitigation in materials data - AIP Publishing](https://pubs.aip.org/aip/apr/article/10/2/021403/2877876/ET-AL-Entropy-targeted-active-learning-for-bias)**  
aip.org

[1134] **[Transfer Learning-Enhanced Prediction of Glass Transition Temperature in Bismaleimide-Based Polyimides - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12251919/)**  
nih.gov

[1135] **[ChemRefine: An open-source automated and interoperable platform for machine learning and quantum chemistry simulations | ChemRxiv](https://chemrxiv.org/doi/10.26434/chemrxiv-2025-cvg1x)**  
chemrxiv.org

[1136] **[Registered Reports - Center for Open Science (COS)](https://www.cos.io/initiatives/registered-reports)**  
cos.io

[1137] **[Prospective Validation of Machine Learning Algorithms for Absorption, Distribution, Metabolism, and Excretion Prediction: An Industrial Perspective | Request PDF - ResearchGate](https://www.researchgate.net/publication/370950710_Prospective_Validation_of_Machine_Learning_Algorithms_for_Absorption_Distribution_Metabolism_and_Excretion_Prediction_An_Industrial_Perspective)**  
researchgate.net

[1138] **[AI's Role in Drug Exploratory Development - Tenthpin](https://tenthpin.com/insights/blog/exploratory-development)**  
tenthpin.com

[1139] **[Preparation, Bandgap Engineering, and Performance Control of Graphene Nanoribbons | Chemistry of Materials - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.chemmater.1c04215)**  
acs.org

[1140] **[Verifying Machine Learning Interpretability and Explainability Requirements Through Provenance - MDPI](https://www.mdpi.com/2674-113X/5/1/9)**  
mdpi.com

[1141] **[Implementing Machine Learning in the Clinical Laboratory: Opportunities and Challenges - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12743347/)**  
nih.gov

[1142] **[Diversifying Data to Beat Bias | Lab Manager](https://www.labmanager.com/diversifying-data-to-beat-bias-31836)**  
labmanager.com

[1143] **[Precursor recommendation for inorganic synthesis by machine learning materials similarity from scientific literature - ResearchGate](https://www.researchgate.net/publication/371448659_Precursor_recommendation_for_inorganic_synthesis_by_machine_learning_materials_similarity_from_scientific_literature)**  
researchgate.net

[1144] **[MoleMCL: a multi-level contrastive learning framework for molecular pre-training - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11001485/)**  
nih.gov

[1145] **[Clever Hans in Chemistry: Chemist Style Signals Confound Activity Prediction on Public Benchmarks - ResearchGate](https://www.researchgate.net/publication/399059463_Clever_Hans_in_Chemistry_Chemist_Style_Signals_Confound_Activity_Prediction_on_Public_Benchmarks)**  
researchgate.net

[1146] **[Interpretable and Explainable Machine Learning for Materials Science and Chemistry - ACS Publications](https://pubs.acs.org/doi/10.1021/accountsmr.1c00244)**  
acs.org

[1147] **[Prospective and External Validation of an... : Clinical Chemistry - Ovid](https://www.ovid.com/00003030-202502000-00016)**  
ovid.com

[1148] **[(PDF) Robust and scalable uncertainty estimation with conformal prediction for machine-learned interatomic potentials - ResearchGate](https://www.researchgate.net/publication/362759865_Robust_and_scalable_uncertainty_estimation_with_conformal_prediction_for_machine-learned_interatomic_potentials)**  
researchgate.net

[1149] **[Improving Deep Learning Performance with Mixture of Experts and Sparse Activation](https://www.preprints.org/manuscript/202503.0611)**  
preprints.org

[1150] **[Risk-Aware Downlink Throughput Prediction in High-Density 5G Networks - MDPI](https://www.mdpi.com/2079-3197/14/5/105)**  
mdpi.com

[1151] **[Machine-Learning- and Knowledge-Based Scoring Functions Incorporating Ligand and Protein Fingerprints - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC9178954/)**  
nih.gov

[1152] **[Machine Learning Approach towards Quality Assurance: Challenges and Possible Strategies in Laboratory Medicine](https://xiahepublishing.com/2771-165X/JCTP-2023-00061)**  
xiahepublishing.com

[1153] **[(PDF) Laboratory Data as a Potential Source of Bias in Healthcare Artificial Intelligence and Machine Learning Models - ResearchGate](https://www.researchgate.net/publication/385217432_Laboratory_Data_as_a_Potential_Source_of_Bias_in_Healthcare_Artificial_Intelligence_and_Machine_Learning_Models)**  
researchgate.net

[1154] **[Accelerating Reaction Discovery through AI-HTE Integration: Nitrene-Mediated C–O Coupling as a Validated Case Study | JACS Au - ACS Publications](https://pubs.acs.org/doi/10.1021/jacsau.6c00160)**  
acs.org

[1155] **[MolCL-SP: a multimodal contrastive learning framework with non-overlapping substructure perturbations for molecular property prediction | Bioinformatics | Oxford Academic](https://academic.oup.com/bioinformatics/article/41/10/btaf507/8251523)**  
oup.com

[1156] **[Workshop on Computational Chemistry and Machine Learning for Chemical Physics - LIRA](https://cylira.cyu.fr/workshop-on-computational-chemistry-and-machine-learning-for-chemical-physics)**  
cyu.fr

[1157] **[Materials Informatics 2025-2035: Markets, Strategies, Players - IDTechEx](https://www.idtechex.com/en/research-report/materials-informatics-2025/1096)**  
idtechex.com

[1158] **[POSTER 1 Mondrian Conformal Prediction – Confidence Predictions with Excellent Handling of Imbalanced Data](https://ukqsar.org/wp-content/uploads/2018/03/All_Poster_abstracts_v4.pdf)**  
ukqsar.org

[1159] **[UGDMoE: An Uncertainty-Guided Mixture-of-Experts Decoder for Open-Vocabulary Remote Sensing Segmentation - MDPI](https://www.mdpi.com/2072-4292/18/9/1349)**  
mdpi.com

[1160] **[Track: Poster Session 3 East - ICML 2026](https://icml.cc/virtual/2025/session/50265)**  
icml.cc

[1161] **[Recent Applications of Machine Learning in Molecular Property and Chemical Reaction Outcome Predictions | The Journal of Physical Chemistry A - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jpca.3c04779)**  
acs.org

[1162] **[Deep Batch Active Learning for Drug Discovery - eLife](https://elifesciences.org/reviewed-preprints/89679)**  
elifesciences.org

[1163] **[Enhancing Machine Learning Potentials through Transfer Learning across Chemical Elements - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12308786/)**  
nih.gov

[1164] **[Sample efficient reinforcement learning with active learning for molecular design† | Chemical Science | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlehtml/2024/sc/d3sc04653b)**  
rsc.org

[1165] **[Active and transfer learning with partially Bayesian neural networks for materials and chemicals† | Digital Discovery | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlelanding/2025/dd/d5dd00027k)**  
rsc.org

[1166] **[Enhancing Molecular Machine Learning with Quantum-Chemical Descriptors and Hybrid Modeling - ResearchGate](https://www.researchgate.net/publication/399253089_Enhancing_Molecular_Machine_Learning_with_Quantum-Chemical_Descriptors_and_Hybrid_Modeling)**  
researchgate.net

[1167] **[Policy-Based Active Learning for Efficient Molecular Identification | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.6c00474)**  
acs.org

[1168] **[A transferable active-learning strategy for reactive molecular force fields† | Chemical Science | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlelanding/2021/sc/d1sc01825f)**  
rsc.org

[1169] **[Upsampling the Signal: Active Learning with Proxy Spaces | Anton Morgunov](https://ischemist.com/writings/research/active-learning-over-chemical-space)**  
ischemist.com

[1170] **[Predicting Activity Cliffs for Autonomous Medicinal Chemistry - arXiv](https://arxiv.org/html/2604.07560v1)**  
arxiv.org

[1171] **[Transfer learning with graph neural networks for improved molecular property prediction in the multi-fidelity setting - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11258334/)**  
nih.gov

[1172] **[Enhancing Machine Learning Potentials through Transfer Learning across Chemical Elements - arXiv](https://arxiv.org/pdf/2502.13522)**  
arxiv.org

[1173] **[Causal Inference via Style Bias Deconfounding for Domain Generalization - IEEE Computer Society](https://www.computer.org/csdl/journal/tp/2026/05/11344809/2ddLm550gJG)**  
computer.org

[1174] **[Domain-adversarial neural networks for cross-instrument harmonization in blood-based infrared spectroscopy - Attoworld](https://attoworld.de/fileadmin/user_upload/tx_attoworld/publications/Y2026_M05_D29_SPIE_V14099_R1409909.pdf)**  
attoworld.de

[1175] **[Dataset Design for Building Models of Chemical Reactivity - The Doyle Group](https://doyle.chem.ucla.edu/wp-content/uploads/2023/12/raghavan-et-al-2023-dataset-design-for-building-models-of-chemical-reactivity.pdf)**  
ucla.edu

[1176] **[Full article: Accelerating materials discovery: combinatorial synthesis, high-throughput characterization, and computational advances - Taylor & Francis](https://www.tandfonline.com/doi/full/10.1080/27660400.2023.2292486)**  
tandfonline.com

[1177] **[TRANSPIRE-DRP: a deep learning framework for translating patient-derived xenograft drug response to clinical patients via domain adaptation - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12642064/)**  
nih.gov

[1178] **[Adversarial Domain Adaptation Guided by Farthest Distance for Open Set Electronic Nose Drift Compensation - ResearchGate](https://www.researchgate.net/publication/396813404_Adversarial_Domain_Adaptation_Guided_by_Farthest_Distance_for_Open_Set_Electronic_Nose_Drift_Compensation)**  
researchgate.net

[1179] **[Enhancing drug property prediction with dual-channel transfer learning based on molecular fragment - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10360281/)**  
nih.gov

[1180] **[Closed-Loop Transfer Enables AI to Yield Chemical Knowledge - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv-2023-jqbqt)**  
chemrxiv.org

[1181] **[Ten simple rules for writing a Registered Report - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC9612468/)**  
nih.gov

[1182] **[Data-driven active learning approaches for accelerating materials discovery - arXiv](https://arxiv.org/html/2601.06971v3)**  
arxiv.org

[1183] **[From association to causation: a decision-aware framework for reproducible biomarker discovery and precision intervention design in the human gut microbiome - Oxford Academic](https://academic.oup.com/bib/article/27/3/bbag316/8709152)**  
oup.com

[1184] **[Enhancing AI microscopy for foodborne bacterial classification using adversarial domain adaptation to address optical and biological variability - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12378515/)**  
nih.gov

[1185] **[(PDF) A chemically-aware validation framework for benchmarking large language models in materials synthesis planning - ResearchGate](https://www.researchgate.net/publication/405205475_A_chemically-aware_validation_framework_for_benchmarking_large_language_models_in_materials_synthesis_planning)**  
researchgate.net

[1186] **[Causal Machine Learning - arXiv](https://arxiv.org/html/2206.15475v3)**  
arxiv.org

[1187] **[Physics-augmented Deep Learning with Adversarial Domain Adaptation: Applications to STM Image Denoising - arXiv](https://arxiv.org/html/2409.05118v1)**  
arxiv.org

[1188] **[Variant Approach for Identifying Spurious Relations That Deep Learning Models Learn](https://www.frontiersin.org/journals/water/articles/10.3389/frwa.2021.745563/full)**  
frontiersin.org

[1189] **[Text-mined dataset of inorganic materials synthesis recipes - Ceder Group](https://ceder.berkeley.edu/publications/2019_olga_text-mining_dataset.pdf)**  
berkeley.edu

[1190] **[Topology-Aware Multiscale Mixture of Experts for Efficient Molecular Property Prediction - arXiv](https://arxiv.org/pdf/2601.12637)**  
arxiv.org

[1191] **[Farthest point sampling in property designated chemical feature space as an effective strategy for enhancing the machine learning model performance for small scale chemical dataset](https://www.oaepublish.com/articles/jmi.2025.10)**  
oaepublish.com

[1192] **[Accelerating materials discovery through active learning: Methods, challenges and opportunities - The Innovation](https://www.the-innovation.org/article/doi/10.59717/j.xinn-inform.2025.100013)**  
the-innovation.org

[1193] **[Casual Inference via Style Bias Deconfounding for Domain Generalization - arXiv](https://arxiv.org/pdf/2503.16852)**  
arxiv.org

[1194] **[Physics-guided deep learning with adversarial domain adaptation: Applications to STM image denoising - AIP Publishing](https://pubs.aip.org/aip/jap/article/139/14/144303/3386745/Physics-guided-deep-learning-with-adversarial)**  
aip.org

[1195] **[Avoiding spurious correlations via logit correction - Amazon Science](https://www.amazon.science/publications/avoiding-spurious-correlations-via-logit-correction)**  
amazon.science

[1196] **[Submission Guidelines | PLOS One](https://journals.plos.org/plosone/s/submission-guidelines)**  
plos.org

[1197] **[Personalized Federated Conformal Prediction with Localization - OpenReview](https://openreview.net/pdf?id=QQUhGPST45)**  
openreview.net

[1198] **[Active learning for efficient analysis of high-throughput nanopore data - Oxford Academic](https://academic.oup.com/bioinformatics/article/39/1/btac764/6851141)**  
oup.com

[1199] **[Joint Transfer and Batch-mode Active Learning](http://proceedings.mlr.press/v28/chattopadhyay13.pdf)**  
mlr.press

[1200] **[The Advent of Generative Chemistry - ACS Publications - American Chemical Society](https://pubs.acs.org/doi/10.1021/acsmedchemlett.0c00088)**  
acs.org

[1201] **[Clever materials: when models identify good materials for the wrong reasons | Faraday Discussions | The Royal Society of Chemistry](http://pubs.rsc.org/FD/article-lookup/doi/10.1039/D6FD00024J)**  
rsc.org

[1202] **[ACS Medicinal Chemistry Letters - Author Guidelines](https://researcher-resources.acs.org/publish/author_guidelines?coden=amclct)**  
acs.org

[1203] **[Adaptive Source-Task Expert Routing for Supervised Molecular Pretraining in Low-Data Electrochemical Property Prediction - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv.15004913)**  
chemrxiv.org

[1204] **[Artificial Intelligence as the Next Layer of Chemometrics | Spectroscopy Online](https://www.spectroscopyonline.com/view/artificial-intelligence-as-the-next-layer-of-chemometrics)**  
spectroscopyonline.com

[1205] **[Machine learning-guided strategies for reaction conditions design and optimization](https://www.beilstein-journals.org/bjoc/articles/20/212)**  
beilstein-journals.org

[1206] **[Experimental reporting - The Royal Society of Chemistry](https://www.rsc.org/publishing/publish-with-us/publish-a-journal-article/experimental-reporting)**  
rsc.org

[1207] **[Trustworthy Machine Learning and Mathematical Modelling for Lithium-Ion Battery State-of-Health Estimation - MDPI](https://www.mdpi.com/2227-7390/14/11/1879)**  
mdpi.com

[1208] **[Deep Batch Active Learning for Drug Discovery - eLife](https://elifesciences.org/reviewed-preprints/89679v2)**  
elifesciences.org

[1209] **[Accelerating high-throughput virtual screening through molecular pool-based active learning† | Chemical Science | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlelanding/2021/sc/d0sc06805e)**  
rsc.org

[1210] **[Trusting our machines: validating machine learning models for single-molecule transport experiments - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC9377421/)**  
nih.gov

[1211] **[Predictive chemistry: machine learning for reaction deployment, reaction development, and reaction discovery | Chemical Science](https://pubs.rsc.org/en/content/articlelanding/2023/sc/d2sc05089g)**  
rsc.org

[1212] **[ACS Research Data Guidelines](https://researcher-resources.acs.org/publish/data_guidelines)**  
acs.org

[1213] **[Transfer Learning from Markov Models Leads to Efficient Sampling of Related Systems](https://pubs.acs.org/doi/10.1021/acs.jpcb.7b06896)**  
acs.org

[1214] **[Large-Scale Pretraining Improves Sample Efficiency of Active Learning-Based Virtual Screening | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/abs/10.1021/acs.jcim.3c01938)**  
acs.org

[1215] **[Beyond Structure: Revolutionising Materials Discovery via AI-Driven Synthesis Protocol-Property Relationships - arXiv](https://arxiv.org/html/2605.00313v1)**  
arxiv.org

[1216] **[Limitations of theory-informed machine learning algorithms for the prediction and exploration of molecular properties: Solvation free energy as a case study - AIP Publishing](https://pubs.aip.org/aip/aml/article/3/3/036107/3356268/Limitations-of-theory-informed-machine-learning)**  
aip.org

[1217] **[On Modelability and Generalizability: Are Machine Learning Models for Drug Synergy Exploiting Artefacts and Biases in Available Data? | OpenReview](https://openreview.net/forum?id=O9bzFjQBjg)**  
openreview.net

[1218] **[Opportunities for Machine Learning and Artificial Intelligence to Advance Synthetic Drug Substance Process Development - DSpace@MIT](https://dspace.mit.edu/bitstreams/71f31e11-7964-48b0-9a64-5290dfcbdd59/download)**  
mit.edu

[1219] **[Instructions for Authors - Molecules - MDPI](https://www.mdpi.com/journal/molecules/instructions)**  
mdpi.com

[1220] **[Intelligent in-silico prioritization of antimalarial peptide candidates under explicit physicochemical windows via de novo CTCM-Neo generation and conformal-gated calibrated classification - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12996230/)**  
nih.gov

[1221] **[Sample-efficient Multi-objective Molecular Optimization with GFlowNets](https://proceedings.neurips.cc/paper_files/paper/2023/file/fbc9981dd6316378aee7fd5975250f21-Paper-Conference.pdf)**  
neurips.cc

[1222] **[Adversarial Attacks and Defenses in Machine Learning - ResearchGate](https://www.researchgate.net/publication/389515260_Adversarial_Attacks_and_Defenses_in_Machine_Learning)**  
researchgate.net

[1223] **[On Modelability and Generalizability: Are Machine Learning Models for Drug Synergy Exploiting Artefacts and Biases in Available Data?](https://proceedings.mlr.press/v240/majha24a.html)**  
mlr.press

[1224] **[Opportunities for Machine Learning and Artificial Intelligence to Advance Synthetic Drug Substance Process Development - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.oprd.3c00229)**  
acs.org

[1225] **[Computational Prediction and Validation of an Expert's Evaluation of Chemical Probes](https://pmc.ncbi.nlm.nih.gov/articles/PMC4955571/)**  
nih.gov

[1226] **[Exchangeability, Conformal Prediction, and Rank Tests - ResearchGate](https://www.researchgate.net/publication/341369823_Exchangeability_Conformal_Prediction_and_Rank_Tests)**  
researchgate.net

[1227] **[ChemSpaceAL: An Efficient Active Learning Methodology Applied to Protein-Specific Molecular Generation - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10516108/)**  
nih.gov

[1228] **[Clinical Research with AI - The Physician AI Handbook](https://physicianaihandbook.com/practical/research.html)**  
physicianaihandbook.com

[1229] **[[2603.24704] Conformal Selective Prediction with General Risk Control - arXiv](https://arxiv.org/abs/2603.24704)**  
arxiv.org

[1230] **[A Systematic Review of Deep Learning Methodologies Used in the Drug Discovery Process with Emphasis on In Vivo Validation - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10095548/)**  
nih.gov

[1231] **[The Journal of Physical Chemistry A - Author Guidelines](https://researcher-resources.acs.org/publish/author_guidelines?coden=jpcafh)**  
acs.org

[1232] **[(PDF) Meta-Learning Linear Models for Molecular Property Prediction - ResearchGate](https://www.researchgate.net/publication/395582849_Meta-Learning_Linear_Models_for_Molecular_Property_Prediction)**  
researchgate.net

[1233] **[Conformal Prediction in the Age of Multimodal Foundation Models: A Survey | Request PDF](https://www.researchgate.net/publication/400384689_Conformal_Prediction_in_the_Age_of_Multimodal_Foundation_Models_A_Survey)**  
researchgate.net

[1234] **[Sample Efficient Generative Optimization for Molecular Design - arXiv](https://arxiv.org/html/2607.12488v1)**  
arxiv.org

[1235] **[Submission and Review - Inorganic Synthesis](https://www.inorgsynth.com/submitting.php)**  
inorgsynth.com

[1236] **[Machine Learning in Unmanned Systems for Chemical Synthesis - MDPI](https://www.mdpi.com/1420-3049/28/5/2232)**  
mdpi.com

[1237] **[A Systematic Survey and Benchmark of Deep Learning for Molecular Property Prediction in the Foundation Model Era - arXiv](https://arxiv.org/pdf/2604.16586)**  
arxiv.org

[1238] **[Improving Expert Predictions with Conformal Prediction - NSF PAR](https://par.nsf.gov/servlets/purl/10466308)**  
nsf.gov

[1239] **[Sample Efficient Reinforcement Learning with Active Learning for Molecular Design](https://www.researchgate.net/publication/378082903_Sample_Efficient_Reinforcement_Learning_with_Active_Learning_for_Molecular_Design)**  
researchgate.net

[1240] **[Journal Information - SYNLETT - Georg Thieme Verlag](https://www.thieme.de/de/synlett/journal-information-55964.htm)**  
thieme.de

[1241] **[Multi-Task Learning for Metal Alloy Property Prediction: An Empirical Study of Negative Transfer and Mitigation Strategies - arXiv](https://arxiv.org/html/2512.22740v3)**  
arxiv.org

[1242] **[Transfer-Learning Deep Raman Models Using Semiempirical Quantum Chemistry](https://pubs.acs.org/doi/10.1021/acs.jcim.5c00513)**  
acs.org

[1243] **[AI-powered target identification: How machine learning is finding new drug targets](https://www.drugdiscoverynews.com/ai-powered-target-identification-how-machine-learning-is-finding-new-drug-targets-17344)**  
drugdiscoverynews.com

[1244] **[The Journal of Organic Chemistry - Author Guidelines - American Chemical Society](https://researcher-resources.acs.org/publish/author_guidelines?coden=joceah)**  
acs.org

[1245] **[Transfer Learning for Heterocycle Retrosynthesis | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.4c02041)**  
acs.org

[1246] **[Iterative experimental design based on active machine learning reduces the experimental burden associated with reaction screening - Royal Society of Chemistry journals](https://pubs.rsc.org/en/content/articlelanding/2020/re/d0re00232a)**  
rsc.org

[1247] **[Quantifying the performance of machine learning models in materials discovery - Royal Society of Chemistry journals](https://pubs.rsc.org/en/content/articlelanding/2023/dd/d2dd00113f)**  
rsc.org

[1248] **[Bayesian optimization for chemical reactions - Royal Society of Chemistry journals](https://pubs.rsc.org/cs/article/55/5/2731/311626/Bayesian-optimization-for-chemical-reactions)**  
rsc.org

[1249] **[Out-of-distribution evaluation of active learning pipelines for molecular property prediction](https://pubs.rsc.org/en/content/articlehtml/2026/ra/d5ra08055j)**  
rsc.org

[1250] **[Evaluating Machine Learning Models for Molecular Property Prediction: Performance and Robustness on Out-of-Distribution Data - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.5c00475)**  
acs.org

[1251] **[DEPARTMENT OF INFORMATICS Bayesian optimization of material synthesis parameters - mediaTUM](https://mediatum.ub.tum.de/doc/1709841/h6o0f7uwa3jmb87m6u9tsitkl.pdf)**  
tum.de

[1252] **[Multi-task Bayesian Optimization of Chemical Reactions - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv.13250216.v2)**  
chemrxiv.org

[1253] **[Large-Scale Pretraining Improves Sample Efficiency of Active Learning-Based Virtual Screening | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.3c01938)**  
acs.org

[1254] **[Active learning & Experimental design | Ruth Misener](https://wp.doc.ic.ac.uk/rmisener/project/active-learning-experimental-design/)**  
ic.ac.uk

[1255] **[Causal Intervention Active Learning for Oxide Material Screening: Balancing Structure Identification and Prediction - MDPI](https://www.mdpi.com/2073-4344/16/7/654)**  
mdpi.com

[1256] **[Race to the bottom: Bayesian optimisation for chemical problems† | Digital Discovery](https://pubs.rsc.org/dd/article/3/6/1086/804994/Race-to-the-bottom-Bayesian-optimisation-for)**  
rsc.org

[1257] **[Toward performance-diverse small-molecule libraries for cell-based phenotypic screening using multiplexed high-dimensional profiling | PNAS](https://www.pnas.org/doi/10.1073/pnas.1410933111)**  
pnas.org

[1258] **[Best Practices for Multi-Fidelity Bayesian Optimization in Materials and Molecular Research](https://arxiv.org/html/2410.00544v3)**  
arxiv.org

[1259] **[Foundation-Model Surrogates Enable Data-Efficient Active Learning for Materials Discovery Citation - arXiv](https://arxiv.org/html/2603.12567v2)**  
arxiv.org

[1260] **[When Active Learning Falls Short: An Empirical Study on Chemical ...](https://arxiv.org/html/2604.19335v1)**  
arxiv.org

[1261] **[Active Learning Improves Ionization Efficiency Predictions and Quantification in Nontargeted LC/HRMS | Analytical Chemistry - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.analchem.5c00816)**  
acs.org

[1262] **[Bayesian Optimization for Chemical Synthesis in the Era of Artificial Intelligence: Advances and Applications - MDPI](https://www.mdpi.com/2227-9717/13/9/2687)**  
mdpi.com

[1263] **[A framework to evaluate machine learning crystal stability predictions - Kristin Persson](https://perssongroup.lbl.gov/papers/Riebesell_et_al-2025-Nature_Machine_Intelligence.pdf)**  
lbl.gov

[1264] **[Selecting, Acquiring, and Using Small Molecule Libraries for High-Throughput Screening - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC4687755/)**  
nih.gov

[1265] **[materials-data-facility/awesome-bayesian-optimization - GitHub](https://github.com/materials-data-facility/awesome-bayesian-optimization)**  
github.com

[1266] **[ActiveFusion: Fused representations improve active learning for molecular property prediction - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv.15003911)**  
chemrxiv.org

[1267] **[Distilling and exploiting quantitative insights from Large Language Models for enhanced Bayesian optimization of chemical reactions - arXiv](https://arxiv.org/html/2504.08874v1)**  
arxiv.org

[1268] **[Finding the most potent compounds using active learning on molecular pairs - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11368049/)**  
nih.gov

[1269] **[Batched Bayesian optimization with correlated candidate uncertainties - OpenReview](https://openreview.net/forum?id=fzJtylzsKO)**  
openreview.net

[1270] **[What are R² and RMSE? | Clarity Help Center](https://help.clarity.io/knowledge/r2-rmse)**  
clarity.io

[1271] **[Robust Molecular Property Prediction via Densifying Scarce Labeled Data - arXiv](https://arxiv.org/html/2506.11877v3)**  
arxiv.org

[1272] **[Filtering Chemical Libraries - Practical Cheminformatics](http://practicalcheminformatics.blogspot.com/2018/08/filtering-chemical-libraries.html)**  
blogspot.com

[1273] **[Bayesian optimization for chemical reactions - PubMed](https://pubmed.ncbi.nlm.nih.gov/41664868/)**  
nih.gov

[1274] **[Enhancing Machine Learning Potentials through Transfer Learning across Chemical Elements - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.5c00293)**  
acs.org

[1275] **[Active Learning Validation 101: Quantifying Your Success | Relativity Blog](https://www.relativity.com/blog/active-learning-validation-101-quantifying-your-success/)**  
relativity.com

[1276] **[Batched Bayesian Optimization by Maximizing the Probability of Including the Optimum](https://pubs.acs.org/doi/10.1021/acs.jcim.5c00214)**  
acs.org

[1277] **[University of Groningen The coefficient of determination R-squared is more informative than SMAPE, MAE, MAPE, MSE and RMSE in re](https://pure.rug.nl/ws/portalfiles/portal/177229407/peerj_cs_623_1_.pdf)**  
rug.nl

[1278] **[Robust Molecular Property Prediction via Densifying Scarce Labeled Data - arXiv](https://arxiv.org/html/2506.11877v4)**  
arxiv.org

[1279] **[Development and Testing of Druglike Screening Libraries | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.8b00537)**  
acs.org

[1280] **[Bayesian Optimization with Gaussian Processes Assisted by Deep Learning for Material Designs | The Journal of Physical Chemistry Letters - ACS Publications](https://pubs.acs.org/doi/full/10.1021/acs.jpclett.5c00592)**  
acs.org

[1281] **[NeurIPS Poster Bridging the Gap Between Cross-Domain Theory and Practical Application: A Case Study on Molecular Dissolution](https://neurips.cc/virtual/2025/poster/117544)**  
neurips.cc

[1282] **[Toward generalizable predictive models for DNA-encoded libraries - https ://uu.diva-portal.org](https://uu.diva-portal.org/smash/get/diva2:2046002/FULLTEXT01.pdf)**  
diva-portal.org

[1283] **[Acquisition Functions in Bayesian Optimization - Emergent Mind](https://www.emergentmind.com/topics/acquisition-functions)**  
emergentmind.com

[1284] **[Improving molecular machine learning through adaptive subsampling with active learning† | Digital Discovery | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlelanding/2023/dd/d3dd00037k)**  
rsc.org

[1285] **[Chapter 14: Active Learning for Drug Discovery and Automated Data Curation - Books](https://books.rsc.org/books/edited-volume/1266/chapter/917154/Active-Learning-for-Drug-Discovery-and-Automated)**  
rsc.org

[1286] **[Artificial Intelligence-Driven Natural Product Discovery for Cancer Metastasis and Chemoresistance: From Computational Prediction to Preclinical Validation - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12984267/)**  
nih.gov

[1287] **[Do Larger Models Really Win in Drug Discovery? A Benchmark Assessment of Model Scaling in AI Driven Molecular Property and Activity Prediction | bioRxiv](https://www.biorxiv.org/content/10.64898/2026.04.29.721568v2.full-text)**  
biorxiv.org

[1288] **[Deep Learning-Based Genetic Perturbation Models Do Outperform Uninformative Baselines on Well-Calibrated Metrics | bioRxiv](https://www.biorxiv.org/content/10.1101/2025.10.20.683304v1.full-text)**  
biorxiv.org

[1289] **[Why Bayesian Optimization Can Fall Short for Materials Innovation](https://citrine.io/why-bayesian-optimization-can-fall-short-for-materials-innovation/)**  
citrine.io

[1290] **[Deep active learning with high structural discriminability for molecular mutagenicity prediction - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11366013/)**  
nih.gov

[1291] **[Active Learning for Accelerated Discovery of Two-Dimensional Magnetic Topological Materials - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.chemmater.5c00908)**  
acs.org

[1292] **[ICML Poster Active Learning for Efficient Discovery of Optimal Combinatorial Perturbations](https://icml.cc/virtual/2025/poster/44533)**  
icml.cc

[1293] **[Trustworthy Compound–Protein Interaction Prediction with Interpretable and Conformalized Cross-Attention Transformers | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.5c02709)**  
acs.org

[1294] **[A systematic benchmark of machine learning methods for protein–RNA interaction prediction - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10516373/)**  
nih.gov

[1295] **[Transfer learning Bayesian optimization for competitor DNA molecule design for use in diagnostic assays - PubMed](https://pubmed.ncbi.nlm.nih.gov/39412958/)**  
nih.gov

[1296] **[(PDF) Sample-Efficient Bayesian Optimization with Transfer Learning for Heterogeneous Search Spaces - ResearchGate](https://www.researchgate.net/publication/383911485_Sample-Efficient_Bayesian_Optimization_with_Transfer_Learning_for_Heterogeneous_Search_Spaces)**  
researchgate.net

[1297] **[Results of the Active Learning Challenge](https://proceedings.mlr.press/v16/guyon11a/guyon11a.pdf)**  
mlr.press

[1298] **[Generative Active Learning for the Search of Small-molecule Protein Binders - arXiv](https://arxiv.org/html/2405.01616v1)**  
arxiv.org

[1299] **[Extreme Gradient Boosting Combined with Conformal Predictors for Informative Solubility Estimation - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10779886/)**  
nih.gov

[1300] **[Artificial intelligence in the discovery and design of molecular semiconductors: a systematic review - Royal Society of Chemistry journals](https://pubs.rsc.org/en/content/articlelanding/2026/dd/d5dd00552c)**  
rsc.org

[1301] **[Towards global reaction feasibility and robustness prediction with high throughput data and bayesian deep learning - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12081921/)**  
nih.gov

[1302] **[Multi-objective Bayesian optimization: a case study in material extrusion | Digital Discovery](https://pubs.rsc.org/en/content/articlehtml/2025/dd/d4dd00281d)**  
rsc.org

[1303] **[Bayesian reaction optimization as a tool for chemical synthesis - The Doyle Group](https://doyle.chem.ucla.edu/wp-content/uploads/2021/02/58.-Bayesian-reaction-optimization-as-a-tool-for-chemical-synthesis.pdf)**  
ucla.edu

[1304] **[LFaB: Low Fidelity as Bias for Active Learning in the Chemical Configuration Space](https://pubs.acs.org/doi/10.1021/acs.jctc.6c00009)**  
acs.org

[1305] **[Data-Driven Dynamic Stability Assessment in Large-Scale Power Grid Based on Deep Transfer Learning - MDPI](https://www.mdpi.com/1996-1073/16/3/1142)**  
mdpi.com

[1306] **[Improving Molecular Contrastive Learning via Faulty Negative Mitigation and Decomposed Fragment Contrast - arXiv](https://arxiv.org/pdf/2202.09346)**  
arxiv.org

[1307] **[Multi-Source Domain Transfer Learning for Accurate Property Prediction in Two-Dimensional Materials - arXiv](https://arxiv.org/pdf/2605.24455)**  
arxiv.org

[1308] **[Auditing domain alignment in latent representations for cross ...](https://www.researchgate.net/publication/408609600_Auditing_domain_alignment_in_latent_representations_for_cross-domain_materials_machine_learning)**  
researchgate.net

[1309] **[Transfer Learning with Gaussian Processes for Bayesian Optimization](https://proceedings.mlr.press/v151/tighineanu22a/tighineanu22a.pdf)**  
mlr.press

[1310] **[Pairwise Difference Regression: A Machine Learning Meta-algorithm for Improved Prediction and Uncertainty Quantification in Chemical Search - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.1c00670)**  
acs.org

[1311] **[Navigating chemical space: multi-level Bayesian optimization with hierarchical coarse-graining - Royal Society of Chemistry journals](https://pubs.rsc.org/en/content/articlehtml/2025/sc/d5sc03855c)**  
rsc.org

[1312] **[Collaborative Active Learning Activities Promote Deep Learning in a Chemistry-Biochemistry Course - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC8368399/)**  
nih.gov

[1313] **[A unified active learning framework for photosensitizer design | Chemical Science | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlehtml/2026/sc/d5sc05749c)**  
rsc.org

[1314] **[A methodology to correctly assess the applicability domain of cell membrane permeability predictors for cyclic peptides† | Digital Discovery | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlehtml/2024/dd/d4dd00056k)**  
rsc.org

[1315] **[UAC-GNN: Uncertainty-Aware Contrastive Graph ... - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv.15000970)**  
chemrxiv.org

[1316] **[In Search of Beautiful Molecules: A Perspective on Generative Modeling for Drug Design - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.5c01203)**  
acs.org

[1317] **[Enhancing molecular property prediction through data integration and consistency assessment - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12574261/)**  
nih.gov

[1318] **[Bi-level Contrastive Learning for Knowledge-Enhanced Molecule Representations](https://ojs.aaai.org/index.php/AAAI/article/view/32013/34168)**  
aaai.org

[1319] **[Domain Generalization Using Maximum Mean Discrepancy Loss for Remaining Useful Life Prediction of Lithium-Ion Batteries - MDPI](https://www.mdpi.com/2313-0105/11/5/194)**  
mdpi.com

[1320] **[Combining machine learning and high-throughput experimentation to discover photocatalytically active organic molecules - Chemical Science (RSC Publishing) DOI:10.1039/D1SC02150H - Royal Society of Chemistry journals](https://pubs.rsc.org/en/content/articlehtml/2021/sc/d1sc02150h)**  
rsc.org

[1321] **[Bayesian optimization with known experimental and design constraints for chemistry applications† | Digital Discovery](https://pubs.rsc.org/dd/article/1/5/732/311447/Bayesian-optimization-with-known-experimental-and)**  
rsc.org

[1322] **[Active learning of alchemical adsorption simulations; towards a universal adsorption model† | Chemical Science | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlehtml/2024/sc/d4sc02156h)**  
rsc.org

[1323] **[A More Robust Baseline for Active Learning by Injecting Randomness to Uncertainty Sampling](https://www.csie.ntu.edu.tw/~htlin/paper/doc/wsaihci23baseactive.pdf)**  
ntu.edu.tw

[1324] **[Machine Learning-Driven Data Valuation for Optimizing High-Throughput Screening Pipelines - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11558681/)**  
nih.gov

[1325] **[NeurIPS 2025 ML×OR Workshop: Mathematical Foundations and Operational Integration of Machine Learning for Uncertainty-Aware Decision-Making](https://mlxor-workshop.github.io/)**  
github.io

[1326] **[Artificial intelligence drives the identification and screening of novel antibiotics and antimicrobial peptides - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC13076943/)**  
nih.gov

[1327] **[Fused Gromov-Wasserstein Contrastive Learning for Effective Enzyme-Reaction Screening](https://arxiv.org/html/2512.08508v1)**  
arxiv.org

[1328] **[Comprehensive Review of Contrastive and Generative Self-Supervised Learning for Small Molecular Representation | Journal of Chemical Information and Modeling - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jcim.6c00547)**  
acs.org

[1329] **[A comprehensive benchmark of active learning strategies with AutoML for small-sample regression in materials science - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12550062/)**  
nih.gov

[1330] **[A study of deep active learning methods to reduce labelling efforts in biomedical relation extraction - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC10723703/)**  
nih.gov

[1331] **[Similarity Search for Efficient Active Learning and Search of Rare Concepts](https://people.eecs.berkeley.edu/~matei/papers/2022/aaai_seals.pdf)**  
berkeley.edu

[1332] **[Uncertainty Quantification | IBM](https://www.ibm.com/think/topics/uncertainty-quantification)**  
ibm.com

[1333] **[MolFCL: predicting molecular properties through chemistry-guided contrastive and prompt learning | Bioinformatics | Oxford Academic](https://academic.oup.com/bioinformatics/article/41/2/btaf061/8005854)**  
oup.com

[1334] **[Closed-loop Auto Research for Molecular Property Prediction: Discovering and Certifying Generalizable Improvements - arXiv](https://arxiv.org/html/2606.22731v1)**  
arxiv.org

[1335] **[Continuous discovery of novel 2D materials via dual active learning-driven generative models | National Science Review | Oxford Academic](https://academic.oup.com/nsr/article/doi/10.1093/nsr/nwag101/8475385)**  
oup.com

[1336] **[Contrastive Domain Generalization for Cross-Instrument Molecular Identification in Mass Spectrometry - arXiv](https://arxiv.org/html/2602.00547)**  
arxiv.org

[1337] **[Assisted Active Learning for Model-Based Method Development in Liquid Chromatography | Analytical Chemistry - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.analchem.4c02700)**  
acs.org

[1338] **[Cost-Aware Active Learning Framework for Efficient Small-Object Detection in Agricultural Images - MDPI](https://www.mdpi.com/2079-9292/15/6/1196)**  
mdpi.com

[1339] **[Mapping of machine learning approaches for description, prediction, and causal inference in the social and health sciences - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC9581488/)**  
nih.gov

[1340] **[Conformal Prediction: A Gentle Introduction - ResearchGate](https://www.researchgate.net/publication/369660224_Conformal_Prediction_A_Gentle_Introduction)**  
researchgate.net

[1341] **[Molecular property prediction by contrastive learning with attention-guided positive sample selection | Bioinformatics | Oxford Academic](https://academic.oup.com/bioinformatics/article/39/5/btad258/7133736)**  
oup.com

[1342] **[(PDF) Wasserstein metric for improved quantum machine learning with adjacency matrix representations - ResearchGate](https://www.researchgate.net/publication/342482694_Wasserstein_metric_for_improved_quantum_machine_learning_with_adjacency_matrix_representations)**  
researchgate.net

[1343] **[CLOOME: contrastive learning unlocks bioimaging databases for queries with chemical structures | bioRxiv](https://www.biorxiv.org/content/10.1101/2022.11.17.516915v2.full-text)**  
biorxiv.org

[1344] **[Active Learning for Sampling in Time-Series Experiments With Application to Gene Expression Analysis](https://icml.cc/Conferences/2005/proceedings/papers/105_ActiveLearning_SinghEtAl.pdf)**  
icml.cc

[1345] **[Area Under the mean squared error Learning Curve (AULC) for the... - ResearchGate](https://www.researchgate.net/figure/Area-Under-the-mean-squared-error-Learning-Curve-AULC-for-the-strategies-in-the_tbl2_334059795)**  
researchgate.net

[1346] **[Uncertainty-aware augmented generation (UAG): A novel deep learning method for enriching in-conversation user intent toward improved LLM generation | Request PDF - ResearchGate](https://www.researchgate.net/publication/396908141_Uncertainty-aware_augmented_generation_UAG_A_novel_deep_learning_method_for_enriching_in-conversation_user_intent_toward_improved_LLM_generation)**  
researchgate.net

[1347] **[Clever Hans in Chemistry: Chemist Style Signals Confound Activity Prediction on Public Benchmarks - Department of Computer Science](https://www.cs.toronto.edu/~cmaddis/courses/csc2541_w26/readings/leashbio_cleverhans.pdf)**  
toronto.edu

[1348] **[INTRA-FUSED GROMOV WASSERSTEIN DISCREPANCY: A SMOOTH METRIC FOR CROSS-DOMAIN STRUCTURED DATA - OpenReview](https://openreview.net/pdf/3ead782f98da921fc08a3259dca0a116799e13cb.pdf)**  
openreview.net

[1349] **[Optimized Active Learning Method for High-Dimensional Industrial Regression Problems](https://www.mdpi.com/1999-4893/18/12/757)**  
mdpi.com

[1350] **[A study of deep active learning methods to reduce labelling efforts in biomedical relation extraction | PLOS One - Research journals](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0292356)**  
plos.org

[1351] **[Active Learning for Gaussian Process Regression Under Self ... - arXiv](https://arxiv.org/html/2605.10654v1)**  
arxiv.org

[1352] **[Enhancing Online Continual Learning with Plug-and-Play State Space Model and Class-Conditional Mixture of Discretization](https://openaccess.thecvf.com/content/CVPR2025/papers/Liu_Enhancing_Online_Continual_Learning_with_Plug-and-Play_State_Space_Model_and_CVPR_2025_paper.pdf)**  
thecvf.com

[1353] **[FlashBind: Towards Accurate and Efficient Structure-based Virtual ...](https://openreview.net/forum?id=2D91AcVcMi)**  
openreview.net

[1354] **[Learning to Predict Graphs with Fused Gromov-Wasserstein Barycenters](https://proceedings.mlr.press/v162/brogat-motte22a/brogat-motte22a.pdf)**  
mlr.press

[1355] **[PolyCL: contrastive learning for polymer representation learning via explicit and implicit augmentations† | Digital Discovery | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlehtml/2025/dd/d4dd00236a)**  
rsc.org

[1356] **[Active learning increases student performance in science, engineering, and mathematics](https://www.pnas.org/doi/10.1073/pnas.1319030111)**  
pnas.org

[1357] **[Uncertainty-Driven Deep-Ensemble Temporal Convolutional Networks for Predicting Chemical Reaction Dynamics - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jctc.5c02153)**  
acs.org

[1358] **[AURA: Active-Response Attribution under Treatment Ambiguity in Bacterial Cytological Profiling - arXiv](https://arxiv.org/pdf/2606.16477)**  
arxiv.org

[1359] **[Improving molecular property prediction through a task similarity enhanced transfer learning strategy - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC9579493/)**  
nih.gov

[1360] **[DAGIP: alleviating cell-free DNA sequencing biases with optimal transport - PMC - NIH](https://pmc.ncbi.nlm.nih.gov/articles/PMC11887355/)**  
nih.gov

[1361] **[Learning Substructure Invariance for Out-of-Distribution Molecular Representations](https://yangnianzu0515.github.io/files/paper4-moleood.pdf)**  
github.io

[1362] **[Optimal Transport Distances to Characterize Electronic Excitations | Journal of Chemical Theory and Computation - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jctc.4c00289)**  
acs.org

[1363] **[Ab Initio Machine Learning in Chemical Compound Space - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC8391942/)**  
nih.gov

[1364] **[Enhancing molecular property prediction with auxiliary learning and task-specific adaptation - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11270959/)**  
nih.gov

[1365] **[From Interaction to Intent: Inferring User Objectives from Provenance Logs - arXiv](https://arxiv.org/html/2607.04501v1)**  
arxiv.org

[1366] **[Alleviating cell-free DNA sequencing biases with optimal transport - eLife](https://elifesciences.org/reviewed-preprints/98116)**  
elifesciences.org

[1367] **[Combination of near-infrared spectroscopy with Wasserstein generative adversarial networks for rapidly detecting raw material quality for formula products](https://opg.optica.org/abstract.cfm?uri=oe-32-4-5529)**  
optica.org

[1368] **[Gromov-Wasserstein Multi-modal Alignment and Clustering - ResearchGate](https://www.researchgate.net/publication/364397506_Gromov-Wasserstein_Multi-modal_Alignment_and_Clustering)**  
researchgate.net

[1369] **[Optimal Transport Distances to Characterize Electronic Excitations - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11238536/)**  
nih.gov

[1370] **[Scaling laws in enzyme function reveal a new kind of biochemical universality - PNAS](https://www.pnas.org/doi/10.1073/pnas.2106655119)**  
pnas.org

[1371] **[Recent Advancements in Active Learning - MDPI](https://www.mdpi.com/2227-7390/14/8/1358)**  
mdpi.com

[1372] **[Accurate, Uncertainty-Aware Classification of Molecular Chemical Motifs from Multimodal X-ray Absorption Spectroscopy | The Journal of Physical Chemistry A - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jpca.3c06910)**  
acs.org

[1373] **[Trust but Verify: Prover-Verifier Deliberation for Selective LLM Prediction - arXiv](https://arxiv.org/html/2605.25133)**  
arxiv.org

[1374] **[Machine learning-driven cancer diagnostics with improved robustness and interpretability | Chemical Science | The Royal Society of Chemistry](https://pubs.rsc.org/en/content/articlelanding/2026/sc/d6sc02368a)**  
rsc.org

[1375] **[Quantifying Distributional Invariance in Causal Subgraph for IRM-Free Graph Generalization](https://openreview.net/forum?id=IpYEKM0Bla&referrer=%5Bthe%20profile%20of%20Xiangyu%20Fu%5D(%2Fprofile%3Fid%3D~Xiangyu_Fu1))**  
openreview.net

[1376] **[A Small Target Tea Leaf Disease Detection Model Combined with Transfer Learning - MDPI](https://www.mdpi.com/1999-4907/15/4/591)**  
mdpi.com

[1377] **[Fast and interpretable quantification of biological shape heterogeneity via stratified Wasserstein kernel - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC13167030/)**  
nih.gov

[1378] **[Optimal transport for generating transition states in chemical reactions - Cornell: Computer Science](https://www.cs.cornell.edu/gomes/pdf/2025_duan_nmi_reactot.pdf)**  
cornell.edu

[1379] **[Neural Scaling Laws Achieve Sub-Chemical Accuracy - Quantum Zeitgeist](https://quantumzeitgeist.com/neural-scaling-laws-achieve-sub-chemical-accuracy-for-molecular-schrodinger-solutions/)**  
quantumzeitgeist.com

[1380] **[From Active to Proactive Learning Methods - CMU School of Computer Science](https://www.cs.cmu.edu/~jgc/Active-to-Proactive%20Learning.pdf)**  
cmu.edu

[1381] **[Increasing the Effectiveness of Active Learning: Introducing Artificial Data Generation in Active Learning for Land Use/Land Cover Classification - MDPI](https://www.mdpi.com/2072-4292/13/13/2619)**  
mdpi.com

[1382] **[Track: Poster Session 5 - NeurIPS 2026](https://neurips.cc/virtual/2022/session/64306)**  
neurips.cc

[1383] **[Invariant Risk Minimization | Request PDF - ResearchGate](https://www.researchgate.net/publication/334288906_Invariant_Risk_Minimization)**  
researchgate.net

[1384] **[Meta- and Transfer Learning | Climate Change AI](https://www.climatechange.ai/subject_areas/meta_and_transfer_learning)**  
climatechange.ai

[1385] **[Riemannian Metric Learning for Alignment of Spatial Multiomics - bioRxiv](https://www.biorxiv.org/content/biorxiv/early/2025/12/11/2025.12.09.693237.full.pdf)**  
biorxiv.org

[1386] **[(PDF) Wasserstein Wormhole: Scalable Optimal Transport Distance with Transformers](https://www.researchgate.net/publication/381118159_Wasserstein_Wormhole_Scalable_Optimal_Transport_Distance_with_Transformers)**  
researchgate.net

[1387] **[Power-law behavior of transcription factor dynamics at the single-molecule level implies a continuum affinity model | Nucleic Acids Research | Oxford Academic](https://academic.oup.com/nar/article/49/12/6605/6138597)**  
oup.com

[1388] **[Active Learning and Bayesian Optimization: a Unified Perspective to Learn with a Goal - arXiv](https://arxiv.org/html/2303.01560v4)**  
arxiv.org

[1389] **[AssayMatch: Learning to Select Data for Molecular Activity Models - arXiv](https://arxiv.org/html/2511.16087v1)**  
arxiv.org

[1390] **[Carnegie Mellon University at ICML 2025 – Machine Learning Blog](https://blog.ml.cmu.edu/2025/07/08/carnegie-mellon-university-at-icml-2025/)**  
cmu.edu

[1391] **[MoTSE outperforms baseline methods and alleviates negative ...](https://www.researchgate.net/figure/MoTSE-outperforms-baseline-methods-and-alleviates-negative-transfer-on-the-QM9-and-PCBA_fig1_364221477)**  
researchgate.net

[1392] **[Cross-species Data Classification by Domain Adaptation via Discriminative Heterogeneous Maximum Mean Discrepancy - IEEE Computer Society](https://www.computer.org/csdl/journal/tb/2021/01/08703086/19EqWGxUQj6)**  
computer.org

[1393] **[Frustratingly Easy Environment Discovery for Invariant Learning - MDPI](https://www.mdpi.com/2813-0324/9/1/2)**  
mdpi.com

[1394] **[Cross-disciplinary perspectives on the potential for artificial intelligence across chemistry](https://pmc.ncbi.nlm.nih.gov/articles/PMC12024683/)**  
nih.gov

[1395] **[Computational optimal transport for molecular spectra: The fully discrete case | The Journal of Chemical Physics | AIP Publishing](https://pubs.aip.org/aip/jcp/article/155/18/184101/199639/Computational-optimal-transport-for-molecular)**  
aip.org

[1396] **[UNDERSTANDING THE MIXTURE-OF-EXPERTS ... - OpenReview](https://openreview.net/pdf/19da3efb5a54101e2e407c1cb1992df760b51ec4.pdf)**  
openreview.net

[1397] **[Baseline Model for Predicting Protein–Ligand Unbinding Kinetics through Machine Learning](https://pubs.acs.org/doi/10.1021/acs.jcim.0c00450)**  
acs.org

[1398] **[Neural Scaling of Deep Chemical Models - ChemRxiv](https://chemrxiv.org/doi/pdf/10.26434/chemrxiv-2022-3s512)**  
chemrxiv.org

[1399] **[Efficient sampling-based Bayesian Active Learning for synaptic characterization | PLOS Computational Biology - Research journals](https://journals.plos.org/ploscompbiol/article?id=10.1371/journal.pcbi.1011342)**  
plos.org

[1400] **[MSIGN: A deep learning framework based on multi-scale interaction graph neural networks for predicting binding of synthetic cannabinoids to receptors](https://pubs.rsc.org/en/content/articlehtml/2026/dd/d5dd00317b)**  
rsc.org

[1401] **[Accurate Predictions of Molecular Properties of Proteins via Graph Neural Networks and Transfer Learning | Journal of Chemical Theory and Computation - ACS Publications](https://pubs.acs.org/doi/10.1021/acs.jctc.4c01682)**  
acs.org

[1402] **[Cross-disciplinary perspectives on the potential for artificial intelligence across chemistry](https://pubs.rsc.org/en/content/articlehtml/2025/cs/d5cs00146c)**  
rsc.org

[1403] **[Multi-Alignment Contrastive Learning for Enzyme–Reaction Retrieval - arXiv](https://arxiv.org/pdf/2512.08508)**  
arxiv.org

[1404] **[Deep learning in single-cell and spatial transcriptomics data analysis: advances and challenges from a data science perspective | Briefings in Bioinformatics | Oxford Academic](https://academic.oup.com/bib/article/26/2/bbaf136/8106554)**  
oup.com

[1405] **[Test-Time Training Scaling Laws for Chemical Exploration in Drug Design - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12728925/)**  
nih.gov

[1406] **[Density-aware active learning for materials discovery: a case study on functionalized nanoporous materials - Royal Society of Chemistry journals](https://pubs.rsc.org/en/content/articlehtml/2025/cp/d5cp02908b)**  
rsc.org

[1407] **[Track: Poster Session 1 - aistats 2026](https://virtual.aistats.org/virtual/2026/session/11473)**  
aistats.org

[1408] **[Routing-Aware Explanations for Mixture of Experts Graph Models in Malware Detection - arXiv](https://arxiv.org/pdf/2602.19025)**  
arxiv.org

[1409] **[Domain-adaptation deep learning models do not outperform simple baseline models in single-cell anti-cancer drug sensitivity prediction | bioRxiv](https://www.biorxiv.org/content/10.64898/2026.02.24.707713v1.full-text)**  
biorxiv.org

[1410] **[Position: Trustworthy AI Suffers from Invariance Conflicts and Causality is the Solution](https://arxiv.org/html/2605.02640v1)**  
arxiv.org

[1411] **[FGW-CLIP: ENHANCING ENZYME SCREENING VIA FUSED GROMOV-WASSERSTEIN CONTRASTIVE LEARN - OpenReview](https://openreview.net/pdf?id=JUu0tsd0Zk)**  
openreview.net

[1412] **[PhILMS: Collaboratory on Mathematics and Physics- Informed Learning Machines for Multiscale and Multiphysics Problems - Pacific Northwest National Laboratory](https://www.pnnl.gov/sites/default/files/media/file/PhILMS_Report_2020.pdf)**  
pnnl.gov

[1413] **[Baseline and Scatter: Correcting the Spectral Chameleons | Spectroscopy Online](https://www.spectroscopyonline.com/view/baseline-and-scatter-correcting-the-spectral-chameleons)**  
spectroscopyonline.com

[1414] **[Multi‐View Biomedical Foundation Models for Molecule‐Target and Property Prediction - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12970179/)**  
nih.gov

[1415] **[Data Isotopes for Data Provenance in DNNs - ResearchGate](https://www.researchgate.net/publication/363128602_Data_Isotopes_for_Data_Provenance_in_DNNs)**  
researchgate.net

[1416] **[Crystallographic Ensembles Reveal the Structural Basis of Binding Entropy in SARS-CoV2 Macrodomain - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12699308/)**  
nih.gov

[1417] **[Aggregating residue-level protein language model embeddings with optimal transport | Bioinformatics Advances | Oxford Academic](https://academic.oup.com/bioinformaticsadvances/article/5/1/vbaf060/8088230)**  
oup.com

[1418] **[Power law - Wikipedia](https://en.wikipedia.org/wiki/Power_law)**  
wikipedia.org

[1419] **[Active Learning for Generalizable Detonation Performance Prediction of Energetic Materials](https://pubs.acs.org/doi/10.1021/acs.chemmater.6c01049)**  
acs.org

[1420] **[Predictive Minisci late stage functionalization with transfer learning - PMC - NIH](https://pmc.ncbi.nlm.nih.gov/articles/PMC10789750/)**  
nih.gov

[1421] **[Bridging the Gap Between Cross-Domain Theory and Practical Application: A Case Study on Molecular Dissolution | OpenReview](https://openreview.net/forum?id=X6djSzDKps)**  
openreview.net

[1422] **[Explore our Funded Projects - aichemy](https://aichemy.ac.uk/explore-our-funded-projects/)**  
aichemy.ac.uk

[1423] **[Learning the Geometry of Data: A Mathematical Review of Shape Space Analysis - arXiv](https://arxiv.org/html/2606.17022v1)**  
arxiv.org

