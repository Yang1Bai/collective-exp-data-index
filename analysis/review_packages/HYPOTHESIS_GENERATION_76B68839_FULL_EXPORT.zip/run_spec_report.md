# Selective Knowledge-Borrowing for OOD Discovery

**Run specification** · Generated on July 20, 2026 by Google Hypothesis Generation. AI can be inaccurate; double check it.

---

## Research Summary

The goal is to establish an operational, falsifiable research programme for "selective knowledge-borrowing" across experimental materials and chemistry domains. The focus is on moving beyond generic transfer-learning benchmarks toward a directed, abstaining map that identifies when one experimental domain can inform OOD (out-of-distribution) decisions for another, and crucially, when it must refuse to borrow. The programme must generate 8–12 mechanistic hypotheses (covering source credibility, latent-state alignment, and negative transfer), propose borrowing methods that include uncertainty-aware mixture-of-experts or conformal gates, and identify high-information experiments to establish prospective discovery claims or falsify the central thesis. Success is measured by quantifiable metrics (e.g., RMSE reduction, R2, sample-saving) across distinct endpoints (prediction, screening, acquisition) while strictly adhering to non-negotiable validity constraints such as exact provenance exclusion, wrong-domain controls, and the separation of exploratory findings from confirmatory results.

## Focus Areas

### Physical and Contextual Determinants of Domain Alignment

Exploration of the mechanistic factors governing transferability, including source credibility, physical adjacency, and condition continuity. This includes comparative analysis of successful edges (e.g., KIT) versus null edges (e.g., CALiSol) to identify the physical signatures that indicate when a domain can inform OOD decisions.

### Algorithmic Frameworks for Controlled and Abstaining Inference

Research into architectures such as uncertainty-aware mixtures-of-experts and conformal gates for selective knowledge borrowing. Focus is placed on target-region-specific transfer to address local epistemic deficits versus global performance metrics, alongside hierarchical modeling of source-target edges.

### Rigorous Validation Protocols for OOD Discovery Claims

Methodological boundaries to separate exploratory findings from frozen confirmation. This involves the use of exact provenance exclusions, shuffled-source controls, and adversarial synthesis to distinguish prospective discovery acceleration from retrospective high-value hits across distinct endpoints.

### Hypothesis-Driven, Diversity-Aware Scientific Exploration

Generation of falsifiable proposals for new material families, condition regimes, or mechanistic regions. This area requires a formal hypothesis-card framework (detailing source evidence, physical rationale, predicted signatures, and falsification conditions) and the identification of genuinely outcome-unseen targets for preregistration.

## Preferences

- Weight scientific hypotheses and discriminating experiments at least as strongly as algorithmic variants.
- Require every scientific proposal to be documented as a hypothesis card (source evidence, rationale, signature, test, control, falsification) before target outcomes are observed.
- Treat all outcomes in the brief as exploratory; confirmation must use a genuinely untouched target or prospective experiment.
- Use an explicit evidence hierarchy (prospective, paper-disjoint, nested grouped, post-outcome diagnostic) and label every conclusion accordingly.
- Verify literature and dataset claims with primary sources and provide traceable citations.
- Prioritize a small number of decisive, feasible tests over a large catalogue of speculative ideas.
- Compare every proposed policy with target-only, random, novelty/diversity, wrong-source, and shuffled-source baselines, including an explicit abstention/failure rule.
- Evaluate transfer benefit both globally and locally within epistemically weak out-of-distribution (OOD) target regions.
- Include null and harmful edges in the knowledge-borrowing map as triggers for principled abstention.
- Identify one outcome-unseen target for preregistration and return a ranked top five plus one primary experiment.

